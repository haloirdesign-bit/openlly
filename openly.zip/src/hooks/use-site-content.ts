"use client";

import { useEffect, useState } from "react";

export interface SiteContent {
  settings: Record<string, string>;
  sections: Record<string, any>;
}

let cache: SiteContent | null = null;

export function useSiteContent() {
  const [data, setData] = useState<SiteContent | null>(cache);
  const [loading, setLoading] = useState(!cache);

  useEffect(() => {
    let mounted = true;
    if (!cache) {
      fetch("/api/content")
        .then((r) => r.json())
        .then((d) => {
          if (!mounted) return;
          cache = d;
          setData(d);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
    return () => {
      mounted = false;
    };
  }, []);

  return { data, loading };
}

export function refreshSiteContent() {
  cache = null;
}

export function waLink(phone?: string, message?: string) {
  const p = phone || "628216881766";
  return message ? `https://wa.me/${p}?text=${encodeURIComponent(message)}` : `https://wa.me/${p}`;
}
