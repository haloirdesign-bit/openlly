"use client";

import { useEffect, useRef, useState } from "react";
import { useSession } from "@/hooks/use-session";
import { toast } from "sonner";

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  createdAt: string;
  orderNumber?: string | null;
}

export function useNotifications() {
  const { user } = useSession();
  const [items, setItems] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const seenRef = useRef<Set<string>>(new Set());
  const firstLoad = useRef(true);

  useEffect(() => {
    if (!user) return;
    let active = true;
    const tick = async () => {
      try {
        const res = await fetch("/api/notifications");
        const d = await res.json();
        if (!active) return;
        const list: AppNotification[] = d.notifications || [];
        // detect new ones (not seen before & unread)
        const fresh = list.filter((n) => !seenRef.current.has(n.id) && !n.read);
        if (firstLoad.current) {
          firstLoad.current = false;
        } else {
          fresh.forEach((n) => {
            toast(n.title, { description: n.message });
          });
        }
        list.forEach((n) => seenRef.current.add(n.id));
        setItems(list);
        setUnread(list.filter((n) => !n.read).length);
      } catch {
        /* ignore */
      }
    };
    tick();
    const interval = setInterval(tick, 30000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [user]);

  const markAllRead = async () => {
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ all: true }),
    });
    setItems((prev) => prev.map((n) => ({ ...n, read: true })));
    setUnread(0);
  };

  return { items, unread, markAllRead };
}
