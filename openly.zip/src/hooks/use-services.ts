"use client";

import { useEffect, useState } from "react";
import type { ServiceDTO, PackageDTO, ServiceType } from "@/lib/types";

export function useServices(type?: ServiceType, niche?: string) {
  const [services, setServices] = useState<ServiceDTO[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams();
    if (type) params.set("type", type);
    if (niche) params.set("niche", niche);
    const qs = params.toString();
    fetch(`/api/services${qs ? `?${qs}` : ""}`)
      .then((r) => r.json())
      .then((d) => setServices(d.services || []))
      .catch(() => setServices([]))
      .finally(() => setLoading(false));
  }, [type, niche]);

  return { services, loading };
}

export function usePackages() {
  const [packages, setPackages] = useState<PackageDTO[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/packages")
      .then((r) => r.json())
      .then((d) => setPackages(d.packages || []))
      .catch(() => setPackages([]))
      .finally(() => setLoading(false));
  }, []);

  return { packages, loading };
}
