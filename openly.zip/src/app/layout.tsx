import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://openly.id";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Openly — Crafted For Your Growth | Jasa Desain Grafis & Website",
    template: "%s | Openly",
  },
  description:
    "Openly — Solusi kreatif untuk membantu bisnis berkembang melalui desain grafis profesional dan website berkualitas. Bagian dari IR DESIGN KREASI.",
  keywords: [
    "Openly",
    "jasa desain grafis",
    "jasa pembuatan website",
    "desain logo",
    "landing page",
    "company profile",
    "IR Design Kreasi",
    "Tanggamus Lampung",
  ],
  authors: [{ name: "IR Design Kreasi" }],
  creator: "IR Design Kreasi",
  icons: {
    icon: "/openly-mark.svg",
    apple: "/openly-mark.svg",
  },
  manifest: "/manifest.webmanifest",
  openGraph: {
    title: "Openly — Crafted For Your Growth",
    description:
      "Solusi kreatif untuk membantu bisnis berkembang melalui desain grafis profesional dan website berkualitas.",
    url: SITE_URL,
    siteName: "Openly",
    type: "website",
    locale: "id_ID",
  },
  twitter: {
    card: "summary_large_image",
    title: "Openly — Crafted For Your Growth",
    description:
      "Solusi kreatif untuk membantu bisnis berkembang melalui desain grafis profesional dan website berkualitas.",
  },
  robots: { index: true, follow: true },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#1E63FF",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body className={`${geistSans.variable} antialiased bg-background text-foreground`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
