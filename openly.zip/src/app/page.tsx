"use client";

import { useEffect } from "react";
import { useRouter } from "@/store/router";
import { Header } from "@/components/openly/header";
import { Footer } from "@/components/openly/footer";
import { BerandaView } from "@/components/openly/views/beranda";
import { JasaDesainView } from "@/components/openly/views/jasa-desain";
import { JasaWebsiteView } from "@/components/openly/views/jasa-website";
import { NicheView } from "@/components/openly/views/niche";
import { PricelistView } from "@/components/openly/views/pricelist";
import { ReviewView } from "@/components/openly/views/review";
import { CaraPemesananView } from "@/components/openly/views/cara-pemesanan";
import { TentangView } from "@/components/openly/views/tentang";
import { KontakView } from "@/components/openly/views/kontak";
import { LoginView } from "@/components/openly/views/login";
import { OrderView } from "@/components/openly/views/order";
import { ConfirmationView } from "@/components/openly/views/confirmation";
import { TrackView } from "@/components/openly/views/track";
import { PortalView } from "@/components/openly/views/portal";
import { AdminView } from "@/components/admin/admin-view";

export default function Home() {
  const view = useRouter((s) => s.view);
  const setFromHash = useRouter((s) => s.setFromHash);

  useEffect(() => {
    setFromHash();
    const onHash = () => setFromHash();
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [setFromHash]);

  // Admin view: completely separate (no public header/footer), premium standalone
  if (view === "admin") {
    return <AdminView />;
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="flex-1">
        {view === "beranda" && <BerandaView />}
        {view === "jasa-desain" && <JasaDesainView />}
        {view === "jasa-website" && <JasaWebsiteView />}
        {view === "niche" && <NicheView />}
        {view === "pricelist" && <PricelistView />}
        {view === "review" && <ReviewView />}
        {view === "cara-pemesanan" && <CaraPemesananView />}
        {view === "tentang" && <TentangView />}
        {view === "kontak" && <KontakView />}
        {view === "login" && <LoginView />}
        {view === "order" && <OrderView />}
        {view === "confirmation" && <ConfirmationView />}
        {view === "track" && <TrackView />}
        {view === "portal" && <PortalView />}
      </main>
      <Footer />
    </div>
  );
}
