import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, signSession, SESSION_COOKIE_NAME } from "@/lib/auth";
import { cookies } from "next/headers";

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();
    if (!email || !password) {
      return NextResponse.json({ error: "Email dan password wajib diisi." }, { status: 400 });
    }
    const user = await db.user.findUnique({ where: { email: email.toLowerCase().trim() } });
    if (!user || !user.active) {
      return NextResponse.json({ error: "Akun tidak ditemukan atau tidak aktif." }, { status: 401 });
    }
    const ok = await verifyPassword(password, user.passwordHash);
    if (!ok) {
      return NextResponse.json({ error: "Email atau password salah." }, { status: 401 });
    }
    const token = signSession({
      sub: user.id,
      email: user.email,
      name: user.name,
      role: user.role as "ADMIN" | "CUSTOMER",
    });
    const store = await cookies();
    store.set(SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });

    let profile = null;
    if (user.role === "CUSTOMER") {
      profile = await db.customerProfile.findUnique({ where: { userId: user.id } });
      if (!profile) {
        return NextResponse.json({ error: "Akun belum diaktivasi admin." }, { status: 403 });
      }
    }

    return NextResponse.json({
      user: { id: user.id, email: user.email, name: user.name, role: user.role, phone: user.phone, avatar: user.avatar },
      profile,
    });
  } catch (e) {
    return NextResponse.json({ error: "Terjadi kesalahan saat login." }, { status: 500 });
  }
}
