import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ user: null });
  const user = await db.user.findUnique({
    where: { id: session.sub },
    select: { id: true, email: true, name: true, role: true, phone: true, avatar: true, active: true },
  });
  if (!user || !user.active) return NextResponse.json({ user: null });
  let profile = null;
  if (user.role === "CUSTOMER") {
    profile = await db.customerProfile.findUnique({ where: { userId: user.id } });
    if (!profile) return NextResponse.json({ user: null });
  }
  return NextResponse.json({ user, profile });
}
