import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { endpoint, keys } = await req.json();
  if (!endpoint || !keys) return NextResponse.json({ error: "Data tidak lengkap" }, { status: 400 });
  await db.pushSubscription.upsert({
    where: { endpoint },
    update: { keys: JSON.stringify(keys), userId: session.sub },
    create: { endpoint, keys: JSON.stringify(keys), userId: session.sub },
  });
  return NextResponse.json({ ok: true });
}
