import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const packages = await db.servicePackage.findMany({
    where: { active: true },
    orderBy: [{ sortOrder: "asc" }],
    include: { service: true },
  });
  const out = packages.map((p) => ({
    id: p.id,
    serviceId: p.serviceId,
    serviceName: p.service.name,
    serviceType: p.service.type,
    name: p.name,
    price: p.price,
    priceLabel: p.priceLabel,
    description: p.description,
    features: p.features ? JSON.parse(p.features) : [],
    estDuration: p.estDuration,
    revision: p.revision,
    popular: p.popular,
    active: p.active,
    sortOrder: p.sortOrder,
  }));
  return NextResponse.json({ packages: out });
}
