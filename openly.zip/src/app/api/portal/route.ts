import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { ORDER_STATUS_LABEL, ORDER_STATUS_COLOR, ORDER_STATUS_STEP } from "@/lib/types";

export async function GET() {
  const session = await getSession();
  if (!session || session.role !== "CUSTOMER")
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const user = await db.user.findUnique({
    where: { id: session.sub },
    include: { customerProfile: true },
  });
  if (!user || !user.customerProfile)
    return NextResponse.json({ error: "Profil kerja sama tidak ditemukan" }, { status: 403 });

  const orders = await db.order.findMany({
    where: { userId: session.sub },
    orderBy: { createdAt: "desc" },
    include: {
      service: true,
      files: { orderBy: { createdAt: "desc" } },
      statusHistory: { orderBy: { createdAt: "asc" }, take: 1 },
    },
  });

  const out = orders.map((o) => ({
    id: o.id,
    orderNumber: o.orderNumber,
    queueNumber: o.queueNumber,
    serviceType: o.serviceType,
    serviceName: o.service?.name || null,
    status: o.status,
    statusLabel: ORDER_STATUS_LABEL[o.status as keyof typeof ORDER_STATUS_LABEL] || o.status,
    statusColor: ORDER_STATUS_COLOR[o.status as keyof typeof ORDER_STATUS_COLOR] || "",
    statusStep: ORDER_STATUS_STEP[o.status as keyof typeof ORDER_STATUS_STEP] ?? 0,
    adminNote: o.adminNote,
    createdAt: o.createdAt,
    updatedAt: o.updatedAt,
    files: o.files.map((f) => ({
      id: f.id,
      fileName: f.fileName,
      fileType: f.fileType,
      note: f.note,
      version: f.version,
      createdAt: f.createdAt,
    })),
  }));

  return NextResponse.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      avatar: user.avatar,
    },
    profile: {
      company: user.customerProfile.company,
      agreement: user.customerProfile.agreement,
    },
    orders: out,
  });
}
