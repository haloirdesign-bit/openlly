import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { readFileSafe } from "@/lib/storage";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const file = await db.orderFile.findUnique({ where: { id }, include: { order: true } });
  if (!file) return NextResponse.json({ error: "File tidak ditemukan" }, { status: 404 });

  const isOwner = file.order.userId === session.sub;
  const isAdmin = session.role === "ADMIN";
  if (!isOwner && !isAdmin)
    return NextResponse.json({ error: "Akses ditolak" }, { status: 403 });

  const buf = await readFileSafe(file.storagePath);
  if (!buf) return NextResponse.json({ error: "File hilang" }, { status: 410 });

  return new NextResponse(buf as any, {
    headers: {
      "Content-Type": file.fileType || "application/octet-stream",
      "Content-Disposition": `inline; filename="${encodeURIComponent(file.fileName)}"`,
      "Cache-Control": "private, no-store",
    },
  });
}

export const runtime = "nodejs";
