import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  ORDER_STATUS_LABEL,
  ORDER_STATUS_COLOR,
  ORDER_STATUS_STEP,
} from "@/lib/types";
import { maskPhone } from "@/lib/format";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const token = searchParams.get("token");
  if (!token) return NextResponse.json({ error: "Token tidak ditemukan." }, { status: 400 });

  const order = await db.order.findUnique({
    where: { token },
    include: {
      service: true,
      statusHistory: { orderBy: { createdAt: "asc" } },
    },
  });
  if (!order) return NextResponse.json({ error: "Pesanan tidak ditemukan." }, { status: 404 });

  const history = order.statusHistory.map((h) => ({
    status: h.status,
    label: ORDER_STATUS_LABEL[h.status as keyof typeof ORDER_STATUS_LABEL] || h.status,
    note: h.note,
    createdAt: h.createdAt,
  }));

  let details: any = {};
  try { details = JSON.parse(order.details); } catch {}

  return NextResponse.json({
    order: {
      orderNumber: order.orderNumber,
      queueNumber: order.queueNumber,
      serviceType: order.serviceType,
      status: order.status,
      statusLabel: ORDER_STATUS_LABEL[order.status as keyof typeof ORDER_STATUS_LABEL] || order.status,
      statusColor: ORDER_STATUS_COLOR[order.status as keyof typeof ORDER_STATUS_COLOR] || "",
      statusStep: ORDER_STATUS_STEP[order.status as keyof typeof ORDER_STATUS_STEP] ?? 0,
      customerName: order.customerName,
      customerPhoneMasked: maskPhone(order.customerPhone),
      serviceName: order.service?.name || null,
      details,
      adminNote: order.adminNote,
      createdAt: order.createdAt,
      updatedAt: order.updatedAt,
    },
    history,
  });
}
