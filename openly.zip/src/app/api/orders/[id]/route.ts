import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";

// Full detail of one order (admin)
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  const order = await db.order.findUnique({
    where: { id },
    include: {
      service: { include: { packages: true } },
      statusHistory: { orderBy: { createdAt: "asc" }, include: { changedBy: true } },
      attachments: true,
      files: { orderBy: { createdAt: "desc" } },
      user: true,
    },
  });
  if (!order) return NextResponse.json({ error: "Tidak ditemukan" }, { status: 404 });

  let details: any = {};
  try { details = JSON.parse(order.details); } catch {}

  return NextResponse.json({
    order: {
      id: order.id,
      orderNumber: order.orderNumber,
      queueNumber: order.queueNumber,
      serviceType: order.serviceType,
      status: order.status,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerEmail: order.user?.email || null,
      userId: order.userId,
      adminNote: order.adminNote,
      createdAt: order.createdAt,
      updatedAt: order.updatedAt,
      serviceName: order.service?.name || null,
      packageId: order.packageId,
      details,
      token: order.token,
    },
    attachments: order.attachments.map((a) => ({
      id: a.id,
      fileName: a.fileName,
      fileType: a.fileType,
      fileSize: a.fileSize,
      createdAt: a.createdAt,
      storagePath: a.storagePath,
    })),
    files: order.files.map((f) => ({
      id: f.id,
      fileName: f.fileName,
      fileType: f.fileType,
      fileSize: f.fileSize,
      note: f.note,
      version: f.version,
      createdAt: f.createdAt,
    })),
    history: order.statusHistory.map((h) => ({
      id: h.id,
      status: h.status,
      note: h.note,
      createdAt: h.createdAt,
      changedBy: h.changedBy?.name || null,
    })),
  });
}
