import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateOrderNumber, generateQueueNumber, randomToken } from "@/lib/queue";
import { writeFileBuffer, validateUpload, fileExt, ALLOWED_IMAGE, MAX_UPLOAD_MB } from "@/lib/storage";
import { getSession } from "@/lib/session";

const MAX_FILES = 6;

export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const customerName = String(form.get("customerName") || "").trim();
    const customerPhone = String(form.get("customerPhone") || "").trim();
    const serviceType = String(form.get("serviceType") || "").trim();
    const serviceId = String(form.get("serviceId") || "") || null;
    const packageId = String(form.get("packageId") || "") || null;
    const detailsRaw = String(form.get("details") || "{}");

    if (!customerName || customerName.length < 2)
      return NextResponse.json({ error: "Nama pemesan wajib diisi." }, { status: 400 });
    if (!/^[0-9+\-\s]{8,18}$/.test(customerPhone))
      return NextResponse.json({ error: "Nomor WhatsApp tidak valid." }, { status: 400 });
    if (serviceType !== "GRAPHIC" && serviceType !== "WEBSITE")
      return NextResponse.json({ error: "Jenis jasa tidak valid." }, { status: 400 });

    let details: any = {};
    try {
      details = JSON.parse(detailsRaw);
    } catch {
      return NextResponse.json({ error: "Data detail tidak valid." }, { status: 400 });
    }

    // validate service if provided
    if (serviceId) {
      const svc = await db.service.findUnique({ where: { id: serviceId } });
      if (!svc || svc.type !== serviceType || !svc.active)
        return NextResponse.json({ error: "Layanan tidak valid." }, { status: 400 });
    }

    // files
    const files = form.getAll("files").filter((f): f is File => f instanceof File && f.size > 0);
    if (files.length > MAX_FILES)
      return NextResponse.json({ error: `Maksimal ${MAX_FILES} file.` }, { status: 400 });

    const session = await getSession();

    const order = await db.order.create({
      data: {
        orderNumber: await generateOrderNumber(),
        queueNumber: await generateQueueNumber(),
        serviceType,
        serviceId,
        packageId,
        customerName,
        customerPhone,
        userId: session?.sub,
        details: JSON.stringify(details),
        status: "RECEIVED",
        token: randomToken(24),
      },
    });

    // initial status history
    await db.orderStatusHistory.create({
      data: {
        orderId: order.id,
        status: "RECEIVED",
        note: "Pesanan diterima oleh sistem.",
        changedById: session?.sub,
      },
    });

    // save attachments
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const err = validateUpload(f.name, f.size);
      if (err) {
        // skip invalid file but record note
        continue;
      }
      const buf = Buffer.from(await f.arrayBuffer());
      const relPath = `orders/${order.id}/attach-${i}-${Date.now()}.${fileExt(f.name)}`;
      await writeFileBuffer(relPath.split("/"), buf);
      await db.orderAttachment.create({
        data: {
          orderId: order.id,
          fileName: f.name,
          fileType: f.type || fileExt(f.name),
          fileSize: f.size,
          storagePath: relPath,
        },
      });
    }

    // notification record (for admin)
    await db.notification.create({
      data: {
        title: "Pesanan baru",
        message: `Pesanan ${order.orderNumber} dari ${customerName} (${serviceType}).`,
        type: "INFO",
        orderId: order.id,
      },
    });

    return NextResponse.json({
      ok: true,
      orderNumber: order.orderNumber,
      queueNumber: order.queueNumber,
      token: order.token,
      serviceType,
    });
  } catch (e: any) {
    console.error("order create error", e);
    return NextResponse.json({ error: "Gagal membuat pesanan. Silakan coba lagi." }, { status: 500 });
  }
}

export const runtime = "nodejs";
