import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getContentJSON, getSettingMap } from "@/lib/content";

const ALL_SETTINGS = [
  "brand_name",
  "parent_company",
  "owner_name",
  "whatsapp",
  "whatsapp_display",
  "address",
  "email_contact",
  "instagram",
  "tiktok",
  "facebook",
  "behance",
  "footer_text",
  "nav_login_text",
  "announcement",
  "hero_slogan",
  "hero_description",
];

const SECTIONS = [
  "hero",
  "advantages",
  "services_summary_graphic",
  "services_summary_website",
  "order_flow",
  "cooperation",
  "owner",
  "faq",
  "contact",
  "testimonials",
  "review_section",
];

export async function GET() {
  const [settings, sections] = await Promise.all([
    getSettingMap(ALL_SETTINGS),
    Promise.all(SECTIONS.map(async (k) => [k, await getContentJSON(k, null)] as const)),
  ]);

  const sectionMap: Record<string, any> = {};
  for (const [k, v] of sections) sectionMap[k] = v;

  return NextResponse.json({
    settings,
    sections: sectionMap,
  });
}
