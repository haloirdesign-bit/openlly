import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";

export async function POST(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json();
  const { serviceId, name, price, priceLabel, description, features, estDuration, revision, popular, active, sortOrder } = body;
  if (!serviceId || !name) return NextResponse.json({ error: "serviceId & name wajib" }, { status: 400 });
  const pkg = await db.servicePackage.create({
    data: {
      serviceId,
      name,
      price: price ?? null,
      priceLabel: priceLabel || null,
      description: description || null,
      features: JSON.stringify(features || []),
      estDuration: estDuration || null,
      revision: revision || null,
      popular: popular ?? false,
      active: active ?? true,
      sortOrder: sortOrder ?? 0,
    },
  });
  return NextResponse.json({ package: pkg });
}

export async function PATCH(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json();
  const { id, ...data } = body;
  if (!id) return NextResponse.json({ error: "ID wajib" }, { status: 400 });
  const update: any = { ...data };
  if (Array.isArray(update.features)) update.features = JSON.stringify(update.features);
  delete update.id;
  const pkg = await db.servicePackage.update({ where: { id }, data: update });
  return NextResponse.json({ package: pkg });
}

export async function DELETE(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await req.json();
  await db.servicePackage.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
