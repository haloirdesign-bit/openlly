import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";
import { ORDER_STATUS_LABEL, ORDER_STATUS_COLOR, ORDER_STATUS_STEP } from "@/lib/types";

export async function GET(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");
  const type = searchParams.get("type");
  const q = searchParams.get("q");

  const where: any = {};
  if (status) where.status = status;
  if (type === "GRAPHIC" || type === "WEBSITE") where.serviceType = type;
  if (q) where.OR = [
    { orderNumber: { contains: q } },
    { customerName: { contains: q } },
    { customerPhone: { contains: q } },
  ];

  const orders = await db.order.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { service: true },
  });

  const out = orders.map((o) => ({
    id: o.id,
    orderNumber: o.orderNumber,
    queueNumber: o.queueNumber,
    serviceType: o.serviceType,
    serviceName: o.service?.name || null,
    customerName: o.customerName,
    customerPhone: o.customerPhone,
    userId: o.userId,
    status: o.status,
    statusLabel: ORDER_STATUS_LABEL[o.status as keyof typeof ORDER_STATUS_LABEL] || o.status,
    statusColor: ORDER_STATUS_COLOR[o.status as keyof typeof ORDER_STATUS_COLOR] || "",
    statusStep: ORDER_STATUS_STEP[o.status as keyof typeof ORDER_STATUS_STEP] ?? 0,
    adminNote: o.adminNote,
    createdAt: o.createdAt,
    updatedAt: o.updatedAt,
  }));

  return NextResponse.json({ orders: out });
}

export async function PATCH(req: Request) {
  let session;
  try {
    session = await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id, status, adminNote } = await req.json();
  if (!id) return NextResponse.json({ error: "ID wajib" }, { status: 400 });

  const data: any = {};
  if (status) data.status = status;
  if (adminNote !== undefined) data.adminNote = adminNote || null;

  const updated = await db.order.update({ where: { id }, data });

  if (status) {
    await db.orderStatusHistory.create({
      data: {
        orderId: id,
        status,
        note: adminNote || undefined,
        changedById: session.sub,
      },
    });
    // create notification for the owning customer
    const order = await db.order.findUnique({ where: { id } });
    if (order?.userId) {
      await db.notification.create({
        data: {
          userId: order.userId,
          orderId: id,
          title: "Status pesanan diperbarui",
          message: `Pesanan ${order.orderNumber}: ${ORDER_STATUS_LABEL[status as keyof typeof ORDER_STATUS_LABEL] || status}.`,
          type: "STATUS",
        },
      });
    }
  }

  return NextResponse.json({ ok: true, order: updated });
}
