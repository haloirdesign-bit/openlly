import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";
import { hashPassword } from "@/lib/auth";
import { randomBytes } from "crypto";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const users = await db.user.findMany({
    where: { role: "CUSTOMER" },
    orderBy: { createdAt: "desc" },
    include: { customerProfile: true, orders: { select: { id: true } } },
  });
  const out = users.map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    phone: u.phone,
    active: u.active,
    createdAt: u.createdAt,
    ordersCount: u.orders.length,
    profile: u.customerProfile
      ? {
          company: u.customerProfile.company,
          agreement: u.customerProfile.agreement,
          activatedAt: u.customerProfile.activatedAt,
        }
      : null,
  }));
  return NextResponse.json({ customers: out });
}

// Create/invite a cooperation customer
export async function POST(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { name, email, phone, password, company, agreement, active } = await req.json();
  if (!name || !email || !password) return NextResponse.json({ error: "Nama, email, password wajib" }, { status: 400 });
  const existing = await db.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) return NextResponse.json({ error: "Email sudah terdaftar" }, { status: 400 });

  const user = await db.user.create({
    data: {
      name,
      email: email.toLowerCase(),
      phone: phone || null,
      passwordHash: await hashPassword(password),
      role: "CUSTOMER",
      active: active ?? true,
    },
  });
  const profile = await db.customerProfile.create({
    data: {
      userId: user.id,
      company: company || null,
      agreement: agreement || null,
      activatedAt: active ? new Date() : null,
    },
  });
  return NextResponse.json({ user, profile });
}

export async function PATCH(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id, name, phone, active, password, company, agreement } = await req.json();
  if (!id) return NextResponse.json({ error: "ID wajib" }, { status: 400 });
  const data: any = {};
  if (name !== undefined) data.name = name;
  if (phone !== undefined) data.phone = phone;
  if (active !== undefined) data.active = active;
  if (password) data.passwordHash = await hashPassword(password);

  const user = await db.user.update({ where: { id }, data });

  if (company !== undefined || agreement !== undefined) {
    await db.customerProfile.upsert({
      where: { userId: id },
      update: {
        ...(company !== undefined ? { company } : {}),
        ...(agreement !== undefined ? { agreement } : {}),
        ...(active && !user.active ? { activatedAt: new Date() } : {}),
      },
      create: {
        userId: id,
        company: company || null,
        agreement: agreement || null,
        activatedAt: active ? new Date() : null,
      },
    });
    if (active) {
      await db.customerProfile.updateMany({ where: { userId: id }, data: { activatedAt: new Date() } });
    }
  }
  return NextResponse.json({ ok: true });
}
