import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const [
    totalOrders,
    pendingOrders,
    inProgress,
    completed,
    cancelled,
    graphicServices,
    websiteServices,
    customers,
    cooperation,
    todayCount,
  ] = await Promise.all([
    db.order.count(),
    db.order.count({ where: { status: { in: ["RECEIVED", "WAITING_CONFIRM", "WAITING_PAYMENT"] } } }),
    db.order.count({ where: { status: { in: ["QUEUED", "IN_PROGRESS", "WAITING_APPROVAL", "REVISION"] } } }),
    db.order.count({ where: { status: "COMPLETED" } }),
    db.order.count({ where: { status: "CANCELLED" } }),
    db.service.count({ where: { type: "GRAPHIC" } }),
    db.service.count({ where: { type: "WEBSITE" } }),
    db.user.count({ where: { role: "CUSTOMER" } }),
    db.customerProfile.count(),
    db.order.count({ where: { createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } } }),
  ]);

  // recent orders
  const recent = await db.order.findMany({
    take: 6,
    orderBy: { createdAt: "desc" },
    include: { service: true },
  });

  // last 7 days counts
  const days: { date: string; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - i);
    const end = new Date(start);
    end.setHours(23, 59, 59, 999);
    const count = await db.order.count({ where: { createdAt: { gte: start, lte: end } } });
    days.push({ date: start.toISOString().slice(0, 10), count });
  }

  return NextResponse.json({
    stats: {
      totalOrders,
      pendingOrders,
      inProgress,
      completed,
      cancelled,
      graphicServices,
      websiteServices,
      customers,
      cooperation,
      todayCount,
    },
    recent: recent.map((o) => ({
      id: o.id,
      orderNumber: o.orderNumber,
      queueNumber: o.queueNumber,
      serviceType: o.serviceType,
      serviceName: o.service?.name || null,
      customerName: o.customerName,
      status: o.status,
      createdAt: o.createdAt,
    })),
    chart: days,
  });
}
