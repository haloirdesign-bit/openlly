import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";
import { setSetting } from "@/lib/content";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const rows = await db.siteSetting.findMany({ orderBy: { key: "asc" } });
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value;
  return NextResponse.json({ settings: map });
}

export async function PATCH(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { key, value } = await req.json();
  if (!key) return NextResponse.json({ error: "key wajib" }, { status: 400 });
  await setSetting(key, String(value ?? ""));
  return NextResponse.json({ ok: true });
}

export async function POST(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { settings } = await req.json();
  if (!settings || typeof settings !== "object")
    return NextResponse.json({ error: "settings wajib" }, { status: 400 });
  for (const [k, v] of Object.entries(settings)) {
    await setSetting(k, String(v ?? ""));
  }
  return NextResponse.json({ ok: true });
}
