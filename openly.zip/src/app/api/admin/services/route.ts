import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";
import { randomBytes } from "crypto";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const services = await db.service.findMany({
    orderBy: [{ type: "asc" }, { sortOrder: "asc" }],
    include: { packages: { orderBy: { sortOrder: "asc" } } },
  });
  const out = services.map((s) => ({
    id: s.id,
    type: s.type,
    niche: s.niche,
    name: s.name,
    slug: s.slug,
    description: s.description,
    image: s.image,
    priceLabel: s.priceLabel,
    priceFrom: s.priceFrom,
    estDuration: s.estDuration,
    revision: s.revision,
    options: s.options ? JSON.parse(s.options) : null,
    sortOrder: s.sortOrder,
    active: s.active,
    packages: s.packages.map((p) => ({
      id: p.id,
      name: p.name,
      price: p.price,
      priceLabel: p.priceLabel,
      description: p.description,
      features: p.features ? JSON.parse(p.features) : [],
      estDuration: p.estDuration,
      revision: p.revision,
      popular: p.popular,
      active: p.active,
      sortOrder: p.sortOrder,
    })),
  }));
  return NextResponse.json({ services: out });
}

export async function POST(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json();
  const { type, niche, name, description, priceLabel, priceFrom, estDuration, revision, options, sortOrder, active, slug } = body;
  if (!name || !type) return NextResponse.json({ error: "Nama & tipe wajib" }, { status: 400 });
  const finalSlug = slug || name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const svc = await db.service.create({
    data: {
      type,
      niche: niche || null,
      name,
      slug: finalSlug + "-" + randomBytes(3).toString("hex"),
      description: description || "",
      priceLabel: priceLabel || null,
      priceFrom: priceFrom ?? null,
      estDuration: estDuration || null,
      revision: revision || null,
      options: options ? JSON.stringify(options) : null,
      sortOrder: sortOrder ?? 0,
      active: active ?? true,
    },
  });
  return NextResponse.json({ service: svc });
}

export async function PATCH(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json();
  const { id, ...data } = body;
  if (!id) return NextResponse.json({ error: "ID wajib" }, { status: 400 });
  const update: any = { ...data };
  if (Array.isArray(update.options)) update.options = JSON.stringify(update.options);
  if (update.niche === "") update.niche = null;
  delete update.id;
  delete update.slug; // don't change slug
  const svc = await db.service.update({ where: { id }, data: update });
  return NextResponse.json({ service: svc });
}

export async function DELETE(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await req.json();
  await db.service.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
