import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";
import { setContent, getContent } from "@/lib/content";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const rows = await db.contentSection.findMany({ orderBy: { key: "asc" } });
  const map: Record<string, any> = {};
  for (const r of rows) {
    try { map[r.key] = JSON.parse(r.value); } catch { map[r.key] = r.value; }
  }
  return NextResponse.json({ sections: map });
}

export async function PATCH(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { key, value } = await req.json();
  if (!key) return NextResponse.json({ error: "key wajib" }, { status: 400 });
  const serialized = typeof value === "string" ? value : JSON.stringify(value);
  await setContent(key, serialized);
  return NextResponse.json({ ok: true });
}
