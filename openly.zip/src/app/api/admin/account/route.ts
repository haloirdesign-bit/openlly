import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, getSession } from "@/lib/session";
import { hashPassword } from "@/lib/auth";

export async function GET() {
  try {
    const session = await requireAdmin();
    const user = await db.user.findUnique({ where: { id: session.sub } });
    if (!user) return NextResponse.json({ error: "Tidak ditemukan" }, { status: 404 });
    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        phone: user.phone,
        createdAt: user.createdAt,
      },
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PATCH(req: Request) {
  let session;
  try {
    session = await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { name, password } = await req.json();
  const data: any = {};
  if (name && typeof name === "string" && name.trim()) data.name = name.trim();
  if (password && typeof password === "string" && password.length >= 6) {
    data.passwordHash = await hashPassword(password);
  }
  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "Tidak ada perubahan" }, { status: 400 });
  }
  const user = await db.user.update({ where: { id: session.sub }, data });
  return NextResponse.json({
    ok: true,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      phone: user.phone,
    },
  });
}
