import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const notifications = await db.notification.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { order: { select: { orderNumber: true } }, user: { select: { name: true, email: true } } },
  });
  return NextResponse.json({
    notifications: notifications.map((n) => ({
      id: n.id,
      title: n.title,
      message: n.message,
      type: n.type,
      read: n.read,
      createdAt: n.createdAt,
      userName: n.user?.name || null,
      orderNumber: n.order?.orderNumber || null,
    })),
  });
}

// Broadcast / send notification
export async function POST(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { title, message, userId, broadcast, type } = await req.json();
  if (!title || !message) return NextResponse.json({ error: "title & message wajib" }, { status: 400 });
  if (broadcast) {
    const users = await db.user.findMany({ where: { role: "CUSTOMER", active: true } });
    await db.notification.createMany({
      data: users.map((u) => ({ userId: u.id, title, message, type: type || "INFO" })),
    });
    return NextResponse.json({ ok: true, sent: users.length });
  }
  if (!userId) return NextResponse.json({ error: "userId wajib (atau set broadcast=true)" }, { status: 400 });
  const n = await db.notification.create({ data: { userId, title, message, type: type || "INFO" } });
  return NextResponse.json({ ok: true, notification: n });
}
