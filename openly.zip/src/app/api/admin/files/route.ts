import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/session";
import { writeFileBuffer, validateUpload, fileExt, deleteFileSafe, storageDir } from "@/lib/storage";
import { getSession } from "@/lib/session";
import fs from "fs/promises";
import path from "path";

// List files for an order
export async function GET(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { searchParams } = new URL(req.url);
  const orderId = searchParams.get("orderId");
  if (!orderId) return NextResponse.json({ files: [], attachments: [] });
  const [files, attachments] = await Promise.all([
    db.orderFile.findMany({ where: { orderId }, orderBy: { createdAt: "desc" } }),
    db.orderAttachment.findMany({ where: { orderId }, orderBy: { createdAt: "desc" } }),
  ]);
  return NextResponse.json({
    files: files.map((f) => ({ id: f.id, fileName: f.fileName, fileType: f.fileType, fileSize: f.fileSize, note: f.note, version: f.version, createdAt: f.createdAt })),
    attachments: attachments.map((a) => ({ id: a.id, fileName: a.fileName, fileType: a.fileType, fileSize: a.fileSize, createdAt: a.createdAt, storagePath: a.storagePath })),
  });
}

// Upload result file(s) for an order
export async function POST(req: Request) {
  let session;
  try {
    session = await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const form = await req.formData();
  const orderId = String(form.get("orderId") || "");
  const note = String(form.get("note") || "");
  if (!orderId) return NextResponse.json({ error: "orderId wajib" }, { status: 400 });

  const order = await db.order.findUnique({ where: { id: orderId } });
  if (!order) return NextResponse.json({ error: "Pesanan tidak ditemukan" }, { status: 404 });

  const files = form.getAll("files").filter((f): f is File => f instanceof File && f.size > 0);
  if (files.length === 0) return NextResponse.json({ error: "Tidak ada file" }, { status: 400 });

  const created: any[] = [];
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const err = validateUpload(f.name, f.size);
    if (err) continue;
    const buf = Buffer.from(await f.arrayBuffer());
    const relPath = `results/${orderId}/${Date.now()}-${i}-${f.name}`;
    await writeFileBuffer(relPath.split("/"), buf);
    const fileRec = await db.orderFile.create({
      data: {
        orderId,
        uploadedById: session.sub,
        fileName: f.name,
        fileType: f.type || fileExt(f.name),
        fileSize: f.size,
        storagePath: relPath,
        note: note || null,
      },
    });
    created.push(fileRec);
  }

  // notify customer
  if (order.userId) {
    await db.notification.create({
      data: {
        userId: order.userId,
        orderId,
        title: "File hasil pekerjaan tersedia",
        message: `File hasil untuk pesanan ${order.orderNumber} telah diunggah.`,
        type: "INFO",
      },
    });
  }

  return NextResponse.json({ ok: true, files: created });
}

export async function DELETE(req: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await req.json();
  const file = await db.orderFile.findUnique({ where: { id } });
  if (!file) return NextResponse.json({ error: "Tidak ditemukan" }, { status: 404 });
  await deleteFileSafe(file.storagePath);
  await db.orderFile.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}

export const runtime = "nodejs";
