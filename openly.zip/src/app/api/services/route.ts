import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { ServiceDTO } from "@/lib/types";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const type = searchParams.get("type"); // GRAPHIC | WEBSITE | BUNDLE
  const niche = searchParams.get("niche"); // niche id
  const where: any = { active: true };
  if (type === "GRAPHIC" || type === "WEBSITE" || type === "BUNDLE") where.type = type;
  if (niche === "general") {
    where.niche = null;
  } else if (niche) {
    where.niche = niche;
  }

  const services = await db.service.findMany({
    where,
    orderBy: { sortOrder: "asc" },
    include: {
      packages: {
        where: { active: true },
        orderBy: { sortOrder: "asc" },
      },
    },
  });

  const out: ServiceDTO[] = services.map((s) => ({
    id: s.id,
    type: s.type as "GRAPHIC" | "WEBSITE" | "BUNDLE",
    niche: s.niche,
    name: s.name,
    slug: s.slug,
    description: s.description,
    image: s.image,
    priceLabel: s.priceLabel,
    priceFrom: s.priceFrom,
    estDuration: s.estDuration,
    revision: s.revision,
    options: s.options ? JSON.parse(s.options) : null,
    sortOrder: s.sortOrder,
    active: s.active,
    packages: s.packages.map((p) => ({
      id: p.id,
      serviceId: p.serviceId,
      name: p.name,
      price: p.price,
      priceLabel: p.priceLabel,
      description: p.description,
      features: p.features ? JSON.parse(p.features) : [],
      estDuration: p.estDuration,
      revision: p.revision,
      popular: p.popular,
      active: p.active,
      sortOrder: p.sortOrder,
    })),
  }));

  return NextResponse.json({ services: out });
}
