import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ notifications: [] });

  const { searchParams } = new URL(req.url);
  const onlyUnread = searchParams.get("unread") === "1";

  const notifications = await db.notification.findMany({
    where: {
      AND: [
        { OR: [{ userId: session.sub }, { userId: null }] },
        ...(onlyUnread ? [{ read: false }] : []),
      ],
    },
    orderBy: { createdAt: "desc" },
    take: 30,
  });

  return NextResponse.json({ notifications });
}

export async function PATCH(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id, all } = await req.json();
  if (all) {
    await db.notification.updateMany({ where: { userId: session.sub, read: false }, data: { read: true } });
    return NextResponse.json({ ok: true });
  }
  if (id) {
    await db.notification.updateMany({ where: { id, userId: session.sub }, data: { read: true } });
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: "Noop" }, { status: 400 });
}
