"use client";

import { create } from "zustand";

export type RouteView =
  | "beranda"
  | "jasa-desain"
  | "jasa-website"
  | "niche"
  | "pricelist"
  | "review"
  | "cara-pemesanan"
  | "tentang"
  | "kontak"
  | "login"
  | "order"
  | "track"
  | "confirmation"
  | "portal"
  | "admin";

export interface RouteState {
  view: RouteView;
  params: Record<string, string>;
}

interface RouterStore extends RouteState {
  navigate: (view: RouteView, params?: Record<string, string>) => void;
  setFromHash: () => void;
}

function readHash(): { view: RouteView; params: Record<string, string> } {
  const hash = typeof window !== "undefined" ? window.location.hash.replace(/^#\/?/, "") : "";
  const [path, query] = hash.split("?");
  const view = (path || "beranda") as RouteView;
  const params: Record<string, string> = {};
  if (query) {
    new URLSearchParams(query).forEach((v, k) => (params[k] = v));
  }
  return { view, params };
}

export const useRouter = create<RouterStore>((set) => ({
  view: "beranda",
  params: {},
  navigate: (view, params = {}) => {
    if (typeof window !== "undefined") {
      const qs = new URLSearchParams(params).toString();
      window.location.hash = `/${view}${qs ? `?${qs}` : ""}`;
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    }
    set({ view, params });
  },
  setFromHash: () => {
    const { view, params } = readHash();
    set({ view, params });
  },
}));

export const PUBLIC_VIEWS: RouteView[] = [
  "beranda",
  "jasa-desain",
  "jasa-website",
  "niche",
  "pricelist",
  "review",
  "cara-pemesanan",
  "tentang",
  "kontak",
  "login",
  "order",
  "track",
  "confirmation",
  "portal",
  "admin",
];
