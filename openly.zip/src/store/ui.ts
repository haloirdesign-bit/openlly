"use client";

import { create } from "zustand";

interface UIStore {
  mobileNavOpen: boolean;
  setMobileNavOpen: (v: boolean) => void;
  ttsEnabled: boolean;
  setTtsEnabled: (v: boolean) => void;
  toggleTts: () => void;
}

export const useUI = create<UIStore>((set, get) => ({
  mobileNavOpen: false,
  setMobileNavOpen: (v) => set({ mobileNavOpen: v }),
  ttsEnabled: false,
  setTtsEnabled: (v) => set({ ttsEnabled: v }),
  toggleTts: () => set({ ttsEnabled: !get().ttsEnabled }),
}));
