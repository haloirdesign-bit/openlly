"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  Pencil,
  Save,
  X,
  Loader2,
  Star,
  Trash2,
} from "lucide-react";
import type { ServiceDTO, PackageDTO } from "@/lib/types";
import { formatIDR } from "@/lib/format";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface FlatPackage extends PackageDTO {
  serviceId: string;
  serviceName: string;
  serviceType: "GRAPHIC" | "WEBSITE";
}

interface PkgForm {
  name: string;
  price: string;
  priceLabel: string;
  description: string;
  features: string;
  estDuration: string;
  revision: string;
  popular: boolean;
  active: boolean;
  sortOrder: string;
}

const EMPTY_PKG: PkgForm = {
  name: "",
  price: "",
  priceLabel: "",
  description: "",
  features: "",
  estDuration: "",
  revision: "",
  popular: false,
  active: true,
  sortOrder: "0",
};

export function PackagesPage() {
  const [pkgs, setPkgs] = useState<FlatPackage[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<FlatPackage | null>(null);
  const [form, setForm] = useState<PkgForm>(EMPTY_PKG);
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState<string>("ALL");
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/services");
      const data = await res.json();
      const flat: FlatPackage[] = [];
      (data.services || []).forEach((s: ServiceDTO) => {
        (s.packages || []).forEach((p: PackageDTO) => {
          flat.push({
            ...p,
            serviceId: s.id,
            serviceName: s.name,
            serviceType: s.type as "GRAPHIC" | "WEBSITE",
          });
        });
      });
      flat.sort((a, b) => a.serviceName.localeCompare(b.serviceName) || a.sortOrder - b.sortOrder);
      setPkgs(flat);
    } catch {
      toast.error("Gagal memuat paket.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openEdit = (p: FlatPackage) => {
    setEditing(p);
    setForm({
      name: p.name,
      price: p.price != null ? String(p.price) : "",
      priceLabel: p.priceLabel || "",
      description: p.description || "",
      features: Array.isArray(p.features) ? p.features.join("\n") : "",
      estDuration: p.estDuration || "",
      revision: p.revision || "",
      popular: p.popular,
      active: p.active,
      sortOrder: String(p.sortOrder ?? 0),
    });
    setOpen(true);
  };

  const submit = async () => {
    if (!editing) return;
    if (!form.name.trim()) {
      toast.error("Nama paket wajib.");
      return;
    }
    setSaving(true);
    try {
      const body: any = {
        id: editing.id,
        name: form.name.trim(),
        price: form.price ? Number(form.price) : null,
        priceLabel: form.priceLabel.trim() || null,
        description: form.description.trim() || null,
        features: form.features
          .split("\n")
          .map((s) => s.trim())
          .filter(Boolean),
        estDuration: form.estDuration.trim() || null,
        revision: form.revision.trim() || null,
        popular: form.popular,
        active: form.active,
        sortOrder: Number(form.sortOrder) || 0,
      };
      const res = await fetch("/api/admin/packages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal menyimpan.");
        return;
      }
      toast.success("Paket diperbarui.");
      setOpen(false);
      load();
    } catch {
      toast.error("Gagal menyimpan.");
    } finally {
      setSaving(false);
    }
  };

  const togglePopular = async (p: FlatPackage) => {
    try {
      await fetch("/api/admin/packages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: p.id, popular: !p.popular }),
      });
      load();
    } catch {
      toast.error("Gagal mengubah paket.");
    }
  };

  const confirmDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch("/api/admin/packages", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: deleteId }),
      });
      toast.success("Paket dihapus.");
      setDeleteId(null);
      load();
    } catch {
      toast.error("Gagal menghapus.");
    }
  };

  const filtered =
    filter === "ALL" ? pkgs : pkgs.filter((p) => p.serviceType === filter);

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">Total Paket</p>
            <p className="text-2xl font-bold">{pkgs.length} paket</p>
          </div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Semua Layanan</SelectItem>
              <SelectItem value="GRAPHIC">Desain Grafis</SelectItem>
              <SelectItem value="WEBSITE">Website</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="border-b">
          <CardTitle className="text-base">Daftar Paket</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {loading ? (
            <div className="space-y-2 p-2">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              Belum ada paket.
            </div>
          ) : (
            <div className="max-h-[65vh] overflow-y-auto openly-scroll">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow>
                    <TableHead>Nama Paket</TableHead>
                    <TableHead>Layanan</TableHead>
                    <TableHead>Harga</TableHead>
                    <TableHead>Label</TableHead>
                    <TableHead>Populer</TableHead>
                    <TableHead>Aktif</TableHead>
                    <TableHead>Urutan</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.name}</TableCell>
                      <TableCell className="text-xs">
                        <div>{p.serviceName}</div>
                        <Badge variant="outline" className="text-[10px] mt-0.5">
                          {p.serviceType === "GRAPHIC" ? "Desain" : "Website"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs">
                        {p.price != null ? formatIDR(p.price) : "—"}
                      </TableCell>
                      <TableCell className="text-xs">{p.priceLabel || "—"}</TableCell>
                      <TableCell>
                        <Switch
                          checked={p.popular}
                          onCheckedChange={() => togglePopular(p)}
                          aria-label="Toggle popular"
                        />
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            p.active
                              ? "bg-emerald-100 text-emerald-700 border-emerald-200"
                              : "bg-zinc-100 text-zinc-500 border-zinc-200"
                          )}
                        >
                          {p.active ? "Aktif" : "Nonaktif"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs">{p.sortOrder}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex gap-1 justify-end">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openEdit(p)}
                          >
                            <Pencil className="size-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setDeleteId(p.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base">Edit Paket</DialogTitle>
            <DialogDescription className="sr-only">Form edit paket</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto openly-scroll pr-1">
            <div className="space-y-1.5">
              <Label>Nama Paket</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Harga (Rp)</Label>
                <Input
                  type="number"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Label Harga</Label>
                <Input
                  value={form.priceLabel}
                  onChange={(e) => setForm({ ...form, priceLabel: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Deskripsi</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={2}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Fitur (satu per baris)</Label>
              <Textarea
                value={form.features}
                onChange={(e) => setForm({ ...form, features: e.target.value })}
                rows={5}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Estimasi Durasi</Label>
                <Input
                  value={form.estDuration}
                  onChange={(e) => setForm({ ...form, estDuration: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Revisi</Label>
                <Input
                  value={form.revision}
                  onChange={(e) => setForm({ ...form, revision: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Urutan</Label>
                <Input
                  type="number"
                  value={form.sortOrder}
                  onChange={(e) => setForm({ ...form, sortOrder: e.target.value })}
                />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch
                  checked={form.popular}
                  onCheckedChange={(v) => setForm({ ...form, popular: v })}
                />
                <Label className="text-sm flex items-center gap-1">
                  <Star className="size-3" /> Populer
                </Label>
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch
                  checked={form.active}
                  onCheckedChange={(v) => setForm({ ...form, active: v })}
                />
                <Label className="text-sm">Aktif</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              <X className="size-4" /> Batal
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus paket?</AlertDialogTitle>
            <AlertDialogDescription>
              Paket ini akan dihapus permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
