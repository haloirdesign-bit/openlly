"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Save, Loader2, ShieldCheck, UserCog, Mail, Lock } from "lucide-react";
import { useSession } from "@/hooks/use-session";

interface AccountInfo {
  id: string;
  email: string;
  name: string;
  role: string;
  phone: string | null;
  createdAt: string;
}

export function AccountPage() {
  const { user, refresh } = useSession();
  const [info, setInfo] = useState<AccountInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/account");
      if (!res.ok) {
        toast.error("Gagal memuat akun.");
        return;
      }
      const data = await res.json();
      setInfo(data.user || null);
      setName(data.user?.name || "");
    } catch {
      toast.error("Gagal memuat akun.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    if (!name.trim()) {
      toast.error("Nama tidak boleh kosong.");
      return;
    }
    if (password && password !== confirmPassword) {
      toast.error("Konfirmasi password tidak cocok.");
      return;
    }
    if (password && password.length < 6) {
      toast.error("Password minimal 6 karakter.");
      return;
    }
    setSaving(true);
    try {
      const body: any = { name: name.trim() };
      if (password) body.password = password;
      const res = await fetch("/api/admin/account", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal menyimpan.");
        return;
      }
      toast.success("Akun diperbarui.");
      setPassword("");
      setConfirmPassword("");
      refresh();
      load();
    } catch {
      toast.error("Gagal menyimpan.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-3 max-w-2xl">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-3xl">
      {/* Account header card */}
      <Card>
        <CardContent className="p-5">
          <div className="flex items-center gap-4">
            <div className="inline-flex size-16 items-center justify-center rounded-full openly-gradient text-white text-2xl font-bold">
              {(info?.name || user?.name || "A").charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="text-lg font-bold truncate">{info?.name || user?.name || "—"}</p>
              <p className="text-sm text-muted-foreground truncate flex items-center gap-1.5">
                <Mail className="size-3.5" /> {info?.email || user?.email || "—"}
              </p>
              <div className="flex items-center gap-2 mt-1">
                <Badge className="openly-gradient text-white border-transparent">
                  <ShieldCheck className="size-3" /> Administrator
                </Badge>
                {info?.phone && (
                  <Badge variant="outline" className="text-xs">
                    {info.phone}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Edit form */}
      <Card>
        <CardHeader className="border-b">
          <CardTitle className="text-base flex items-center gap-2">
            <UserCog className="size-4 text-primary" /> Edit Akun
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4 space-y-4">
          <div className="space-y-1.5">
            <Label>Nama</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nama admin"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input value={info?.email || ""} disabled />
            <p className="text-xs text-muted-foreground">Email tidak dapat diubah.</p>
          </div>
          <div className="border-t border-border/60 pt-4 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold">
              <Lock className="size-4 text-primary" /> Ubah Password
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Password Baru</Label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Konfirmasi Password</Label>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Kosongkan jika tidak ingin mengubah password. Minimal 6 karakter.
            </p>
          </div>
          <div className="flex justify-end">
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              Simpan Perubahan
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
