"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Volume2, VolumeX, Loader2, RefreshCw, ArrowRight } from "lucide-react";
import {
  ORDER_STATUSES,
  ORDER_STATUS_LABEL,
  ORDER_STATUS_COLOR,
  type OrderStatus,
} from "@/lib/types";
import { cn } from "@/lib/utils";
import { useUI } from "@/store/ui";
import { StatusTimeline } from "@/components/openly/status-timeline";

interface QueueOrder {
  id: string;
  orderNumber: string;
  queueNumber: string;
  serviceType: "GRAPHIC" | "WEBSITE";
  serviceName: string | null;
  customerName: string;
  customerPhone: string;
  status: OrderStatus;
  createdAt: string;
}

function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "id-ID";
    u.rate = 1;
    u.pitch = 1;
    const voices = window.speechSynthesis.getVoices();
    const id = voices.find((v) => v.lang?.toLowerCase().startsWith("id"));
    if (id) u.voice = id;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  } catch {
    /* ignore */
  }
}

const QUICK_ACTIONS: { value: OrderStatus; label: string }[] = [
  { value: "IN_PROGRESS", label: "Mulai Proses" },
  { value: "WAITING_APPROVAL", label: "Mintakan Persetujuan" },
  { value: "COMPLETED", label: "Tandai Selesai" },
];

export function QueuePage() {
  const { ttsEnabled, toggleTts } = useUI();
  const [orders, setOrders] = useState<QueueOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/orders?status=QUEUED");
      const d1 = await res.json();
      const res2 = await fetch("/api/admin/orders?status=IN_PROGRESS");
      const d2 = await res2.json();
      const list = [
        ...(d1.orders || []),
        ...(d2.orders || []),
      ] as QueueOrder[];
      // sort by queue number asc
      list.sort((a, b) => a.queueNumber.localeCompare(b.queueNumber));
      setOrders(list);
    } catch {
      toast.error("Gagal memuat antrean.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const updateStatus = async (o: QueueOrder, newStatus: OrderStatus) => {
    setUpdatingId(o.id);
    try {
      const res = await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: o.id, status: newStatus }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal memperbarui status.");
        return;
      }
      toast.success(`Pesanan ${o.orderNumber}: ${ORDER_STATUS_LABEL[newStatus]}.`);
      if (ttsEnabled) {
        const labelMap: Record<string, string> = {
          IN_PROGRESS: "sedang diproses",
          WAITING_APPROVAL: "menunggu persetujuan pelanggan",
          COMPLETED: "selesai",
        };
        speak(`Nomor antrean ${o.queueNumber}, pesanan ${labelMap[newStatus] || ORDER_STATUS_LABEL[newStatus]}.`);
      }
      load();
    } catch {
      toast.error("Gagal memperbarui status.");
    } finally {
      setUpdatingId(null);
    }
  };

  const todayCount = orders.filter((o) => {
    const today = new Date();
    const d = new Date(o.createdAt);
    return (
      d.getDate() === today.getDate() &&
      d.getMonth() === today.getMonth() &&
      d.getFullYear() === today.getFullYear()
    );
  }).length;

  const queued = orders.filter((o) => o.status === "QUEUED");
  const inProgress = orders.filter((o) => o.status === "IN_PROGRESS");

  return (
    <div className="space-y-4">
      {/* Header actions */}
      <Card>
        <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-4">
            <div>
              <p className="text-xs text-muted-foreground">Total Antrean Aktif</p>
              <p className="text-2xl font-bold">{orders.length}</p>
            </div>
            <div className="h-10 w-px bg-border/60" />
            <div>
              <p className="text-xs text-muted-foreground">Hari Ini</p>
              <p className="text-2xl font-bold text-primary">{todayCount}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={ttsEnabled ? "default" : "outline"}
              size="sm"
              onClick={toggleTts}
            >
              {ttsEnabled ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
              TTS {ttsEnabled ? "Aktif" : "Nonaktif"}
            </Button>
            <Button variant="outline" size="sm" onClick={load} disabled={loading}>
              <RefreshCw className={cn("size-4", loading && "animate-spin")} /> Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground">
        {ttsEnabled
          ? "🔊 TTS diaktifkan — pengumuman suara akan diputar saat status pesanan diubah."
          : "🔇 TTS dinonaktifkan — klik tombol di atas untuk mengaktifkan pengumuman suara."}
      </p>

      {/* Queue board */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-44 w-full rounded-xl" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <p className="text-sm text-muted-foreground">
              Tidak ada pesanan dalam antrean. 🎉
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {queued.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold mb-2 text-muted-foreground">
                Dalam Antrean ({queued.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {queued.map((o) => (
                  <QueueCard
                    key={o.id}
                    order={o}
                    updating={updatingId === o.id}
                    onAction={(s) => updateStatus(o, s)}
                  />
                ))}
              </div>
            </div>
          )}
          {inProgress.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold mb-2 mt-4 text-muted-foreground">
                Sedang Dikerjakan ({inProgress.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {inProgress.map((o) => (
                  <QueueCard
                    key={o.id}
                    order={o}
                    updating={updatingId === o.id}
                    onAction={(s) => updateStatus(o, s)}
                  />
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

interface QueueCardProps {
  order: QueueOrder;
  updating: boolean;
  onAction: (s: OrderStatus) => void;
}

function QueueCard({ order, updating, onAction }: QueueCardProps) {
  const nextAction: OrderStatus =
    order.status === "QUEUED"
      ? "IN_PROGRESS"
      : order.status === "IN_PROGRESS"
      ? "WAITING_APPROVAL"
      : "COMPLETED";

  return (
    <Card className="overflow-hidden">
      <div className="relative bg-card p-4">
        <div className="absolute top-0 right-0 left-0 h-1 openly-gradient" />
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-black openly-text-gradient">
                {order.queueNumber}
              </span>
              <span className="text-xs text-muted-foreground">/{order.orderNumber}</span>
            </div>
            <p className="text-sm font-medium truncate mt-1">{order.customerName}</p>
            <p className="text-xs text-muted-foreground truncate">
              {order.serviceName || (order.serviceType === "GRAPHIC" ? "Desain Grafis" : "Website")}
            </p>
          </div>
          <Badge
            variant="outline"
            className={cn("text-xs shrink-0", ORDER_STATUS_COLOR[order.status])}
          >
            {ORDER_STATUS_LABEL[order.status]}
          </Badge>
        </div>

        <div className="mt-3">
          <StatusTimeline current={order.status} compact />
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <Button
            size="sm"
            onClick={() => onAction(nextAction)}
            disabled={updating}
            className="flex-1 min-w-[140px]"
          >
            {updating ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <>
                {ORDER_STATUS_LABEL[nextAction]}
                <ArrowRight className="size-4" />
              </>
            )}
          </Button>
          {order.status === "QUEUED" && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onAction("WAITING_APPROVAL")}
              disabled={updating}
            >
              Skip →
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
