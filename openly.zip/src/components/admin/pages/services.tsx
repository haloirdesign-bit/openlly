"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  Plus,
  Pencil,
  Trash2,
  Package,
  Loader2,
  ChevronDown,
  ChevronRight,
  Save,
  X,
} from "lucide-react";
import type { ServiceDTO, PackageDTO, ServiceType } from "@/lib/types";
import { NICHES, nicheInfo } from "@/lib/types";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface ServicesPageProps {
  type: ServiceType;
}

interface ServiceFormState {
  name: string;
  description: string;
  priceLabel: string;
  priceFrom: string;
  estDuration: string;
  revision: string;
  options: string;
  sortOrder: string;
  active: boolean;
  niche: string;
}

const EMPTY_FORM: ServiceFormState = {
  name: "",
  description: "",
  priceLabel: "",
  priceFrom: "",
  estDuration: "",
  revision: "",
  options: "",
  sortOrder: "0",
  active: true,
  niche: "",
};

function typeLabel(type: ServiceType): string {
  if (type === "GRAPHIC") return "Layanan Desain Grafis";
  if (type === "WEBSITE") return "Layanan Website";
  return "Paket Bundle";
}

function typeLabelShort(type: ServiceType): string {
  if (type === "GRAPHIC") return "desain grafis";
  if (type === "WEBSITE") return "website";
  return "paket bundle";
}

export function ServicesPage({ type }: ServicesPageProps) {
  const [services, setServices] = useState<ServiceDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ServiceDTO | null>(null);
  const [form, setForm] = useState<ServiceFormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/services");
      const data = await res.json();
      const list: ServiceDTO[] = (data.services || []).filter(
        (s: ServiceDTO) => s.type === type
      );
      setServices(list);
    } catch {
      toast.error("Gagal memuat layanan.");
    } finally {
      setLoading(false);
    }
  }, [type]);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY_FORM);
    setOpen(true);
  };
  const openEdit = (s: ServiceDTO) => {
    setEditing(s);
    setForm({
      name: s.name,
      description: s.description || "",
      priceLabel: s.priceLabel || "",
      priceFrom: s.priceFrom != null ? String(s.priceFrom) : "",
      estDuration: s.estDuration || "",
      revision: s.revision || "",
      options: Array.isArray(s.options) ? s.options.join(", ") : "",
      sortOrder: String(s.sortOrder ?? 0),
      active: s.active,
      niche: s.niche || "",
    });
    setOpen(true);
  };

  const submit = async () => {
    if (!form.name.trim()) {
      toast.error("Nama layanan wajib diisi.");
      return;
    }
    setSaving(true);
    try {
      const body: any = {
        type,
        name: form.name.trim(),
        description: form.description.trim(),
        priceLabel: form.priceLabel.trim() || null,
        priceFrom: form.priceFrom ? Number(form.priceFrom) : null,
        estDuration: form.estDuration.trim() || null,
        revision: form.revision.trim() || null,
        options:
          type === "WEBSITE" && form.options.trim()
            ? form.options
                .split(",")
                .map((s) => s.trim())
                .filter(Boolean)
            : null,
        sortOrder: Number(form.sortOrder) || 0,
        active: form.active,
        niche: form.niche.trim() || null,
      };
      const res = await fetch("/api/admin/services", {
        method: editing ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing ? { id: editing.id, ...body } : body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal menyimpan.");
        return;
      }
      toast.success(editing ? "Layanan diperbarui." : "Layanan ditambahkan.");
      setOpen(false);
      load();
    } catch {
      toast.error("Gagal menyimpan.");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (s: ServiceDTO) => {
    try {
      await fetch("/api/admin/services", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: s.id, active: !s.active }),
      });
      load();
    } catch {
      toast.error("Gagal mengubah status.");
    }
  };

  const confirmDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch("/api/admin/services", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: deleteId }),
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || "Gagal menghapus.");
        return;
      }
      toast.success("Layanan dihapus.");
      setDeleteId(null);
      load();
    } catch {
      toast.error("Gagal menghapus.");
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">{typeLabel(type)}</p>
            <p className="text-2xl font-bold">{services.length} layanan</p>
          </div>
          <Button onClick={openCreate}>
            <Plus className="size-4" /> Tambah Layanan
          </Button>
        </CardContent>
      </Card>

      {loading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
      ) : services.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            Belum ada layanan {typeLabelShort(type)}.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {services.map((s) => (
            <ServiceRow
              key={s.id}
              service={s}
              expanded={expanded === s.id}
              onToggleExpand={() =>
                setExpanded(expanded === s.id ? null : s.id)
              }
              onEdit={() => openEdit(s)}
              onDelete={() => setDeleteId(s.id)}
              onToggleActive={() => toggleActive(s)}
              onChanged={load}
            />
          ))}
        </div>
      )}

      {/* Service form dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base">
              {editing ? "Edit Layanan" : "Tambah Layanan"}
            </DialogTitle>
            <DialogDescription className="sr-only">Form layanan</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto openly-scroll pr-1">
            <div className="space-y-1.5">
              <Label>Nama Layanan</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Logo, Banner, Brosur…"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Deskripsi</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={3}
                placeholder="Deskripsi singkat layanan"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Label Harga</Label>
                <Input
                  value={form.priceLabel}
                  onChange={(e) => setForm({ ...form, priceLabel: e.target.value })}
                  placeholder="Mulai dari Rp 350.000"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Harga Numerik (opsional)</Label>
                <Input
                  type="number"
                  value={form.priceFrom}
                  onChange={(e) => setForm({ ...form, priceFrom: e.target.value })}
                  placeholder="350000"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Estimasi Durasi</Label>
                <Input
                  value={form.estDuration}
                  onChange={(e) => setForm({ ...form, estDuration: e.target.value })}
                  placeholder="2-3 hari kerja"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Revisi</Label>
                <Input
                  value={form.revision}
                  onChange={(e) => setForm({ ...form, revision: e.target.value })}
                  placeholder="2x revisi gratis"
                />
              </div>
            </div>
            {type === "WEBSITE" && (
              <div className="space-y-1.5">
                <Label>Opsi (pisahkan koma)</Label>
                <Input
                  value={form.options}
                  onChange={(e) => setForm({ ...form, options: e.target.value })}
                  placeholder=".com, hosting, SSL, email"
                />
              </div>
            )}
            <div className="space-y-1.5">
              <Label>Niche</Label>
              <Select
                value={form.niche}
                onValueChange={(v) => setForm({ ...form, niche: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih niche" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Umum (tanpa niche)</SelectItem>
                  {NICHES.map((n) => (
                    <SelectItem key={n.id} value={n.id}>
                      {`${n.emoji} ${n.short}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Niche membantu mengelompokkan layanan untuk audiens tertentu (mis. salon, klinik, kuliner).
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Urutan</Label>
                <Input
                  type="number"
                  value={form.sortOrder}
                  onChange={(e) => setForm({ ...form, sortOrder: e.target.value })}
                />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch
                  checked={form.active}
                  onCheckedChange={(v) => setForm({ ...form, active: v })}
                />
                <Label className="text-sm">Aktif</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              <X className="size-4" /> Batal
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus layanan?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini akan menghapus layanan beserta seluruh paket di dalamnya. Aksi ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface ServiceRowProps {
  service: ServiceDTO;
  expanded: boolean;
  onToggleExpand: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onToggleActive: () => void;
  onChanged: () => void;
}

function ServiceRow({
  service,
  expanded,
  onToggleExpand,
  onEdit,
  onDelete,
  onToggleActive,
  onChanged,
}: ServiceRowProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <button
            onClick={onToggleExpand}
            className="mt-1 p-1 rounded hover:bg-accent"
            aria-label="Toggle packages"
          >
            {expanded ? (
              <ChevronDown className="size-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="size-4 text-muted-foreground" />
            )}
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <p className="font-semibold truncate">{service.name}</p>
              <Badge variant="outline" className="text-xs">
                {service.packages.length} paket
              </Badge>
              {service.priceLabel && (
                <Badge variant="secondary" className="text-xs">
                  {service.priceLabel}
                </Badge>
              )}
              {(() => {
                const ni = nicheInfo(service.niche);
                return (
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-xs",
                      ni
                        ? "border-primary/30 bg-primary/5 text-primary"
                        : "text-muted-foreground"
                    )}
                    title={ni?.desc || "Tanpa niche"}
                  >
                    {ni ? `${ni.emoji} ${ni.short}` : "Umum"}
                  </Badge>
                );
              })()}
              {!service.active && (
                <Badge variant="outline" className="text-xs text-muted-foreground">
                  Nonaktif
                </Badge>
              )}
            </div>
            {service.description && (
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                {service.description}
              </p>
            )}
            <div className="flex flex-wrap gap-3 mt-2 text-xs text-muted-foreground">
              {service.estDuration && <span>⏱ {service.estDuration}</span>}
              {service.revision && <span>↻ {service.revision}</span>}
              <span>urutan: {service.sortOrder}</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2 shrink-0">
            <div className="flex items-center gap-2">
              <Switch
                checked={service.active}
                onCheckedChange={onToggleActive}
                aria-label="Toggle active"
              />
              <Button size="sm" variant="outline" onClick={onEdit}>
                <Pencil className="size-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={onDelete}
                className="text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>

      {expanded && (
        <div className="border-t border-border/60 bg-muted/20 p-4">
          <PackageManager service={service} onChanged={onChanged} />
        </div>
      )}
    </Card>
  );
}

interface PackageManagerProps {
  service: ServiceDTO;
  onChanged: () => void;
}

interface PkgForm {
  id?: string;
  name: string;
  price: string;
  priceLabel: string;
  description: string;
  features: string; // newline separated
  estDuration: string;
  revision: string;
  popular: boolean;
  active: boolean;
  sortOrder: string;
}

const EMPTY_PKG: PkgForm = {
  name: "",
  price: "",
  priceLabel: "",
  description: "",
  features: "",
  estDuration: "",
  revision: "",
  popular: false,
  active: true,
  sortOrder: "0",
};

function PackageManager({ service, onChanged }: PackageManagerProps) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<PkgForm>(EMPTY_PKG);
  const [editing, setEditing] = useState<PackageDTO | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY_PKG);
    setOpen(true);
  };
  const openEdit = (p: PackageDTO) => {
    setEditing(p);
    setForm({
      name: p.name,
      price: p.price != null ? String(p.price) : "",
      priceLabel: p.priceLabel || "",
      description: p.description || "",
      features: Array.isArray(p.features) ? p.features.join("\n") : "",
      estDuration: p.estDuration || "",
      revision: p.revision || "",
      popular: p.popular,
      active: p.active,
      sortOrder: String(p.sortOrder ?? 0),
    });
    setOpen(true);
  };

  const submit = async () => {
    if (!form.name.trim()) {
      toast.error("Nama paket wajib.");
      return;
    }
    setSaving(true);
    try {
      const body: any = {
        serviceId: service.id,
        name: form.name.trim(),
        price: form.price ? Number(form.price) : null,
        priceLabel: form.priceLabel.trim() || null,
        description: form.description.trim() || null,
        features: form.features
          .split("\n")
          .map((s) => s.trim())
          .filter(Boolean),
        estDuration: form.estDuration.trim() || null,
        revision: form.revision.trim() || null,
        popular: form.popular,
        active: form.active,
        sortOrder: Number(form.sortOrder) || 0,
      };
      const res = await fetch("/api/admin/packages", {
        method: editing ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing ? { id: editing.id, ...body } : body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal menyimpan paket.");
        return;
      }
      toast.success(editing ? "Paket diperbarui." : "Paket ditambahkan.");
      setOpen(false);
      onChanged();
    } catch {
      toast.error("Gagal menyimpan paket.");
    } finally {
      setSaving(false);
    }
  };

  const togglePopular = async (p: PackageDTO) => {
    try {
      await fetch("/api/admin/packages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: p.id, popular: !p.popular }),
      });
      onChanged();
    } catch {
      toast.error("Gagal mengubah paket.");
    }
  };

  const confirmDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch("/api/admin/packages", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: deleteId }),
      });
      toast.success("Paket dihapus.");
      setDeleteId(null);
      onChanged();
    } catch {
      toast.error("Gagal menghapus.");
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-semibold flex items-center gap-1.5">
          <Package className="size-4 text-primary" /> Paket ({service.packages.length})
        </h4>
        <Button size="sm" variant="outline" onClick={openCreate}>
          <Plus className="size-4" /> Tambah Paket
        </Button>
      </div>

      {service.packages.length === 0 ? (
        <p className="text-xs text-muted-foreground py-3">
          Belum ada paket. Layanan ini bisa dipesan tanpa paket spesifik.
        </p>
      ) : (
        <div className="space-y-2">
          {service.packages.map((p) => (
            <div
              key={p.id}
              className="rounded-lg border border-border/60 bg-card p-3 flex flex-wrap items-center justify-between gap-2"
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-medium text-sm">{p.name}</p>
                  {p.popular && (
                    <Badge className="text-[10px] openly-gradient text-white border-transparent">
                      Populer
                    </Badge>
                  )}
                  {!p.active && (
                    <Badge variant="outline" className="text-[10px] text-muted-foreground">
                      Nonaktif
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {p.priceLabel || "—"} · {p.estDuration || "—"} · urutan {p.sortOrder}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-muted-foreground">Populer</span>
                  <Switch
                    checked={p.popular}
                    onCheckedChange={() => togglePopular(p)}
                  />
                </div>
                <Button size="sm" variant="outline" onClick={() => openEdit(p)}>
                  <Pencil className="size-3.5" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setDeleteId(p.id)}
                  className="text-destructive"
                >
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Package form */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base">
              {editing ? "Edit Paket" : "Tambah Paket"}
            </DialogTitle>
            <DialogDescription className="sr-only">Form paket</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto openly-scroll pr-1">
            <div className="space-y-1.5">
              <Label>Nama Paket</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Paket Basic, Standar, Premium"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Harga (Rp)</Label>
                <Input
                  type="number"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  placeholder="350000"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Label Harga (override)</Label>
                <Input
                  value={form.priceLabel}
                  onChange={(e) => setForm({ ...form, priceLabel: e.target.value })}
                  placeholder="Mulai dari Rp 350.000"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Deskripsi</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={2}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Fitur (satu per baris)</Label>
              <Textarea
                value={form.features}
                onChange={(e) => setForm({ ...form, features: e.target.value })}
                rows={5}
                placeholder="3 konsep desain&#10;Revisi 2x&#10;File source AI/PSD"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Estimasi Durasi</Label>
                <Input
                  value={form.estDuration}
                  onChange={(e) => setForm({ ...form, estDuration: e.target.value })}
                  placeholder="2-3 hari"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Revisi</Label>
                <Input
                  value={form.revision}
                  onChange={(e) => setForm({ ...form, revision: e.target.value })}
                  placeholder="2x revisi"
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Urutan</Label>
                <Input
                  type="number"
                  value={form.sortOrder}
                  onChange={(e) => setForm({ ...form, sortOrder: e.target.value })}
                />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch
                  checked={form.popular}
                  onCheckedChange={(v) => setForm({ ...form, popular: v })}
                />
                <Label className="text-sm">Populer</Label>
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch
                  checked={form.active}
                  onCheckedChange={(v) => setForm({ ...form, active: v })}
                />
                <Label className="text-sm">Aktif</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              <X className="size-4" /> Batal
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus paket?</AlertDialogTitle>
            <AlertDialogDescription>
              Paket ini akan dihapus permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
