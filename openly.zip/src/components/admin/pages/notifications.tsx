"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import {
  Send,
  Loader2,
  Megaphone,
  Info,
  CheckCircle2,
  Bell,
} from "lucide-react";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

interface NotificationRow {
  id: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  createdAt: string;
  userName: string | null;
  orderNumber: string | null;
}

interface CustomerItem {
  id: string;
  name: string;
  email: string;
}

const TYPE_BADGES: Record<string, { label: string; cls: string; icon: React.ComponentType<{ className?: string }> }> = {
  INFO: { label: "Info", cls: "bg-sky-100 text-sky-700 border-sky-200", icon: Info },
  STATUS: { label: "Status", cls: "bg-amber-100 text-amber-700 border-amber-200", icon: Bell },
  SYSTEM: { label: "Sistem", cls: "bg-violet-100 text-violet-700 border-violet-200", icon: Megaphone },
};

export function NotificationsPage() {
  const [list, setList] = useState<NotificationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [customers, setCustomers] = useState<CustomerItem[]>([]);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [recipient, setRecipient] = useState<string>("broadcast");
  const [type, setType] = useState<string>("INFO");
  const [sending, setSending] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r1, r2] = await Promise.all([
        fetch("/api/admin/notifications"),
        fetch("/api/admin/customers"),
      ]);
      const d1 = await r1.json();
      const d2 = await r2.json();
      setList(d1.notifications || []);
      setCustomers(
        (d2.customers || []).map((c: any) => ({ id: c.id, name: c.name, email: c.email }))
      );
    } catch {
      toast.error("Gagal memuat notifikasi.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const submit = async () => {
    if (!title.trim() || !message.trim()) {
      toast.error("Judul dan pesan wajib diisi.");
      return;
    }
    setSending(true);
    try {
      const body: any = {
        title: title.trim(),
        message: message.trim(),
        type,
      };
      if (recipient === "broadcast") body.broadcast = true;
      else body.userId = recipient;
      const res = await fetch("/api/admin/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal mengirim.");
        return;
      }
      toast.success(
        recipient === "broadcast"
          ? `Notifikasi dikirim ke ${data.sent || 0} pelanggan.`
          : "Notifikasi dikirim."
      );
      setOpen(false);
      setTitle("");
      setMessage("");
      setRecipient("broadcast");
      setType("INFO");
      load();
    } catch {
      toast.error("Gagal mengirim.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">Total Notifikasi Terkirim</p>
            <p className="text-2xl font-bold">{list.length}</p>
          </div>
          <Button onClick={() => setOpen(true)}>
            <Send className="size-4" /> Kirim Notifikasi
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="border-b">
          <CardTitle className="text-base">Riwayat Notifikasi</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {loading ? (
            <div className="space-y-2 p-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : list.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              Belum ada notifikasi.
            </div>
          ) : (
            <div className="max-h-[65vh] overflow-y-auto openly-scroll">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow>
                    <TableHead>Judul</TableHead>
                    <TableHead>Pesan</TableHead>
                    <TableHead>Penerima</TableHead>
                    <TableHead>Tipe</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Waktu</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {list.map((n) => {
                    const t = TYPE_BADGES[n.type] || TYPE_BADGES.INFO;
                    const Icon = t.icon;
                    return (
                      <TableRow key={n.id}>
                        <TableCell className="font-medium text-sm">{n.title}</TableCell>
                        <TableCell className="text-xs max-w-[260px] truncate">
                          {n.message}
                        </TableCell>
                        <TableCell className="text-xs">
                          {n.orderNumber ? (
                            <span>{n.orderNumber} · {n.userName || "—"}</span>
                          ) : n.userName ? (
                            <span>{n.userName}</span>
                          ) : (
                            <Badge variant="outline" className="text-[10px]">Broadcast</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={cn("text-xs", t.cls)}>
                            <Icon className="size-3" /> {t.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {n.read ? (
                            <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">
                              <CheckCircle2 className="size-3" /> Dibaca
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-xs text-muted-foreground">
                              Belum dibaca
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {formatDateTime(n.createdAt)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base">Kirim Notifikasi</DialogTitle>
            <DialogDescription className="sr-only">Form kirim notifikasi</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto openly-scroll pr-1">
            <div className="space-y-1.5">
              <Label>Judul</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Mis. Pesanan Anda sedang diproses"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Pesan</Label>
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={3}
                placeholder="Tulis isi pesan…"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Penerima</Label>
              <Select value={recipient} onValueChange={setRecipient}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="broadcast">📡 Semua Pelanggan (Broadcast)</SelectItem>
                  {customers.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name} ({c.email})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Tipe Notifikasi</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="INFO">Info</SelectItem>
                  <SelectItem value="STATUS">Status</SelectItem>
                  <SelectItem value="SYSTEM">Sistem</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
            <Button onClick={submit} disabled={sending}>
              {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              Kirim
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
