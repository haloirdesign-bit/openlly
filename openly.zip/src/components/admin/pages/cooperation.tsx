"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Plus,
  Pencil,
  Save,
  X,
  Loader2,
  Handshake,
  MessageCircle,
} from "lucide-react";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

interface CoopRow {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  active: boolean;
  createdAt: string;
  ordersCount: number;
  profile: {
    company: string | null;
    agreement: string | null;
    activatedAt: string | null;
  } | null;
}

interface FormState {
  name: string;
  email: string;
  phone: string;
  password: string;
  company: string;
  agreement: string;
  active: boolean;
}

const EMPTY_FORM: FormState = {
  name: "",
  email: "",
  phone: "",
  password: "",
  company: "",
  agreement: "",
  active: true,
};

function waHref(phone: string) {
  let p = (phone || "").replace(/[^\d]/g, "");
  if (p.startsWith("0")) p = "62" + p.slice(1);
  else if (p.startsWith("8")) p = "62" + p;
  return `https://wa.me/${p}`;
}

export function CooperationPage() {
  const [rows, setRows] = useState<CoopRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<CoopRow | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/customers");
      const data = await res.json();
      const list: CoopRow[] = (data.customers || []).filter(
        (c: CoopRow) => !!c.profile
      );
      setRows(list);
    } catch {
      toast.error("Gagal memuat pelanggan kerja sama.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      ...EMPTY_FORM,
      agreement: "Pelanggan kerja sama — disetujui admin",
    });
    setOpen(true);
  };
  const openEdit = (c: CoopRow) => {
    setEditing(c);
    setForm({
      name: c.name,
      email: c.email,
      phone: c.phone || "",
      password: "",
      company: c.profile?.company || "",
      agreement: c.profile?.agreement || "",
      active: c.active,
    });
    setOpen(true);
  };

  const submit = async () => {
    if (!form.name.trim() || !form.email.trim()) {
      toast.error("Nama dan email wajib.");
      return;
    }
    if (!editing && !form.password) {
      toast.error("Password wajib.");
      return;
    }
    setSaving(true);
    try {
      const body: any = {
        name: form.name.trim(),
        email: form.email.trim().toLowerCase(),
        phone: form.phone.trim() || null,
        active: form.active,
        company: form.company.trim() || null,
        agreement: form.agreement.trim() || null,
      };
      if (form.password) body.password = form.password;
      if (!editing && !body.agreement)
        body.agreement = "Pelanggan kerja sama — disetujui admin";
      const res = await fetch("/api/admin/customers", {
        method: editing ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing ? { id: editing.id, ...body } : body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal menyimpan.");
        return;
      }
      toast.success(editing ? "Pelanggan diperbarui." : "Pelanggan kerja sama ditambahkan.");
      setOpen(false);
      load();
    } catch {
      toast.error("Gagal menyimpan.");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (c: CoopRow) => {
    try {
      await fetch("/api/admin/customers", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: c.id, active: !c.active }),
      });
      load();
    } catch {
      toast.error("Gagal mengubah status.");
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">Pelanggan Kerja sama Aktif</p>
            <p className="text-2xl font-bold">
              {rows.filter((r) => r.active).length} / {rows.length}
            </p>
          </div>
          <Button onClick={openCreate}>
            <Plus className="size-4" /> Undang Pelanggan Kerja sama
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="border-b">
          <CardTitle className="text-base flex items-center gap-2">
            <Handshake className="size-4 text-primary" /> Daftar Kerja sama
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {loading ? (
            <div className="space-y-2 p-2">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : rows.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              Belum ada pelanggan kerja sama.
            </div>
          ) : (
            <div className="max-h-[65vh] overflow-y-auto openly-scroll">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow>
                    <TableHead>Nama / Perusahaan</TableHead>
                    <TableHead>Kontak</TableHead>
                    <TableHead>Kesepakatan</TableHead>
                    <TableHead>Pesanan</TableHead>
                    <TableHead>Aktivasi</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <p className="font-medium">{c.name}</p>
                        {c.profile?.company && (
                          <p className="text-xs text-muted-foreground">{c.profile.company}</p>
                        )}
                      </TableCell>
                      <TableCell className="text-xs">
                        <p>{c.email}</p>
                        <p className="text-muted-foreground">{c.phone || "—"}</p>
                      </TableCell>
                      <TableCell className="text-xs max-w-[200px]">
                        <p className="line-clamp-2">
                          {c.profile?.agreement || "—"}
                        </p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {c.ordersCount}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {c.profile?.activatedAt
                          ? formatDateTime(c.profile.activatedAt)
                          : "—"}
                      </TableCell>
                      <TableCell>
                        <Switch
                          checked={c.active}
                          onCheckedChange={() => toggleActive(c)}
                          aria-label="Toggle active"
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex gap-1 justify-end">
                          {c.phone && (
                            <Button asChild size="sm" variant="outline">
                              <a
                                href={waHref(c.phone)}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <MessageCircle className="size-3.5" />
                              </a>
                            </Button>
                          )}
                          <Button size="sm" variant="outline" onClick={() => openEdit(c)}>
                            <Pencil className="size-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base">
              {editing ? "Edit Pelanggan Kerja sama" : "Undang Pelanggan Kerja sama"}
            </DialogTitle>
            <DialogDescription className="sr-only">Form kerja sama</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto openly-scroll pr-1">
            <div className="rounded-lg bg-primary/5 border border-primary/20 p-3 text-xs text-primary">
              Akun kerja sama memungkinkan pelanggan login ke portal dan melihat riwayat pesanan mereka.
            </div>
            <div className="space-y-1.5">
              <Label>Nama</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  disabled={!!editing}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Telepon</Label>
                <Input
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>
                Password {editing && <span className="text-xs text-muted-foreground">(kosongkan jika tidak diubah)</span>}
              </Label>
              <Input
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="••••••••"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Perusahaan</Label>
              <Input
                value={form.company}
                onChange={(e) => setForm({ ...form, company: e.target.value })}
                placeholder="CV/PT/Brand"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Ringkasan Kesepakatan</Label>
              <Textarea
                value={form.agreement}
                onChange={(e) => setForm({ ...form, agreement: e.target.value })}
                rows={3}
                placeholder="Lingkup kerja sama, harga khusus, termin pembayaran, dll."
              />
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={form.active}
                onCheckedChange={(v) => setForm({ ...form, active: v })}
              />
              <Label className="text-sm">Aktif</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              <X className="size-4" /> Batal
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
