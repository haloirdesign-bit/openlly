"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import {
  Inbox,
  Clock,
  Loader2,
  CheckCircle2,
  XCircle,
  CalendarDays,
  Palette,
  Globe,
  Users,
  Handshake,
} from "lucide-react";
import {
  ORDER_STATUS_LABEL,
  ORDER_STATUS_COLOR,
  type OrderStatus,
} from "@/lib/types";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { AdminPageId } from "../admin-view";

interface Stats {
  totalOrders: number;
  pendingOrders: number;
  inProgress: number;
  completed: number;
  cancelled: number;
  graphicServices: number;
  websiteServices: number;
  customers: number;
  cooperation: number;
  todayCount: number;
}
interface RecentOrder {
  id: string;
  orderNumber: string;
  queueNumber: string;
  serviceType: string;
  serviceName: string | null;
  customerName: string;
  status: OrderStatus;
  createdAt: string;
}
interface ChartItem {
  date: string;
  count: number;
}

interface DashboardProps {
  onNavigate: (id: AdminPageId) => void;
}

const STAT_CARDS: {
  key: keyof Stats;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  page?: AdminPageId;
}[] = [
  { key: "totalOrders", label: "Total Pesanan", icon: Inbox },
  { key: "pendingOrders", label: "Menunggu Konfirmasi", icon: Clock, page: "orders" },
  { key: "inProgress", label: "Sedang Dikerjakan", icon: Loader2, page: "queue" },
  { key: "completed", label: "Selesai", icon: CheckCircle2, page: "orders" },
  { key: "cancelled", label: "Dibatalkan", icon: XCircle, page: "orders" },
  { key: "todayCount", label: "Pesanan Hari Ini", icon: CalendarDays, page: "orders" },
  { key: "graphicServices", label: "Layanan Desain", icon: Palette, page: "services-graphic" },
  { key: "websiteServices", label: "Layanan Website", icon: Globe, page: "services-website" },
  { key: "customers", label: "Pelanggan", icon: Users, page: "customers" },
  { key: "cooperation", label: "Pelanggan Kerja sama", icon: Handshake, page: "cooperation" },
];

export function DashboardPage({ onNavigate }: DashboardProps) {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<RecentOrder[]>([]);
  const [chart, setChart] = useState<ChartItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const res = await fetch("/api/admin/stats");
        const data = await res.json();
        if (!active) return;
        setStats(data.stats || null);
        setRecent(data.recent || []);
        setChart(
          (data.chart || []).map((d: ChartItem) => ({
            date: d.date.slice(5),
            count: d.count,
          }))
        );
      } catch {
        /* ignore */
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const chartData = chart.map((d) => ({
    label: new Date(d.date).toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
    count: d.count,
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-3 sm:gap-4">
        {STAT_CARDS.map((c) => {
          const Icon = c.icon;
          const val = stats ? stats[c.key] : null;
          return (
            <button
              key={c.key}
              onClick={() => c.page && onNavigate(c.page)}
              className="text-left"
              type="button"
            >
              <Card className="overflow-hidden transition-all hover:shadow-md hover:-translate-y-0.5 h-full">
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs text-muted-foreground truncate">{c.label}</p>
                      {loading ? (
                        <Skeleton className="h-7 w-12 mt-1.5" />
                      ) : (
                        <p className="text-2xl font-bold leading-tight">{val ?? 0}</p>
                      )}
                    </div>
                    <div className="inline-flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                      <Icon className="size-4" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        <Card className="lg:col-span-2">
          <CardHeader className="border-b">
            <CardTitle className="text-base">Pesanan 7 Hari Terakhir</CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            {loading ? (
              <Skeleton className="h-[260px] w-full rounded-md" />
            ) : (
              <div className="h-[260px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.91 0.015 250)" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 12, fill: "oklch(0.5 0.03 258)" }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 12, fill: "oklch(0.5 0.03 258)" }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <Tooltip
                      cursor={{ fill: "oklch(0.93 0.05 250)" }}
                      contentStyle={{
                        borderRadius: 8,
                        border: "1px solid oklch(0.91 0.015 250)",
                        fontSize: 12,
                      }}
                    />
                    <Bar dataKey="count" fill="#1E63FF" radius={[6, 6, 0, 0]} name="Pesanan" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="border-b">
            <CardTitle className="text-base">Status Antrean</CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-3">
            {loading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between rounded-lg bg-amber-50 border border-amber-200 px-3 py-2.5 dark:bg-amber-950/30 dark:border-amber-900/40">
                  <span className="text-sm text-amber-700 dark:text-amber-300">Menunggu Konfirmasi</span>
                  <Badge className="bg-amber-100 text-amber-700 border-amber-200">{stats?.pendingOrders ?? 0}</Badge>
                </div>
                <div className="flex items-center justify-between rounded-lg bg-sky-50 border border-sky-200 px-3 py-2.5 dark:bg-sky-950/30 dark:border-sky-900/40">
                  <span className="text-sm text-sky-700 dark:text-sky-300">Sedang Dikerjakan</span>
                  <Badge className="bg-sky-100 text-sky-700 border-sky-200">{stats?.inProgress ?? 0}</Badge>
                </div>
                <button
                  onClick={() => onNavigate("queue")}
                  className="w-full text-sm font-medium text-primary hover:underline text-left"
                >
                  Buka papan antrean →
                </button>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="border-b flex-row items-center justify-between">
          <CardTitle className="text-base">Pesanan Terbaru</CardTitle>
          <button
            onClick={() => onNavigate("orders")}
            className="text-sm text-primary hover:underline font-medium"
          >
            Lihat semua
          </button>
        </CardHeader>
        <CardContent className="pt-0">
          {loading ? (
            <div className="space-y-2 p-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : recent.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              Belum ada pesanan masuk.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>No. Pesanan</TableHead>
                    <TableHead>Pelanggan</TableHead>
                    <TableHead>Jenis</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Waktu</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recent.map((o) => (
                    <TableRow
                      key={o.id}
                      className="cursor-pointer hover:bg-accent/50"
                      onClick={() => onNavigate("orders")}
                    >
                      <TableCell className="font-mono text-xs font-semibold">
                        {o.orderNumber}
                      </TableCell>
                      <TableCell className="font-medium">{o.customerName}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {o.serviceType === "GRAPHIC" ? "Desain" : "Website"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={cn("text-xs", ORDER_STATUS_COLOR[o.status])}
                        >
                          {ORDER_STATUS_LABEL[o.status]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatDateTime(o.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
