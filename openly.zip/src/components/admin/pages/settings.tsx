"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Save, Loader2, ShieldAlert } from "lucide-react";

interface SettingField {
  key: string;
  label: string;
  type?: "text" | "textarea";
  placeholder?: string;
  hint?: string;
}

const GROUPS: { title: string; fields: SettingField[] }[] = [
  {
    title: "Identitas Merek",
    fields: [
      { key: "brand_name", label: "Nama Merek" },
      { key: "parent_company", label: "Perusahaan Induk" },
      { key: "owner_name", label: "Nama Owner" },
      { key: "footer_text", label: "Teks Footer", type: "textarea" },
    ],
  },
  {
    title: "Hero / Beranda",
    fields: [
      { key: "hero_slogan", label: "Slogan Hero" },
      { key: "hero_description", label: "Deskripsi Hero", type: "textarea" },
      { key: "announcement", label: "Pengumuman (opsional)", type: "textarea", hint: "Kosongkan jika tidak ada pengumuman aktif" },
      { key: "nav_login_text", label: "Teks Tombol Login Pelanggan" },
    ],
  },
  {
    title: "Kontak",
    fields: [
      { key: "whatsapp", label: "Nomor WhatsApp (format 62…)", placeholder: "628216881766" },
      { key: "whatsapp_display", label: "Tampilan WhatsApp", placeholder: "0821-6881-766" },
      { key: "address", label: "Alamat", type: "textarea" },
      { key: "email_contact", label: "Email Kontak" },
    ],
  },
  {
    title: "Media Sosial",
    fields: [
      { key: "instagram", label: "Instagram (URL/username)", placeholder: "@openly.id" },
      { key: "tiktok", label: "TikTok", placeholder: "@openly.id" },
      { key: "facebook", label: "Facebook", placeholder: "url atau username" },
      { key: "behance", label: "Behance", placeholder: "url atau username" },
    ],
  },
];

export function SettingsPage() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/settings");
      const data = await res.json();
      const map = data.settings || {};
      setSettings(map);
      setDraft(map);
    } catch {
      toast.error("Gagal memuat pengaturan.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const dirty = Object.keys(draft).some((k) => draft[k] !== settings[k]);

  const saveAll = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: draft }),
      });
      if (!res.ok) {
        toast.error("Gagal menyimpan pengaturan.");
        return;
      }
      toast.success("Pengaturan tersimpan.");
      setSettings(draft);
    } catch {
      toast.error("Gagal menyimpan.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-3">
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-40 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="border-amber-200 bg-amber-50/50">
        <CardContent className="p-4 flex items-start gap-3">
          <ShieldAlert className="size-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-sm text-amber-800">
            <p className="font-semibold">Pengaturan Rahasia Server</p>
            <p className="text-xs mt-0.5">
              Kunci VAPID, JWT secret, dan kredensial lain TIDAK dapat diubah melalui editor ini. Gunakan environment variables di server.
            </p>
          </div>
        </CardContent>
      </Card>

      {GROUPS.map((g) => (
        <Card key={g.title}>
          <CardHeader className="border-b">
            <CardTitle className="text-base">{g.title}</CardTitle>
            <CardDescription className="text-xs">
              {g.fields.length} pengaturan
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-4 space-y-3">
            {g.fields.map((f) => (
              <div key={f.key} className="space-y-1.5">
                <Label className="text-sm flex items-center gap-1.5">
                  {f.label}
                  <code className="text-[10px] text-muted-foreground font-mono">{f.key}</code>
                </Label>
                {f.type === "textarea" ? (
                  <Textarea
                    value={draft[f.key] || ""}
                    onChange={(e) =>
                      setDraft({ ...draft, [f.key]: e.target.value })
                    }
                    placeholder={f.placeholder}
                    rows={2}
                  />
                ) : (
                  <Input
                    value={draft[f.key] || ""}
                    onChange={(e) =>
                      setDraft({ ...draft, [f.key]: e.target.value })
                    }
                    placeholder={f.placeholder}
                  />
                )}
                {f.hint && <p className="text-xs text-muted-foreground">{f.hint}</p>}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}

      <div className="sticky bottom-4 z-10">
        <Card className="border-primary/30 shadow-lg">
          <CardContent className="p-3 flex items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">
              {dirty ? "Ada perubahan belum disimpan." : "Semua perubahan tersimpan."}
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={load} disabled={saving}>
                Reset
              </Button>
              <Button size="sm" onClick={saveAll} disabled={saving || !dirty}>
                {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                Simpan Semua
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
