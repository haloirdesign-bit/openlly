"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { toast } from "sonner";
import {
  Search,
  Loader2,
  Eye,
  MessageCircle,
  Save,
  X,
  Paperclip,
  Clock,
  FileText,
} from "lucide-react";
import {
  ORDER_STATUSES,
  ORDER_STATUS_LABEL,
  ORDER_STATUS_COLOR,
  type OrderStatus,
  type OrderDetailGraphic,
  type OrderDetailWebsite,
} from "@/lib/types";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import { StatusTimeline } from "@/components/openly/status-timeline";

interface OrderRow {
  id: string;
  orderNumber: string;
  queueNumber: string;
  serviceType: "GRAPHIC" | "WEBSITE";
  serviceName: string | null;
  customerName: string;
  customerPhone: string;
  userId: string | null;
  status: OrderStatus;
  statusLabel: string;
  statusColor: string;
  statusStep: number;
  adminNote: string | null;
  createdAt: string;
  updatedAt: string;
}

interface OrderDetail {
  id: string;
  orderNumber: string;
  queueNumber: string;
  serviceType: "GRAPHIC" | "WEBSITE";
  status: OrderStatus;
  customerName: string;
  customerPhone: string;
  customerEmail: string | null;
  userId: string | null;
  adminNote: string | null;
  createdAt: string;
  updatedAt: string;
  serviceName: string | null;
  packageId: string | null;
  details: OrderDetailGraphic | OrderDetailWebsite | Record<string, unknown>;
  token: string;
}
interface Attachment {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  createdAt: string;
  storagePath: string;
}
interface FileResult {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  note: string | null;
  version: number;
  createdAt: string;
}
interface HistoryItem {
  id: string;
  status: string;
  note: string | null;
  createdAt: string;
  changedBy: string | null;
}

const STATUS_FILTERS: { value: string; label: string }[] = [
  { value: "ALL", label: "Semua Status" },
  ...ORDER_STATUSES.map((s) => ({ value: s, label: ORDER_STATUS_LABEL[s] })),
];

function waHref(phone: string) {
  let p = (phone || "").replace(/[^\d]/g, "");
  if (p.startsWith("0")) p = "62" + p.slice(1);
  else if (p.startsWith("8")) p = "62" + p;
  return `https://wa.me/${p}`;
}

function formatBytes(n: number) {
  if (!n) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

function DetailRow({ label, value }: { label: string; value: React.ReactNode }) {
  if (value === null || value === undefined || value === "") return null;
  return (
    <div className="grid grid-cols-3 gap-2 py-1.5 border-b border-border/40 last:border-0">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="col-span-2 text-sm break-words">{value}</span>
    </div>
  );
}

function OrderDetailsView({ details }: { details: Record<string, any> }) {
  const d = details || {};
  return (
    <div>
      <DetailRow label="Jenis" value={d.jenisDesain || d.jenisWebsite} />
      <DetailRow label="Paket" value={d.paket} />
      {d.namaBisnis ? <DetailRow label="Nama Bisnis" value={d.namaBisnis} /> : null}
      <DetailRow label="Kebutuhan" value={d.kebutuhan || d.tujuan} />
      {d.ukuran ? <DetailRow label="Ukuran" value={d.ukuran} /> : null}
      {d.warna ? <DetailRow label="Warna" value={d.warna} /> : null}
      {d.fitur ? (
        <DetailRow
          label="Fitur"
          value={
            Array.isArray(d.fitur) && d.fitur.length
              ? d.fitur.join(", ")
              : "—"
          }
        />
      ) : null}
      {d.referensi ? <DetailRow label="Referensi" value={d.referensi} /> : null}
      {d.domain ? <DetailRow label="Domain" value={d.domain} /> : null}
      <DetailRow label="Deadline" value={d.deadline} />
      <DetailRow label="Catatan" value={d.catatan} />
    </div>
  );
}

export function OrdersPage() {
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("ALL");
  const [type, setType] = useState<string>("ALL");
  const [detailOpen, setDetailOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [detail, setDetail] = useState<OrderDetail | null>(null);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [files, setFiles] = useState<FileResult[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [detailLoading, setDetailLoading] = useState(false);
  const [newStatus, setNewStatus] = useState<OrderStatus | null>(null);
  const [adminNote, setAdminNote] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (status !== "ALL") params.set("status", status);
      if (type !== "ALL") params.set("type", type);
      if (q.trim()) params.set("q", q.trim());
      const res = await fetch(`/api/admin/orders?${params.toString()}`);
      const data = await res.json();
      setOrders(data.orders || []);
    } catch {
      toast.error("Gagal memuat pesanan.");
    } finally {
      setLoading(false);
    }
  }, [status, type, q]);

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  const openDetail = async (row: OrderRow) => {
    setActiveId(row.id);
    setDetailOpen(true);
    setDetailLoading(true);
    setDetail(null);
    setAttachments([]);
    setFiles([]);
    setHistory([]);
    setNewStatus(null);
    setAdminNote("");
    try {
      const res = await fetch(`/api/orders/${row.id}`);
      const data = await res.json();
      setDetail(data.order);
      setAttachments(data.attachments || []);
      setFiles(data.files || []);
      setHistory(data.history || []);
      setAdminNote(data.order?.adminNote || "");
    } catch {
      toast.error("Gagal memuat detail pesanan.");
    } finally {
      setDetailLoading(false);
    }
  };

  const saveStatus = async () => {
    if (!activeId) return;
    setSaving(true);
    try {
      const body: any = { id: activeId };
      if (newStatus) body.status = newStatus;
      if (adminNote !== (detail?.adminNote || "")) body.adminNote = adminNote;
      const res = await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal menyimpan.");
        return;
      }
      toast.success("Pesanan diperbarui.");
      setNewStatus(null);
      // refresh detail + list
      if (activeId) {
        const r = await fetch(`/api/orders/${activeId}`);
        const d = await r.json();
        setDetail(d.order);
        setHistory(d.history || []);
        setAdminNote(d.order?.adminNote || "");
      }
      load();
    } catch {
      toast.error("Gagal menyimpan.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Card>
        <CardContent className="p-4 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari nomor pesanan / nama / telepon…"
              className="pl-9"
            />
          </div>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {STATUS_FILTERS.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="w-full sm:w-[160px]">
              <SelectValue placeholder="Jenis" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Semua Jenis</SelectItem>
              <SelectItem value="GRAPHIC">Desain Grafis</SelectItem>
              <SelectItem value="WEBSITE">Website</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => { setQ(""); setStatus("ALL"); setType("ALL"); }}>
            <X className="size-4" /> Reset
          </Button>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader className="border-b">
          <CardTitle className="text-base">Daftar Pesanan ({orders.length})</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {loading ? (
            <div className="space-y-2 p-2">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : orders.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              Tidak ada pesanan yang cocok.
            </div>
          ) : (
            <div className="max-h-[60vh] overflow-y-auto openly-scroll">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow>
                    <TableHead>No. Pesanan</TableHead>
                    <TableHead>Antrean</TableHead>
                    <TableHead>Pelanggan</TableHead>
                    <TableHead>Telepon</TableHead>
                    <TableHead>Layanan</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Waktu</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((o) => (
                    <TableRow key={o.id}>
                      <TableCell className="font-mono text-xs font-semibold">
                        {o.orderNumber}
                      </TableCell>
                      <TableCell>
                        <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-muted">
                          {o.queueNumber}
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">{o.customerName}</TableCell>
                      <TableCell className="text-xs">{o.customerPhone}</TableCell>
                      <TableCell className="text-xs">
                        <div className="flex flex-col">
                          <span>{o.serviceName || "—"}</span>
                          <Badge variant="outline" className="w-fit mt-0.5 text-[10px]">
                            {o.serviceType === "GRAPHIC" ? "Desain" : "Website"}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={cn("text-xs", ORDER_STATUS_COLOR[o.status])}
                        >
                          {ORDER_STATUS_LABEL[o.status]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatDateTime(o.createdAt)}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openDetail(o)}
                        >
                          <Eye className="size-4" /> Detail
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail dialog — desktop, sheet on mobile */}
      <DetailDialog
        open={detailOpen}
        onOpenChange={setDetailOpen}
        loading={detailLoading}
        detail={detail}
        attachments={attachments}
        files={files}
        history={history}
        newStatus={newStatus}
        setNewStatus={setNewStatus}
        adminNote={adminNote}
        setAdminNote={setAdminNote}
        saving={saving}
        onSave={saveStatus}
      />
    </div>
  );
}

interface DetailDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  loading: boolean;
  detail: OrderDetail | null;
  attachments: Attachment[];
  files: FileResult[];
  history: HistoryItem[];
  newStatus: OrderStatus | null;
  setNewStatus: (s: OrderStatus | null) => void;
  adminNote: string;
  setAdminNote: (s: string) => void;
  saving: boolean;
  onSave: () => void;
}

function DetailDialog({
  open,
  onOpenChange,
  loading,
  detail,
  attachments,
  files,
  history,
  newStatus,
  setNewStatus,
  adminNote,
  setAdminNote,
  saving,
  onSave,
}: DetailDialogProps) {
  const isMobile = typeof window !== "undefined" && window.innerWidth < 768;
  const content = (
    <div className="space-y-5 max-h-[78vh] overflow-y-auto openly-scroll pr-1">
      {loading || !detail ? (
        <div className="space-y-3 py-6">
          <Skeleton className="h-6 w-1/2" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </div>
      ) : (
        <>
          {/* Header */}
          <div className="rounded-lg border border-border/60 p-4 bg-muted/30">
            <div className="flex flex-wrap items-center gap-2 justify-between mb-2">
              <div>
                <p className="font-mono text-sm font-bold">{detail.orderNumber}</p>
                <p className="text-xs text-muted-foreground">
                  Antrean #{detail.queueNumber} · {detail.serviceType === "GRAPHIC" ? "Desain Grafis" : "Website"}
                </p>
              </div>
              <Badge
                variant="outline"
                className={cn("text-xs", ORDER_STATUS_COLOR[detail.status])}
              >
                {ORDER_STATUS_LABEL[detail.status]}
              </Badge>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <p className="text-muted-foreground">Pelanggan</p>
                <p className="font-medium">{detail.customerName}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Telepon</p>
                <p className="font-medium">{detail.customerPhone}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Email</p>
                <p className="font-medium break-words">{detail.customerEmail || "—"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Layanan</p>
                <p className="font-medium">{detail.serviceName || "—"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Dibuat</p>
                <p className="font-medium">{formatDateTime(detail.createdAt)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Update</p>
                <p className="font-medium">{formatDateTime(detail.updatedAt)}</p>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button asChild size="sm" variant="outline">
                <a
                  href={waHref(detail.customerPhone)}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MessageCircle className="size-4" /> WhatsApp Pelanggan
                </a>
              </Button>
            </div>
          </div>

          {/* Detail kebutuhan */}
          <div>
            <h3 className="text-sm font-semibold mb-2 flex items-center gap-1.5">
              <FileText className="size-4 text-primary" /> Detail Kebutuhan
            </h3>
            <div className="rounded-lg border border-border/60 p-3">
              <OrderDetailsView details={detail.details as any} />
            </div>
          </div>

          {/* Timeline */}
          <div>
            <h3 className="text-sm font-semibold mb-2 flex items-center gap-1.5">
              <Clock className="size-4 text-primary" /> Status & Riwayat
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="rounded-lg border border-border/60 p-4">
                <StatusTimeline current={detail.status} history={history} compact />
                <div className="mt-4">
                  <p className="text-xs font-semibold text-muted-foreground mb-2">Riwayat Perubahan</p>
                  <ul className="space-y-1.5 max-h-40 overflow-y-auto openly-scroll">
                    {history.length === 0 ? (
                      <li className="text-xs text-muted-foreground">Belum ada riwayat.</li>
                    ) : (
                      history.map((h) => (
                        <li key={h.id} className="text-xs flex items-start gap-2">
                          <span className="mt-1 inline-block size-1.5 rounded-full bg-primary shrink-0" />
                          <div>
                            <p className="font-medium">
                              {ORDER_STATUS_LABEL[h.status as OrderStatus] || h.status}
                            </p>
                            <p className="text-muted-foreground">
                              {formatDateTime(h.createdAt)}
                              {h.changedBy ? ` · oleh ${h.changedBy}` : ""}
                            </p>
                            {h.note && <p className="text-muted-foreground italic">"{h.note}"</p>}
                          </div>
                        </li>
                      ))
                    )}
                  </ul>
                </div>
              </div>

              {/* Status changer */}
              <div className="rounded-lg border border-border/60 p-4 space-y-3">
                <p className="text-sm font-semibold">Ubah Status</p>
                <div className="space-y-1.5">
                  <Label className="text-xs">Status Baru</Label>
                  <Select
                    value={newStatus || ""}
                    onValueChange={(v) => setNewStatus(v as OrderStatus)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={ORDER_STATUS_LABEL[detail.status]} />
                    </SelectTrigger>
                    <SelectContent>
                      {ORDER_STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {ORDER_STATUS_LABEL[s]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Catatan Admin</Label>
                  <Textarea
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    placeholder="Catatan internal atau untuk pelanggan…"
                    rows={3}
                  />
                </div>
                <Button onClick={onSave} disabled={saving} className="w-full">
                  {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                  Simpan Perubahan
                </Button>
              </div>
            </div>
          </div>

          {/* Attachments */}
          <div>
            <h3 className="text-sm font-semibold mb-2 flex items-center gap-1.5">
              <Paperclip className="size-4 text-primary" /> Lampiran dari Pelanggan ({attachments.length})
            </h3>
            {attachments.length === 0 ? (
              <p className="text-xs text-muted-foreground">Tidak ada lampiran.</p>
            ) : (
              <ul className="rounded-lg border border-border/60 divide-y divide-border/40">
                {attachments.map((a) => (
                  <li key={a.id} className="flex items-center justify-between p-2.5 text-sm">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{a.fileName}</p>
                      <p className="text-xs text-muted-foreground">
                        {a.fileType || "file"} · {formatBytes(a.fileSize)} · {formatDateTime(a.createdAt)}
                      </p>
                    </div>
                    <Badge variant="outline" className="text-[10px]">
                      Tersimpan aman di server
                    </Badge>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Result files (uploaded by admin) */}
          {files.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold mb-2 flex items-center gap-1.5">
                <FileText className="size-4 text-primary" /> File Hasil ({files.length})
              </h3>
              <ul className="rounded-lg border border-border/60 divide-y divide-border/40">
                {files.map((f) => (
                  <li key={f.id} className="flex items-center justify-between p-2.5 text-sm">
                    <div className="min-w-0">
                      <p className="font-medium truncate">
                        {f.fileName}
                        <span className="ml-1.5 text-[10px] text-muted-foreground">v{f.version}</span>
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatBytes(f.fileSize)} · {formatDateTime(f.createdAt)}
                      </p>
                      {f.note && <p className="text-xs italic">"{f.note}"</p>}
                    </div>
                    <Button asChild size="sm" variant="outline">
                      <a href={`/api/files/${f.id}`} target="_blank" rel="noopener noreferrer">
                        <FileText className="size-4" /> Unduh
                      </a>
                    </Button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}
    </div>
  );

  if (isMobile) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="bottom" className="h-[92vh] max-h-[92vh] overflow-y-auto openly-scroll p-0">
          <SheetHeader className="px-4 pt-4">
            <SheetTitle className="text-base">Detail Pesanan</SheetTitle>
            <SheetDescription className="sr-only">Detail pesanan</SheetDescription>
          </SheetHeader>
          <div className="px-4 pb-6">{content}</div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="text-base">Detail Pesanan</DialogTitle>
          <DialogDescription className="sr-only">Detail lengkap pesanan</DialogDescription>
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
}
