"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  Save,
  Loader2,
  Plus,
  Trash2,
  Sparkles,
  Rocket,
  ArrowUpDown,
  Star,
  MessageSquareQuote,
} from "lucide-react";

const ICON_HINTS = [
  "Sparkles", "Zap", "ShieldCheck", "Rocket", "Palette", "Headset",
  "Target", "Compass", "Heart", "Star", "Award", "Trophy",
  "Smile", "TrendingUp", "Lightbulb", "Brush", "PenTool", "Megaphone",
];

const SECTION_LABELS: Record<string, { title: string; desc: string }> = {
  hero: { title: "Hero / Beranda", desc: "Bagian atas beranda — slogan, deskripsi, tombol CTA, badge" },
  advantages: { title: "Keunggulan Layanan", desc: "Daftar keunggulan dengan ikon Lucide" },
  services_summary_graphic: { title: "Ringkasan Jasa Desain", desc: "Section ringkasan layanan desain grafis" },
  services_summary_website: { title: "Ringkasan Jasa Website", desc: "Section ringkasan layanan website" },
  order_flow: { title: "Alur Pemesanan", desc: "Langkah-langkah alur pemesanan" },
  cooperation: { title: "Pelanggan Kerja sama", desc: "Section undangan kerja sama" },
  owner: { title: "Profil Owner", desc: "Profil founder, visi, misi, nilai" },
  testimonials: { title: "Testimoni Pelanggan", desc: "Daftar testimoni/kata pelanggan" },
  review_section: { title: "Section Ulasan Google", desc: "Penilaian Google + ringkasan ulasan" },
  faq: { title: "FAQ", desc: "Pertanyaan yang sering diajukan" },
  contact: { title: "Kontak", desc: "Informasi kontak dan jam operasional" },
};

const ORDER = [
  "hero",
  "advantages",
  "services_summary_graphic",
  "services_summary_website",
  "order_flow",
  "cooperation",
  "owner",
  "testimonials",
  "review_section",
  "faq",
  "contact",
];

export function ContentPage() {
  const [sections, setSections] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [savingKey, setSavingKey] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/content");
      const data = await res.json();
      setSections(data.sections || {});
    } catch {
      toast.error("Gagal memuat konten.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const saveSection = async (key: string, value: any) => {
    setSavingKey(key);
    try {
      const res = await fetch("/api/admin/content", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      if (!res.ok) {
        toast.error("Gagal menyimpan konten.");
        return;
      }
      toast.success("Konten tersimpan.");
    } catch {
      toast.error("Gagal menyimpan.");
    } finally {
      setSavingKey(null);
    }
  };

  if (loading) {
    return (
      <div className="space-y-3">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">Total Bagian Konten</p>
            <p className="text-2xl font-bold">{ORDER.length}</p>
          </div>
          <p className="text-xs text-muted-foreground max-w-sm">
            Perubahan konten langsung tampil di beranda publik. Simpan tiap section secara terpisah.
          </p>
        </CardContent>
      </Card>

      {ORDER.map((key) => {
        const meta = SECTION_LABELS[key];
        const value = sections[key] || null;
        return (
          <SectionEditor
            key={key}
            sectionKey={key}
            title={meta?.title || key}
            description={meta?.desc || ""}
            value={value}
            saving={savingKey === key}
            onSave={(v) => saveSection(key, v)}
          />
        );
      })}
    </div>
  );
}

interface SectionEditorProps {
  sectionKey: string;
  title: string;
  description: string;
  value: any;
  saving: boolean;
  onSave: (v: any) => void;
}

function SectionEditor({
  sectionKey,
  title,
  description,
  value,
  saving,
  onSave,
}: SectionEditorProps) {
  const [prevValue, setPrevValue] = useState<any>(value ?? null);
  const [draft, setDraft] = useState<any>(value ?? null);
  const [dirty, setDirty] = useState(false);

  // Reset draft when the upstream value changes (calling setState during render
  // is the recommended React pattern to avoid cascading renders from effects).
  if ((value ?? null) !== prevValue) {
    setPrevValue(value ?? null);
    setDraft(value ?? null);
    setDirty(false);
  }

  const update = (next: any) => {
    setDraft(next);
    setDirty(true);
  };

  const handleSave = () => {
    onSave(draft);
    setDirty(false);
  };

  return (
    <Card>
      <CardHeader className="border-b">
        <div className="flex items-start justify-between gap-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              {title}
              <Badge variant="outline" className="text-[10px] font-mono">
                {sectionKey}
              </Badge>
            </CardTitle>
            <CardDescription className="text-xs">{description}</CardDescription>
          </div>
          <Button size="sm" onClick={handleSave} disabled={saving || !dirty}>
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
            Simpan
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <Editor sectionKey={sectionKey} value={draft} onChange={update} />
      </CardContent>
    </Card>
  );
}

function Editor({
  sectionKey,
  value,
  onChange,
}: {
  sectionKey: string;
  value: any;
  onChange: (v: any) => void;
}) {
  switch (sectionKey) {
    case "hero":
      return (
        <HeroEditor value={value || { slogan: "", description: "", ctas: [], badges: [] }} onChange={onChange} />
      );
    case "advantages":
      return <ArrayEditor value={value || []} onChange={onChange} renderItem={(item, set) => <AdvantageItem value={item} set={set} />} newItem={() => ({ icon: "Sparkles", title: "", desc: "" })} addLabel="Tambah Keunggulan" />;
    case "services_summary_graphic":
    case "services_summary_website":
      return <ServicesSummaryEditor value={value || { title: "", desc: "", points: [], cta: { label: "", view: "" } }} onChange={onChange} />;
    case "order_flow":
      return (
        <OrderFlowEditor value={value || { title: "", steps: [] }} onChange={onChange} />
      );
    case "cooperation":
      return <CooperationEditor value={value || { title: "", desc: "", points: [], cta: { label: "", view: "" } }} onChange={onChange} />;
    case "owner":
      return <OwnerEditor value={value || { name: "", role: "", welcome: "", vision: "", mission: "", values: [], avatar: "" }} onChange={onChange} />;
    case "testimonials":
      return (
        <TestimonialsEditor value={value || []} onChange={onChange} />
      );
    case "review_section":
      return (
        <ReviewSectionEditor value={value || { title: "", desc: "", googleRating: 0, googleCount: 0, googleUrl: "" }} onChange={onChange} />
      );
    case "faq":
      return <ArrayEditor value={value || []} onChange={onChange} renderItem={(item, set) => <FaqItem value={item} set={set} />} newItem={() => ({ q: "", a: "" })} addLabel="Tambah Pertanyaan" />;
    case "contact":
      return <ContactEditor value={value || { title: "", desc: "", whatsapp: "", address: "", hours: "" }} onChange={onChange} />;
    default:
      return <JSONEditor value={value} onChange={onChange} />;
  }
}

// ----- Hero -----
function HeroEditor({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label>Slogan</Label>
        <Input value={value.slogan || ""} onChange={(e) => set("slogan", e.target.value)} />
      </div>
      <div className="space-y-1.5">
        <Label>Deskripsi</Label>
        <Textarea value={value.description || ""} onChange={(e) => set("description", e.target.value)} rows={2} />
      </div>
      <StringListEditor label="Badge" items={value.badges || []} onChange={(v) => set("badges", v)} placeholder="Mis. Desain Grafis" />
      <div className="space-y-1.5">
        <Label>Tombol CTA</Label>
        <ArrayEditor
          value={value.ctas || []}
          onChange={(v) => set("ctas", v)}
          renderItem={(item, set) => (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <Input value={item.label || ""} onChange={(e) => set({ ...item, label: e.target.value })} placeholder="Label" />
              <Input value={item.view || ""} onChange={(e) => set({ ...item, view: e.target.value })} placeholder="View (mis. order)" />
              <Input value={item.params ? JSON.stringify(item.params) : ""} onChange={(e) => {
                try { set({ ...item, params: e.target.value ? JSON.parse(e.target.value) : {} }); } catch {}
              }} placeholder='params JSON' />
            </div>
          )}
          newItem={() => ({ label: "", view: "beranda" })}
          addLabel="Tambah CTA"
        />
      </div>
    </div>
  );
}

// ----- Advantage item -----
function AdvantageItem({ value, set }: { value: any; set: (v: any) => void }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
      <Input value={value.icon || ""} onChange={(e) => set({ ...value, icon: e.target.value })} placeholder="Icon Lucide" list="icon-list" />
      <Input value={value.title || ""} onChange={(e) => set({ ...value, title: e.target.value })} placeholder="Judul" />
      <Input value={value.desc || ""} onChange={(e) => set({ ...value, desc: e.target.value })} placeholder="Deskripsi" />
    </div>
  );
}

// ----- Services summary -----
function ServicesSummaryEditor({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label>Judul</Label>
        <Input value={value.title || ""} onChange={(e) => set("title", e.target.value)} />
      </div>
      <div className="space-y-1.5">
        <Label>Deskripsi</Label>
        <Textarea value={value.desc || ""} onChange={(e) => set("desc", e.target.value)} rows={2} />
      </div>
      <StringListEditor label="Poin" items={value.points || []} onChange={(v) => set("points", v)} placeholder="Mis. Logo profesional" />
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>CTA Label</Label>
          <Input value={value.cta?.label || ""} onChange={(e) => set("cta", { ...value.cta, label: e.target.value })} />
        </div>
        <div className="space-y-1.5">
          <Label>CTA View</Label>
          <Input value={value.cta?.view || ""} onChange={(e) => set("cta", { ...value.cta, view: e.target.value })} />
        </div>
      </div>
    </div>
  );
}

// ----- Order flow -----
function OrderFlowEditor({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label>Judul</Label>
        <Input value={value.title || ""} onChange={(e) => set("title", e.target.value)} />
      </div>
      <ArrayEditor
        value={value.steps || []}
        onChange={(v) => set("steps", v)}
        renderItem={(item, set) => (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <Input value={item.title || ""} onChange={(e) => set({ ...item, title: e.target.value })} placeholder="Judul step" />
            <Input value={item.desc || ""} onChange={(e) => set({ ...item, desc: e.target.value })} placeholder="Deskripsi" />
          </div>
        )}
        newItem={() => ({ title: "", desc: "" })}
        addLabel="Tambah Step"
      />
    </div>
  );
}

// ----- Cooperation -----
function CooperationEditor({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label>Judul</Label>
        <Input value={value.title || ""} onChange={(e) => set("title", e.target.value)} />
      </div>
      <div className="space-y-1.5">
        <Label>Deskripsi</Label>
        <Textarea value={value.desc || ""} onChange={(e) => set("desc", e.target.value)} rows={3} />
      </div>
      <StringListEditor label="Poin Keunggulan" items={value.points || []} onChange={(v) => set("points", v)} placeholder="Mis. Login aman" />
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>CTA Label</Label>
          <Input value={value.cta?.label || ""} onChange={(e) => set("cta", { ...value.cta, label: e.target.value })} />
        </div>
        <div className="space-y-1.5">
          <Label>CTA View</Label>
          <Input value={value.cta?.view || ""} onChange={(e) => set("cta", { ...value.cta, view: e.target.value })} />
        </div>
      </div>
    </div>
  );
}

// ----- Owner -----
function OwnerEditor({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>Nama</Label>
          <Input value={value.name || ""} onChange={(e) => set("name", e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Peran</Label>
          <Input value={value.role || ""} onChange={(e) => set("role", e.target.value)} />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Sambutan</Label>
        <Textarea value={value.welcome || ""} onChange={(e) => set("welcome", e.target.value)} rows={3} />
      </div>
      <div className="space-y-1.5">
        <Label>Visi</Label>
        <Textarea value={value.vision || ""} onChange={(e) => set("vision", e.target.value)} rows={2} />
      </div>
      <div className="space-y-1.5">
        <Label>Misi</Label>
        <Textarea value={value.mission || ""} onChange={(e) => set("mission", e.target.value)} rows={2} />
      </div>
      <ArrayEditor
        value={value.values || []}
        onChange={(v) => set("values", v)}
        renderItem={(item, set) => (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <Input value={item.title || ""} onChange={(e) => set({ ...item, title: e.target.value })} placeholder="Judul nilai" />
            <Input value={item.desc || ""} onChange={(e) => set({ ...item, desc: e.target.value })} placeholder="Deskripsi" />
          </div>
        )}
        newItem={() => ({ title: "", desc: "" })}
        addLabel="Tambah Nilai"
      />
    </div>
  );
}

// ----- FAQ item -----
function FaqItem({ value, set }: { value: any; set: (v: any) => void }) {
  return (
    <div className="space-y-2">
      <Input value={value.q || ""} onChange={(e) => set({ ...value, q: e.target.value })} placeholder="Pertanyaan" />
      <Textarea value={value.a || ""} onChange={(e) => set({ ...value, a: e.target.value })} rows={2} placeholder="Jawaban" />
    </div>
  );
}

// ----- Testimonials -----
interface TestimonialItem {
  name?: string;
  role?: string;
  text?: string;
  rating?: number;
}

function TestimonialsEditor({
  value,
  onChange,
}: {
  value: TestimonialItem[];
  onChange: (v: TestimonialItem[]) => void;
}) {
  const update = (i: number, v: TestimonialItem) => {
    const next = [...value];
    next[i] = v;
    onChange(next);
  };
  const remove = (i: number) => onChange(value.filter((_, idx) => idx !== i));
  const add = () =>
    onChange([
      ...value,
      { name: "", role: "", text: "", rating: 5 } as TestimonialItem,
    ]);

  return (
    <div className="space-y-3">
      {value.length === 0 ? (
        <p className="text-xs text-muted-foreground">
          Belum ada testimoni. Klik &quot;Tambah Testimoni&quot; untuk menambah.
        </p>
      ) : (
        value.map((item, i) => (
          <div
            key={i}
            className="rounded-lg border border-border/60 bg-muted/20 p-3 space-y-2"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-medium inline-flex items-center gap-1.5">
                <MessageSquareQuote className="size-3.5 text-primary" />
                Testimoni #{i + 1}
              </span>
              <Button
                size="sm"
                variant="ghost"
                type="button"
                onClick={() => remove(i)}
                className="text-destructive"
              >
                <Trash2 className="size-3.5" /> Hapus
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label className="text-xs">Nama</Label>
                <Input
                  value={item.name || ""}
                  onChange={(e) => update(i, { ...item, name: e.target.value })}
                  placeholder="Nama pelanggan"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Peran / Bisnis</Label>
                <Input
                  value={item.role || ""}
                  onChange={(e) => update(i, { ...item, role: e.target.value })}
                  placeholder="Mis. Pemilik Cafe Senja"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Testimoni</Label>
              <Textarea
                value={item.text || ""}
                onChange={(e) => update(i, { ...item, text: e.target.value })}
                rows={3}
                placeholder="Tulis testimoni pelanggan…"
              />
            </div>
            <div className="space-y-1.5 sm:max-w-[200px]">
              <Label className="text-xs inline-flex items-center gap-1">
                <Star className="size-3.5 text-amber-500" /> Rating
              </Label>
              <Select
                value={String(item.rating ?? 5)}
                onValueChange={(v) =>
                  update(i, { ...item, rating: Number(v) })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih rating" />
                </SelectTrigger>
                <SelectContent>
                  {[5, 4, 3, 2, 1].map((r) => (
                    <SelectItem key={r} value={String(r)}>
                      {`${r} Bintang`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        ))
      )}
      <Button size="sm" variant="outline" onClick={add} type="button">
        <Plus className="size-4" /> Tambah Testimoni
      </Button>
    </div>
  );
}

// ----- Review Section (Google rating summary) -----
interface ReviewSectionValue {
  title?: string;
  desc?: string;
  googleRating?: number;
  googleCount?: number;
  googleUrl?: string;
}

function ReviewSectionEditor({
  value,
  onChange,
}: {
  value: ReviewSectionValue;
  onChange: (v: ReviewSectionValue) => void;
}) {
  const set = (k: keyof ReviewSectionValue, v: any) =>
    onChange({ ...value, [k]: v });
  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label>Judul Section</Label>
        <Input
          value={value.title || ""}
          onChange={(e) => set("title", e.target.value)}
          placeholder="Mis. Apa Kata Pelanggan Kami"
        />
      </div>
      <div className="space-y-1.5">
        <Label>Deskripsi</Label>
        <Textarea
          value={value.desc || ""}
          onChange={(e) => set("desc", e.target.value)}
          rows={2}
          placeholder="Ringkasan singkat tentang ulasan pelanggan"
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="inline-flex items-center gap-1">
            <Star className="size-3.5 text-amber-500" /> Rating Google
          </Label>
          <Input
            type="number"
            min={0}
            max={5}
            step={0.1}
            value={value.googleRating != null ? String(value.googleRating) : ""}
            onChange={(e) =>
              set(
                "googleRating",
                e.target.value === "" ? 0 : Number(e.target.value)
              )
            }
            placeholder="4.9"
          />
        </div>
        <div className="space-y-1.5">
          <Label>Jumlah Ulasan</Label>
          <Input
            type="number"
            min={0}
            value={value.googleCount != null ? String(value.googleCount) : ""}
            onChange={(e) =>
              set(
                "googleCount",
                e.target.value === "" ? 0 : Number(e.target.value)
              )
            }
            placeholder="127"
          />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>URL Ulasan Google</Label>
        <Input
          value={value.googleUrl || ""}
          onChange={(e) => set("googleUrl", e.target.value)}
          placeholder="https://www.google.com/maps/place/..."
        />
      </div>
    </div>
  );
}

// ----- Contact -----
function ContactEditor({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>Judul</Label>
          <Input value={value.title || ""} onChange={(e) => set("title", e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>No WhatsApp (format 62…)</Label>
          <Input value={value.whatsapp || ""} onChange={(e) => set("whatsapp", e.target.value)} />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Deskripsi</Label>
        <Textarea value={value.desc || ""} onChange={(e) => set("desc", e.target.value)} rows={2} />
      </div>
      <div className="space-y-1.5">
        <Label>Alamat</Label>
        <Textarea value={value.address || ""} onChange={(e) => set("address", e.target.value)} rows={2} />
      </div>
      <div className="space-y-1.5">
        <Label>Jam Operasional</Label>
        <Input value={value.hours || ""} onChange={(e) => set("hours", e.target.value)} />
      </div>
    </div>
  );
}

// ----- JSON fallback editor -----
function JSONEditor({ value, onChange }: { value: any; onChange: (v: any) => void }) {
  const [prevValue, setPrevValue] = useState<any>(value);
  const [text, setText] = useState<string>(() => {
    try { return JSON.stringify(value, null, 2); } catch { return ""; }
  });
  if (value !== prevValue) {
    setPrevValue(value);
    try { setText(JSON.stringify(value, null, 2)); } catch { setText(""); }
  }
  return (
    <Textarea
      value={text}
      onChange={(e) => {
        setText(e.target.value);
        try { onChange(JSON.parse(e.target.value)); } catch {}
      }}
      rows={8}
      className="font-mono text-xs"
    />
  );
}

// ----- Generic array editor -----
function ArrayEditor<T>({
  value,
  onChange,
  renderItem,
  newItem,
  addLabel,
}: {
  value: T[];
  onChange: (v: T[]) => void;
  renderItem: (item: T, set: (v: T) => void) => React.ReactNode;
  newItem: () => T;
  addLabel: string;
}) {
  const update = (i: number, v: T) => {
    const next = [...value];
    next[i] = v;
    onChange(next);
  };
  const remove = (i: number) => onChange(value.filter((_, idx) => idx !== i));
  const moveUp = (i: number) => {
    if (i === 0) return;
    const next = [...value];
    [next[i - 1], next[i]] = [next[i], next[i - 1]];
    onChange(next);
  };
  const moveDown = (i: number) => {
    if (i === value.length - 1) return;
    const next = [...value];
    [next[i + 1], next[i]] = [next[i], next[i + 1]];
    onChange(next);
  };
  return (
    <div className="space-y-2">
      {value.length === 0 ? (
        <p className="text-xs text-muted-foreground">Belum ada item.</p>
      ) : (
        value.map((item, i) => (
          <div key={i} className="rounded-lg border border-border/60 bg-muted/20 p-3 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-muted-foreground">#{i + 1}</span>
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" onClick={() => moveUp(i)} disabled={i === 0} type="button">
                  <ArrowUpDown className="size-3.5" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => moveDown(i)} disabled={i === value.length - 1} type="button">
                  <ArrowUpDown className="size-3.5 rotate-180" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => remove(i)} type="button" className="text-destructive">
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            </div>
            {renderItem(item, (v) => update(i, v))}
          </div>
        ))
      )}
      <Button
        size="sm"
        variant="outline"
        onClick={() => onChange([...value, newItem()])}
        type="button"
      >
        <Plus className="size-4" /> {addLabel}
      </Button>
      {/* shared icon hint list */}
      <datalist id="icon-list">
        {ICON_HINTS.map((ic) => (
          <option key={ic} value={ic} />
        ))}
      </datalist>
    </div>
  );
}

// ----- String list (badges / points) -----
function StringListEditor({
  label,
  items,
  onChange,
  placeholder,
}: {
  label: string;
  items: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <div className="space-y-1.5">
        {items.map((s, i) => (
          <div key={i} className="flex gap-2">
            <Input
              value={s}
              onChange={(e) => {
                const next = [...items];
                next[i] = e.target.value;
                onChange(next);
              }}
              placeholder={placeholder}
            />
            <Button
              size="sm"
              variant="outline"
              onClick={() => onChange(items.filter((_, idx) => idx !== i))}
              className="text-destructive"
              type="button"
            >
              <Trash2 className="size-3.5" />
            </Button>
          </div>
        ))}
        <Button
          size="sm"
          variant="outline"
          onClick={() => onChange([...items, ""])}
          type="button"
        >
          <Plus className="size-4" /> Tambah
        </Button>
      </div>
    </div>
  );
}
