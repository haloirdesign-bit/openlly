"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  Upload,
  Trash2,
  Search,
  Loader2,
  Paperclip,
  FileText,
  FolderOpen,
} from "lucide-react";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

interface OrderItem {
  id: string;
  orderNumber: string;
  queueNumber: string;
  customerName: string;
  serviceType: "GRAPHIC" | "WEBSITE";
  serviceName: string | null;
  status: string;
  createdAt: string;
}
interface FileResult {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  note: string | null;
  version: number;
  createdAt: string;
}
interface Attachment {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  createdAt: string;
  storagePath: string;
}

function formatBytes(n: number) {
  if (!n) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

const ALLOWED = ["jpg", "jpeg", "png", "webp", "gif", "pdf", "zip", "ai", "psd", "doc", "docx"];

function validateFiles(files: FileList | File[]) {
  const errors: string[] = [];
  const valid: File[] = [];
  for (const f of Array.from(files)) {
    const ext = (f.name.split(".").pop() || "").toLowerCase();
    if (!ALLOWED.includes(ext)) {
      errors.push(`${f.name}: tipe .${ext} tidak diizinkan`);
      continue;
    }
    if (f.size > 15 * 1024 * 1024) {
      errors.push(`${f.name}: melebihi 15MB`);
      continue;
    }
    valid.push(f);
  }
  return { valid, errors };
}

export function FilesPage() {
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string>("");
  const [q, setQ] = useState("");
  const [files, setFiles] = useState<FileResult[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [filesLoading, setFilesLoading] = useState(false);
  const [note, setNote] = useState("");
  const [uploading, setUploading] = useState(false);
  const [fileList, setFileList] = useState<File[]>([]);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    setOrdersLoading(true);
    try {
      const res = await fetch("/api/admin/orders");
      const data = await res.json();
      setOrders(data.orders || []);
    } catch {
      toast.error("Gagal memuat pesanan.");
    } finally {
      setOrdersLoading(false);
    }
  }, []);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const filteredOrders = orders.filter((o) => {
    if (!q.trim()) return true;
    const s = q.toLowerCase();
    return (
      o.orderNumber.toLowerCase().includes(s) ||
      o.customerName.toLowerCase().includes(s)
    );
  });

  const loadFiles = useCallback(async (orderId: string) => {
    if (!orderId) {
      setFiles([]);
      setAttachments([]);
      return;
    }
    setFilesLoading(true);
    try {
      const res = await fetch(`/api/admin/files?orderId=${orderId}`);
      const data = await res.json();
      setFiles(data.files || []);
      setAttachments(data.attachments || []);
    } catch {
      toast.error("Gagal memuat file.");
    } finally {
      setFilesLoading(false);
    }
  }, []);

  const onSelectOrder = (id: string) => {
    setSelectedId(id);
    setNote("");
    setFileList([]);
    loadFiles(id);
  };

  const onPickFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list) return;
    const { valid, errors } = validateFiles(list);
    if (errors.length > 0) {
      toast.error(errors.join("\n"));
    }
    setFileList(valid);
  };

  const upload = async () => {
    if (!selectedId) {
      toast.error("Pilih pesanan dulu.");
      return;
    }
    if (fileList.length === 0) {
      toast.error("Pilih file untuk diunggah.");
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("orderId", selectedId);
      fd.append("note", note);
      fileList.forEach((f) => fd.append("files", f));
      const res = await fetch("/api/admin/files", {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal mengunggah.");
        return;
      }
      toast.success(`${fileList.length} file berhasil diunggah.`);
      setNote("");
      setFileList([]);
      loadFiles(selectedId);
    } catch {
      toast.error("Gagal mengunggah.");
    } finally {
      setUploading(false);
    }
  };

  const deleteFile = async (id: string) => {
    try {
      const res = await fetch("/api/admin/files", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) {
        toast.error("Gagal menghapus.");
        return;
      }
      toast.success("File dihapus.");
      setDeletingId(null);
      if (selectedId) loadFiles(selectedId);
    } catch {
      toast.error("Gagal menghapus.");
    }
  };

  const selectedOrder = orders.find((o) => o.id === selectedId);

  return (
    <div className="space-y-4">
      {/* Order picker */}
      <Card>
        <CardHeader className="border-b">
          <CardTitle className="text-base">Pilih Pesanan</CardTitle>
        </CardHeader>
        <CardContent className="pt-4 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari nomor pesanan / nama pelanggan"
              className="pl-9"
            />
          </div>
          {ordersLoading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : filteredOrders.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">Tidak ada pesanan.</p>
          ) : (
            <div className="max-h-64 overflow-y-auto openly-scroll rounded-lg border border-border/60">
              {filteredOrders.slice(0, 50).map((o) => (
                <button
                  key={o.id}
                  onClick={() => onSelectOrder(o.id)}
                  className={cn(
                    "w-full text-left px-3 py-2 text-sm border-b border-border/40 last:border-0 transition-colors hover:bg-accent",
                    selectedId === o.id && "bg-primary/10"
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-semibold">{o.orderNumber}</span>
                    <Badge variant="outline" className="text-[10px]">
                      {o.serviceType === "GRAPHIC" ? "Desain" : "Website"}
                    </Badge>
                  </div>
                  <p className="text-xs truncate">{o.customerName} · {o.serviceName || "—"}</p>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {!selectedId ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            <FolderOpen className="size-8 mx-auto mb-2 opacity-50" />
            Pilih pesanan untuk mengelola file hasil pekerjaan.
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Upload form */}
          <Card>
            <CardHeader className="border-b">
              <CardTitle className="text-base">Unggah File Hasil</CardTitle>
              <p className="text-xs text-muted-foreground">
                {selectedOrder?.orderNumber} · {selectedOrder?.customerName}
              </p>
            </CardHeader>
            <CardContent className="pt-4 space-y-3">
              <div className="space-y-1.5">
                <Label>Catatan (untuk pelanggan)</Label>
                <Textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Mis. Versi final — siap digunakan"
                  rows={2}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Pilih File (maks 15MB · jpg/png/webp/gif/pdf/zip/ai/psd/doc/docx)</Label>
                <Input
                  type="file"
                  multiple
                  onChange={onPickFiles}
                  accept={ALLOWED.map((e) => "." + e).join(",")}
                />
                {fileList.length > 0 && (
                  <ul className="text-xs text-muted-foreground mt-1 space-y-0.5">
                    {fileList.map((f, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <Paperclip className="size-3" /> {f.name} · {formatBytes(f.size)}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <Button onClick={upload} disabled={uploading || fileList.length === 0} className="w-full">
                {uploading ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
                Unggah {fileList.length > 0 ? `(${fileList.length})` : ""}
              </Button>
            </CardContent>
          </Card>

          {/* Files list */}
          <Card>
            <CardHeader className="border-b">
              <CardTitle className="text-base">File Hasil Pekerjaan</CardTitle>
              <p className="text-xs text-muted-foreground">{files.length} file</p>
            </CardHeader>
            <CardContent className="pt-0">
              {filesLoading ? (
                <div className="space-y-2 p-2">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : files.length === 0 ? (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  Belum ada file hasil untuk pesanan ini.
                </p>
              ) : (
                <div className="max-h-[50vh] overflow-y-auto openly-scroll">
                  <Table>
                    <TableHeader className="sticky top-0 bg-card z-10">
                      <TableRow>
                        <TableHead>File</TableHead>
                        <TableHead>Versi</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {files.map((f) => (
                        <TableRow key={f.id}>
                          <TableCell className="min-w-0">
                            <p className="font-medium text-sm truncate flex items-center gap-1.5">
                              <FileText className="size-3.5 text-primary shrink-0" />
                              {f.fileName}
                            </p>
                            <p className="text-[10px] text-muted-foreground">
                              {formatBytes(f.fileSize)} · {formatDateTime(f.createdAt)}
                            </p>
                            {f.note && <p className="text-xs italic mt-0.5">"{f.note}"</p>}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">v{f.version}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex gap-1 justify-end">
                              <Button asChild size="sm" variant="outline">
                                <a href={`/api/files/${f.id}`} target="_blank" rel="noopener noreferrer">
                                  Unduh
                                </a>
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setDeletingId(f.id)}
                                className="text-destructive"
                              >
                                <Trash2 className="size-3.5" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Attachments read-only */}
          <Card className="lg:col-span-2">
            <CardHeader className="border-b">
              <CardTitle className="text-base flex items-center gap-2">
                <Paperclip className="size-4 text-primary" /> Lampiran Pelanggan
              </CardTitle>
              <p className="text-xs text-muted-foreground">
                {attachments.length} lampiran · file tersimpan aman di server
              </p>
            </CardHeader>
            <CardContent className="pt-0">
              {filesLoading ? (
                <Skeleton className="h-12 w-full mt-2" />
              ) : attachments.length === 0 ? (
                <p className="py-6 text-center text-sm text-muted-foreground">
                  Tidak ada lampiran dari pelanggan.
                </p>
              ) : (
                <div className="divide-y divide-border/40">
                  {attachments.map((a) => (
                    <div key={a.id} className="flex items-center justify-between py-2.5">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate flex items-center gap-1.5">
                          <Paperclip className="size-3.5 text-muted-foreground" />
                          {a.fileName}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {a.fileType || "file"} · {formatBytes(a.fileSize)} · {formatDateTime(a.createdAt)}
                        </p>
                      </div>
                      <Badge variant="outline" className="text-[10px]">tersimpan aman</Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Delete confirm (simple inline) */}
      {deletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <Card className="max-w-sm w-full">
            <CardContent className="p-5">
              <p className="font-semibold mb-1">Hapus file?</p>
              <p className="text-sm text-muted-foreground mb-4">
                File akan dihapus permanen dari server.
              </p>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" size="sm" onClick={() => setDeletingId(null)}>
                  Batal
                </Button>
                <Button
                  size="sm"
                  onClick={() => deleteFile(deletingId)}
                  className="bg-destructive hover:bg-destructive/90 text-white"
                >
                  Hapus
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
