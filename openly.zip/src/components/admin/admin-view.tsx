"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useSession } from "@/hooks/use-session";
import { useRouter } from "@/store/router";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Inbox,
  ListOrdered,
  Palette,
  Globe,
  Package,
  Users,
  Handshake,
  FolderOpen,
  FileText,
  Settings,
  Bell,
  UserCog,
  LogOut,
  Loader2,
  ShieldCheck,
  Menu,
  ArrowLeft,
  LogIn,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
  SheetClose,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

import { DashboardPage } from "./pages/dashboard";
import { OrdersPage } from "./pages/orders";
import { QueuePage } from "./pages/queue";
import { ServicesPage } from "./pages/services";
import { PackagesPage } from "./pages/packages";
import { CustomersPage } from "./pages/customers";
import { CooperationPage } from "./pages/cooperation";
import { FilesPage } from "./pages/files";
import { ContentPage } from "./pages/content";
import { SettingsPage } from "./pages/settings";
import { NotificationsPage } from "./pages/notifications";
import { AccountPage } from "./pages/account";

export type AdminPageId =
  | "dashboard"
  | "orders"
  | "queue"
  | "services-graphic"
  | "services-website"
  | "services-bundle"
  | "packages"
  | "customers"
  | "cooperation"
  | "files"
  | "content"
  | "settings"
  | "notifications"
  | "account";

interface NavItem {
  id: AdminPageId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV: NavItem[] = [
  { id: "dashboard", label: "Ringkasan", icon: LayoutDashboard },
  { id: "orders", label: "Pesanan Masuk", icon: Inbox },
  { id: "queue", label: "Antrean", icon: ListOrdered },
  { id: "services-graphic", label: "Layanan Desain Grafis", icon: Palette },
  { id: "services-website", label: "Layanan Website", icon: Globe },
  { id: "services-bundle", label: "Paket Bundle", icon: Package },
  { id: "packages", label: "Paket & Pricelist", icon: Package },
  { id: "customers", label: "Pelanggan", icon: Users },
  { id: "cooperation", label: "Pelanggan Kerja sama", icon: Handshake },
  { id: "files", label: "File & Hasil Pekerjaan", icon: FolderOpen },
  { id: "content", label: "Konten Beranda", icon: FileText },
  { id: "settings", label: "Pengaturan Website", icon: Settings },
  { id: "notifications", label: "Notifikasi", icon: Bell },
  { id: "account", label: "Pengaturan Akun", icon: UserCog },
];

const PAGE_TITLES: Record<AdminPageId, string> = {
  dashboard: "Ringkasan",
  orders: "Pesanan Masuk",
  queue: "Antrean Pengerjaan",
  "services-graphic": "Layanan Desain Grafis",
  "services-website": "Layanan Website",
  "services-bundle": "Paket Bundle",
  packages: "Paket & Pricelist",
  customers: "Pelanggan",
  cooperation: "Pelanggan Kerja sama",
  files: "File & Hasil Pekerjaan",
  content: "Konten Beranda",
  settings: "Pengaturan Website",
  notifications: "Notifikasi",
  account: "Pengaturan Akun",
};

function AdminLoginCard() {
  const [email, setEmail] = useState("admin@openly.id");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(false);
  const { refresh } = useSession();
  const navigate = useRouter((s) => s.navigate);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Email dan password wajib diisi.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Login gagal.");
        return;
      }
      if (data.user?.role !== "ADMIN") {
        toast.error("Akses ditolak. Akun ini bukan admin.");
        return;
      }
      toast.success("Selamat datang, Admin.");
      refresh();
      setTimeout(() => window.location.reload(), 300);
    } catch {
      toast.error("Terjadi kesalahan jaringan.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden flex items-center justify-center p-4">
      {/* Premium animated background */}
      <div className="absolute inset-0 -z-10 openly-gradient" />
      <div className="absolute inset-0 -z-10 openly-pattern opacity-20" />
      <div className="absolute -top-24 -left-24 size-96 rounded-full bg-white/10 blur-3xl" />
      <div className="absolute -bottom-32 -right-24 size-96 rounded-full bg-sky-300/20 blur-3xl" />
      <div className="absolute top-1/3 right-1/4 size-40 rounded-full bg-white/5 blur-2xl" />

      <div className="relative w-full max-w-md">
        {/* Back to site (subtle) */}
        <button
          onClick={() => navigate("beranda")}
          className="mb-5 inline-flex items-center gap-1.5 text-sm text-white/70 hover:text-white transition-colors"
        >
          <ArrowLeft className="size-4" /> Kembali ke situs
        </button>

        {/* Glass card */}
        <div className="relative overflow-hidden rounded-3xl border border-white/20 bg-white/10 backdrop-blur-2xl shadow-2xl">
          {/* Logo header */}
          <div className="relative px-8 pt-10 pb-6 text-center text-white">
            <motion.div
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="mx-auto inline-flex size-16 items-center justify-center rounded-2xl bg-white/15 backdrop-blur ring-1 ring-white/30 shadow-xl"
            >
              <ShieldCheck className="size-8" />
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="mt-4 text-2xl font-extrabold tracking-tight"
            >
              Admin Openly
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.18 }}
              className="mt-1 text-sm text-white/70"
            >
              Akses khusus administrator
            </motion.p>
          </div>

          {/* Form */}
          <form onSubmit={submit} className="px-8 pb-8 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="admin-email" className="text-white/80 text-xs font-medium">
                Email
              </Label>
              <Input
                id="admin-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@openly.id"
                autoComplete="email"
                className="border-white/20 bg-white/10 text-white placeholder:text-white/40 backdrop-blur focus-visible:border-white/40 focus-visible:ring-white/20"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="admin-password" className="text-white/80 text-xs font-medium">
                Password
              </Label>
              <div className="relative">
                <Input
                  id="admin-password"
                  type={show ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  autoFocus
                  className="border-white/20 bg-white/10 text-white placeholder:text-white/40 backdrop-blur focus-visible:border-white/40 focus-visible:ring-white/20 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShow((s) => !s)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-white/50 hover:text-white/80 text-xs px-1.5"
                  tabIndex={-1}
                >
                  {show ? "Sembunyi" : "Lihat"}
                </button>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full bg-white text-primary hover:bg-white/90 shadow-lg"
              size="lg"
              disabled={loading}
            >
              {loading ? <Loader2 className="size-4 animate-spin" /> : <LogIn className="size-4" />}
              Masuk
            </Button>
          </form>
        </div>

        <p className="mt-5 text-center text-xs text-white/50">
          Area terbatas · Hanya untuk administrator yang berwenang
        </p>
      </div>
    </div>
  );
}

function LoadingShell() {
  return (
    <div className="flex min-h-[70vh] items-center justify-center">
      <div className="text-center">
        <Loader2 className="size-10 mx-auto animate-spin text-primary" />
        <p className="mt-3 text-sm text-muted-foreground">Memuat dashboard admin…</p>
      </div>
    </div>
  );
}

function SidebarContent({
  active,
  onNavigate,
  onLogout,
}: {
  active: AdminPageId;
  onNavigate: (id: AdminPageId) => void;
  onLogout: () => void;
}) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-border/60">
        <div className="relative inline-flex size-9 items-center justify-center rounded-lg openly-gradient text-white">
          <ShieldCheck className="size-5" />
        </div>
        <div>
          <p className="text-sm font-bold leading-tight">Admin Openly</p>
          <p className="text-[11px] text-muted-foreground leading-tight">Dashboard Internal</p>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto openly-scroll px-3 py-4 space-y-1">
        {NAV.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                "relative w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors text-left",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              {isActive && (
                <span className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-1 rounded-r-full openly-gradient" />
              )}
              <Icon className="size-4 shrink-0" />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>
      <div className="border-t border-border/60 p-3">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors"
        >
          <LogOut className="size-4" /> Keluar
        </button>
      </div>
    </div>
  );
}

export function AdminView() {
  const { user, loading } = useSession();
  const navigate = useRouter((s) => s.navigate);
  const [active, setActive] = useState<AdminPageId>("dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);

  // logout
  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {
      /* ignore */
    }
    window.location.reload();
  };

  const goNavigate = (id: AdminPageId) => {
    setActive(id);
    setMobileOpen(false);
    if (typeof window !== "undefined") window.scrollTo({ top: 0 });
  };

  const pageTitle = useMemo(() => PAGE_TITLES[active], [active]);

  const renderPage = () => {
    switch (active) {
      case "dashboard":
        return <DashboardPage onNavigate={goNavigate} />;
      case "orders":
        return <OrdersPage />;
      case "queue":
        return <QueuePage />;
      case "services-graphic":
        return <ServicesPage type="GRAPHIC" />;
      case "services-website":
        return <ServicesPage type="WEBSITE" />;
      case "services-bundle":
        return <ServicesPage type="BUNDLE" />;
      case "packages":
        return <PackagesPage />;
      case "customers":
        return <CustomersPage />;
      case "cooperation":
        return <CooperationPage />;
      case "files":
        return <FilesPage />;
      case "content":
        return <ContentPage />;
      case "settings":
        return <SettingsPage />;
      case "notifications":
        return <NotificationsPage />;
      case "account":
        return <AccountPage />;
      default:
        return null;
    }
  };

  if (loading) return <LoadingShell />;
  if (!user || user.role !== "ADMIN") return <AdminLoginCard />;

  const initial = (user.name || "A").trim().charAt(0).toUpperCase();

  return (
    <div className="min-h-[70vh]">
      <div className="lg:grid lg:grid-cols-[260px_1fr]">
        {/* Sidebar — desktop */}
        <aside className="hidden lg:flex lg:flex-col lg:sticky lg:top-[64px] lg:h-[calc(100vh-64px)] border-r border-border/60 bg-sidebar/40">
          <SidebarContent
            active={active}
            onNavigate={goNavigate}
            onLogout={logout}
          />
        </aside>

        {/* Mobile sidebar drawer */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetContent side="left" className="w-[260px] p-0 max-w-[85vw]">
            <SheetTitle className="sr-only">Menu Admin</SheetTitle>
            <SheetClose className="sr-only">Tutup</SheetClose>
            <SidebarContent
              active={active}
              onNavigate={goNavigate}
              onLogout={logout}
            />
          </SheetContent>
        </Sheet>

        {/* Main content */}
        <div className="flex min-h-[calc(100vh-64px)] flex-col">
          {/* Top bar */}
          <header className="sticky top-[64px] z-30 flex items-center gap-3 border-b border-border/60 bg-background/85 backdrop-blur px-4 sm:px-6 py-3">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden"
                  aria-label="Buka menu admin"
                >
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
            </Sheet>
            <div className="flex-1 min-w-0">
              <h1 className="truncate text-base sm:text-lg font-bold leading-tight">
                {pageTitle}
              </h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Panel administrasi Openly
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("beranda")}
              className="hidden sm:inline-flex"
            >
              <ArrowLeft className="size-4" /> Kembali ke Situs
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("beranda")}
              className="sm:hidden"
              aria-label="Kembali ke situs"
            >
              <ArrowLeft className="size-5" />
            </Button>
            <div className="flex items-center gap-2 rounded-full border border-border/60 bg-card pl-1 pr-3 py-1">
              <div className="inline-flex size-7 items-center justify-center rounded-full openly-gradient text-white text-xs font-bold">
                {initial}
              </div>
              <div className="hidden sm:block leading-tight">
                <p className="text-xs font-semibold truncate max-w-[140px]">{user.name}</p>
                <p className="text-[10px] text-muted-foreground">Administrator</p>
              </div>
            </div>
          </header>

          {/* Page content */}
          <main className="flex-1 overflow-y-auto openly-scroll p-4 sm:p-6 lg:p-8">
            {renderPage()}
          </main>
        </div>
      </div>

      {/* Mobile bottom logout (so logout always accessible even if drawer closed) */}
      <div className="lg:hidden sticky bottom-0 left-0 right-0 border-t border-border/60 bg-background/95 backdrop-blur p-2 flex items-center justify-between">
        <span className="text-xs text-muted-foreground px-2">Admin · {user.name}</span>
        <Button variant="ghost" size="sm" onClick={logout} className="text-destructive">
          <LogOut className="size-4" /> Keluar
        </Button>
      </div>
    </div>
  );
}
