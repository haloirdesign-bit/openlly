"use client";

import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";
import { waLink } from "@/hooks/use-site-content";
import { cn } from "@/lib/utils";

interface WaButtonProps {
  message?: string;
  phone?: string;
  label?: string;
  variant?: "default" | "outline" | "secondary" | "ghost";
  size?: "default" | "sm" | "lg";
  className?: string;
}

export function WaButton({
  message,
  phone,
  label = "Chat WhatsApp",
  variant = "default",
  size = "default",
  className,
}: WaButtonProps) {
  return (
    <Button asChild variant={variant} size={size} className={cn(className)}>
      <a href={waLink(phone, message)} target="_blank" rel="noopener noreferrer">
        <MessageCircle className="size-4" />
        {label}
      </a>
    </Button>
  );
}
