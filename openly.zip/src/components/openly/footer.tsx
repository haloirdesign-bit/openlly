"use client";

import { MapPin, MessageCircle, Mail, Clock } from "lucide-react";
import { useRouter } from "@/store/router";
import { useSiteContent, waLink } from "@/hooks/use-site-content";

export function Footer() {
  const navigate = useRouter((s) => s.navigate);
  const { data } = useSiteContent();
  const s = data?.settings || {};
  const socials = [
    { key: "instagram", label: "Instagram", url: s.instagram },
    { key: "tiktok", label: "TikTok", url: s.tiktok },
    { key: "facebook", label: "Facebook", url: s.facebook },
    { key: "behance", label: "Behance", url: s.behance },
  ].filter((x) => x.url);

  return (
    <footer className="mt-auto border-t border-border/60 bg-gradient-to-b from-background to-muted/30">
      <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10 py-8">
        <div className="grid gap-6 md:grid-cols-3">
          <div>
            { }
            <img src="/openly-logo.svg" alt="Openly" className="h-9 w-auto mb-2" />
            <p className="text-sm text-muted-foreground max-w-xs leading-relaxed">
              {s.footer_text || "Openly — Crafted For Your Growth."}
            </p>
          </div>

          <div className="text-sm">
            <h4 className="font-semibold mb-2">Kontak</h4>
            <ul className="space-y-1.5 text-muted-foreground">
              <li>
                <a
                  href={waLink(s.whatsapp)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 hover:text-primary transition-colors"
                >
                  <MessageCircle className="size-4" /> {s.whatsapp_display || "WhatsApp"}
                </a>
              </li>
              {s.email_contact && (
                <li className="inline-flex items-center gap-2">
                  <Mail className="size-4" /> {s.email_contact}
                </li>
              )}
              <li className="inline-flex items-start gap-2">
                <MapPin className="size-4 mt-0.5 shrink-0" />
                <span>{s.address}</span>
              </li>
            </ul>
          </div>

          <div className="text-sm">
            <h4 className="font-semibold mb-2">Navigasi</h4>
            <ul className="space-y-1.5 text-muted-foreground">
              <li>
                <button onClick={() => navigate("pricelist")} className="hover:text-primary transition-colors">
                  Pricelist
                </button>
              </li>
              <li>
                <button onClick={() => navigate("cara-pemesanan")} className="hover:text-primary transition-colors">
                  Cara Pemesanan
                </button>
              </li>
              <li>
                <button onClick={() => navigate("tentang")} className="hover:text-primary transition-colors">
                  Tentang Kami
                </button>
              </li>
              <li>
                <button onClick={() => navigate("kontak")} className="hover:text-primary transition-colors">
                  Hubungi Kami
                </button>
              </li>
            </ul>
            {socials.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {socials.map((soc) => (
                  <a
                    key={soc.key}
                    href={soc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center rounded-md border border-border/70 px-2.5 py-1 text-xs font-medium text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors"
                  >
                    {soc.label}
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-2 border-t border-border/60 pt-4 text-xs text-muted-foreground">
          <p>
            © {new Date().getFullYear()} {s.brand_name || "Openly"} — {s.parent_company || "IR Design Kreasi"}. Hak cipta dilindungi.
          </p>
          <p className="inline-flex items-center gap-1.5">
            <Clock className="size-3.5" /> Crafted For Your Growth
          </p>
        </div>
      </div>
    </footer>
  );
}
