"use client";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, Clock, RotateCcw, Star, FileText, Package as PackageIcon } from "lucide-react";
import { formatIDR } from "@/lib/format";
import type { PackageDTO } from "@/lib/types";

interface PackageDetailModalProps {
  pkg: PackageDTO | null;
  serviceName?: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onOrder?: () => void;
}

export function PackageDetailModal({
  pkg,
  serviceName,
  open,
  onOpenChange,
  onOrder,
}: PackageDetailModalProps) {
  const features: string[] = pkg ? (Array.isArray(pkg.features) ? pkg.features : []) : [];
  const priceText = pkg?.priceLabel || (pkg?.price != null ? formatIDR(pkg.price) : "Hubungi kami");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg sm:max-w-xl max-h-[88vh] overflow-y-auto openly-scroll">
        {pkg && (
          <>
            <DialogHeader>
              <div className="flex items-center gap-2">
                <div className="inline-flex size-11 items-center justify-center rounded-xl openly-gradient text-white shadow-md">
                  <PackageIcon className="size-5" />
                </div>
                <div>
                  <DialogTitle className="text-xl">{pkg.name}</DialogTitle>
                  <DialogDescription>{serviceName || "Paket layanan Openly"}</DialogDescription>
                </div>
              </div>
            </DialogHeader>

            <div className="mt-2 flex items-center gap-2 flex-wrap">
              {pkg.popular && (
                <Badge className="gap-1 openly-gradient text-white border-0">
                  <Star className="size-3 fill-current" /> Paket Populer
                </Badge>
              )}
              <span className="text-2xl font-extrabold openly-text-gradient">{priceText}</span>
            </div>

            {pkg.description && (
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{pkg.description}</p>
            )}

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {pkg.estDuration && (
                <div className="rounded-lg border border-border/70 bg-muted/40 p-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                    <Clock className="size-3.5" /> Estimasi Pengerjaan
                  </div>
                  <p className="mt-1 text-sm font-medium">{pkg.estDuration}</p>
                </div>
              )}
              {pkg.revision && (
                <div className="rounded-lg border border-border/70 bg-muted/40 p-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                    <RotateCcw className="size-3.5" /> Ketentuan Revisi
                  </div>
                  <p className="mt-1 text-sm font-medium">{pkg.revision}</p>
                </div>
              )}
            </div>

            <div className="mt-5">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="size-4 text-primary" />
                <h4 className="text-sm font-bold">Fitur yang didapatkan</h4>
              </div>
              <ul className="space-y-2">
                {features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm">
                    <span className="mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
                      <Check className="size-3.5" />
                    </span>
                    <span className="text-foreground/90">{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            {onOrder && (
              <div className="mt-6 flex flex-col sm:flex-row gap-2">
                <Button onClick={onOrder} className="flex-1">
                  Pesan Paket Ini
                </Button>
                <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
                  Tutup
                </Button>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
