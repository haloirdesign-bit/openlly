"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Clock, Star, Eye } from "lucide-react";
import { formatIDR } from "@/lib/format";
import type { PackageDTO } from "@/lib/types";

interface PackageCardProps {
  pkg: PackageDTO;
  serviceName?: string;
  onViewDetail: () => void;
  onOrder: () => void;
}

export function PackageCard({ pkg, serviceName, onViewDetail, onOrder }: PackageCardProps) {
  const priceText = pkg.priceLabel || (pkg.price != null ? formatIDR(pkg.price) : "Hubungi kami");
  const features: string[] = Array.isArray(pkg.features) ? pkg.features : [];

  return (
    <Card
      className={`relative flex h-full flex-col p-6 transition-all duration-300 hover:-translate-y-1 ${
        pkg.popular
          ? "border-primary shadow-xl ring-1 ring-primary/30"
          : "border-border/70 shadow-sm hover:shadow-lg"
      }`}
    >
      {pkg.popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <Badge className="gap-1 openly-gradient text-white border-0 shadow-md px-3 py-1">
            <Star className="size-3 fill-current" /> Populer
          </Badge>
        </div>
      )}
      <div className="mt-2">
        <h3 className="text-lg font-bold tracking-tight">{pkg.name}</h3>
        {serviceName && <p className="text-xs text-muted-foreground">{serviceName}</p>}
      </div>
      <div className="mt-4">
        <div className="text-2xl font-extrabold openly-text-gradient">{priceText}</div>
        {pkg.description && <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{pkg.description}</p>}
      </div>

      <ul className="mt-4 space-y-2 flex-1">
        {features.slice(0, 6).map((f, i) => (
          <li key={i} className="flex items-start gap-2 text-sm">
            <span className="mt-0.5 inline-flex size-4 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
              <Check className="size-3" />
            </span>
            <span className="text-foreground/80">{f}</span>
          </li>
        ))}
      </ul>

      <div className="mt-4 flex items-center gap-3 text-xs text-muted-foreground">
        {pkg.estDuration && (
          <span className="inline-flex items-center gap-1">
            <Clock className="size-3" /> {pkg.estDuration}
          </span>
        )}
        {pkg.revision && <span className="inline-flex items-center gap-1"><Check className="size-3" /> {pkg.revision}</span>}
      </div>

      <div className="mt-5 flex flex-col gap-2">
        <Button onClick={onOrder} className="w-full" size="sm">
          Pesan Sekarang
        </Button>
        <Button onClick={onViewDetail} variant="outline" size="sm" className="w-full">
          <Eye className="size-4" /> Lihat Detail
        </Button>
      </div>
    </Card>
  );
}
