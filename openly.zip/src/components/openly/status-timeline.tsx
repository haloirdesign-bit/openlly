"use client";

import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  ORDER_STATUSES,
  ORDER_STATUS_LABEL,
  ORDER_STATUS_STEP,
  type OrderStatus,
} from "@/lib/types";
import { motion } from "framer-motion";

interface StatusTimelineProps {
  current: OrderStatus;
  history?: { status: string; createdAt: string; note?: string | null }[];
  compact?: boolean;
}

const FLOW: OrderStatus[] = [
  "RECEIVED",
  "WAITING_CONFIRM",
  "QUEUED",
  "IN_PROGRESS",
  "WAITING_APPROVAL",
  "COMPLETED",
];

export function StatusTimeline({ current, history, compact }: StatusTimelineProps) {
  const currentStep = ORDER_STATUS_STEP[current] ?? 0;
  const cancelled = current === "CANCELLED";
  const revision = current === "REVISION";
  const historyMap = new Map<string, string>();
  history?.forEach((h) => {
    if (!historyMap.has(h.status)) historyMap.set(h.status, h.createdAt);
  });

  const pct = cancelled ? 100 : Math.max(0, Math.min(100, (currentStep / 6) * 100));

  if (compact) {
    return (
      <div className="w-full">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-muted-foreground">Progress</span>
          <span className="text-xs font-bold text-primary">
            {cancelled ? "Dibatalkan" : `${Math.round(pct)}%`}
          </span>
        </div>
        <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
          <motion.div
            className={cn("h-full rounded-full", cancelled ? "bg-zinc-400" : "openly-gradient")}
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="absolute left-4 top-2 bottom-2 w-0.5 bg-muted" />
      <motion.div
        className="absolute left-4 top-2 w-0.5 openly-gradient"
        initial={{ height: 0 }}
        animate={{ height: `${pct}%` }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      />
      <ul className="space-y-4">
        {FLOW.map((status) => {
          const step = ORDER_STATUS_STEP[status];
          const done = !cancelled && step <= currentStep;
          const isCurrent = !cancelled && status === current;
          return (
            <li key={status} className="relative flex items-start gap-4 pl-0">
              <div
                className={cn(
                  "relative z-10 inline-flex size-8 items-center justify-center rounded-full border-2 transition-colors",
                  done
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-background text-muted-foreground"
                )}
              >
                {done ? <Check className="size-4" /> : <span className="text-xs font-bold">{step + 1}</span>}
              </div>
              <div className="pt-1">
                <p
                  className={cn(
                    "text-sm font-semibold",
                    isCurrent ? "text-primary" : done ? "text-foreground" : "text-muted-foreground"
                  )}
                >
                  {ORDER_STATUS_LABEL[status]}
                </p>
                {historyMap.get(status) && (
                  <p className="text-xs text-muted-foreground">
                    {new Date(historyMap.get(status)!).toLocaleString("id-ID")}
                  </p>
                )}
              </div>
            </li>
          );
        })}
        {cancelled && (
          <li className="relative flex items-start gap-4">
            <div className="relative z-10 inline-flex size-8 items-center justify-center rounded-full border-2 border-zinc-300 bg-zinc-100 text-zinc-500">
              <X className="size-4" />
            </div>
            <div className="pt-1">
              <p className="text-sm font-semibold text-zinc-600">Dibatalkan</p>
            </div>
          </li>
        )}
        {revision && (
          <li className="relative flex items-start gap-4">
            <div className="relative z-10 inline-flex size-8 items-center justify-center rounded-full border-2 border-amber-400 bg-amber-100 text-amber-700">
              <span className="text-xs font-bold">!</span>
            </div>
            <div className="pt-1">
              <p className="text-sm font-semibold text-amber-700">Dalam Revisi</p>
            </div>
          </li>
        )}
      </ul>
    </div>
  );
}
