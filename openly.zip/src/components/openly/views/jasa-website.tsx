"use client";

import { ServiceExplorer } from "@/components/openly/service-explorer";
import { Reveal } from "@/components/openly/reveal";

export function JasaWebsiteView() {
  return (
    <div>
      <section className="relative overflow-hidden openly-pattern-mesh border-b border-border/60">
        <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10 py-12 sm:py-16">
          <Reveal>
            <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-primary mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Jasa Pembuatan Website
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight">
              <span className="openly-text-gradient">Website Berkualitas untuk Bisnis Anda</span>
            </h1>
            <p className="mt-4 max-w-2xl text-muted-foreground leading-relaxed">
              Dari landing page hingga website bisnis dan katalog produk. Dibangun dengan desain
              modern, responsif, dan siap mendukung pertumbuhan bisnis Anda secara online.
            </p>
          </Reveal>
        </div>
      </section>
      <ServiceExplorer
        type="WEBSITE"
        eyebrow="Layanan Website"
        title="Pilihan Layanan Pembuatan Website"
        description="Pilih jenis website sesuai kebutuhan bisnis Anda, lengkap dengan opsi domain dan hosting."
      />
    </div>
  );
}
