"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Reveal } from "@/components/openly/reveal";
import { StatusTimeline } from "@/components/openly/status-timeline";
import { useRouter } from "@/store/router";
import { useSiteContent, waLink } from "@/hooks/use-site-content";
import { formatDateTime } from "@/lib/format";
import { toast } from "sonner";
import { Search, Hash, Loader2, FileText, ArrowLeft, MessageCircle } from "lucide-react";

interface TrackResult {
  order: {
    orderNumber: string;
    queueNumber: string;
    serviceType: string;
    status: string;
    statusLabel: string;
    statusColor: string;
    statusStep: number;
    customerName: string;
    customerPhoneMasked: string;
    serviceName: string | null;
    details: any;
    adminNote: string | null;
    createdAt: string;
    updatedAt: string;
  };
  history: { status: string; label: string; note?: string | null; createdAt: string }[];
}

export function TrackView() {
  const { params, navigate } = useRouter();
  const { data } = useSiteContent();
  const settings = data?.settings || {};
  const [token, setToken] = useState(params.token || "");
  const [result, setResult] = useState<TrackResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const search = async (t?: string) => {
    const tk = (t || token).trim();
    if (!tk) {
      toast.error("Masukkan tautan atau token pelacakan.");
      return;
    }
    setLoading(true);
    setSearched(true);
    try {
      const res = await fetch(`/api/orders/track?token=${encodeURIComponent(tk)}`);
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Pesanan tidak ditemukan.");
        setResult(null);
        return;
      }
      setResult(data);
    } catch {
      toast.error("Gagal memuat data. Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (params.token) {
      setToken(params.token);
      search(params.token);
    }
     
  }, [params.token]);

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <button
            onClick={() => navigate("beranda")}
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-4"
          >
            <ArrowLeft className="size-4" /> Beranda
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            <span className="openly-text-gradient">Lacak Pesanan Anda</span>
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Masukkan token pelacakan yang Anda terima saat pemesanan berhasil.
          </p>
        </Reveal>

        <Card className="mt-6 p-5 sm:p-6 border-border/70 shadow-sm">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex-1 space-y-1.5">
              <Label htmlFor="token" className="sr-only">Token</Label>
              <Input
                id="token"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="Tempel token / tautan pelacakan"
                onKeyDown={(e) => e.key === "Enter" && search()}
              />
            </div>
            <Button onClick={() => search()} disabled={loading} size="lg">
              {loading ? <Loader2 className="size-4 animate-spin" /> : <Search className="size-4" />}
              Lacak
            </Button>
          </div>
        </Card>

        {loading && (
          <Card className="mt-6 p-6 border-border/70 shadow-sm">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="mt-4 h-40 w-full" />
          </Card>
        )}

        {!loading && result && (
          <Card className="mt-6 border-border/70 shadow-sm overflow-hidden">
            <div className="p-5 sm:p-6 border-b border-border/60 bg-muted/20">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="text-xs font-semibold text-muted-foreground">Nomor Pesanan</div>
                  <div className="text-lg font-extrabold text-primary">{result.order.orderNumber}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-semibold text-muted-foreground">Antrean</div>
                  <div className="text-lg font-extrabold inline-flex items-center gap-1">
                    <Hash className="size-4 text-primary" />{result.order.queueNumber}
                  </div>
                </div>
              </div>
              <div className="mt-3">
                <Badge className={`border ${result.order.statusColor}`}>
                  {result.order.statusLabel}
                </Badge>
              </div>
            </div>

            <div className="p-5 sm:p-6 space-y-6">
              <StatusTimeline
                current={result.order.status as any}
                history={result.history}
              />

              <div className="rounded-xl border border-border/70 bg-muted/20 p-4">
                <h4 className="text-sm font-bold flex items-center gap-2">
                  <FileText className="size-4 text-primary" /> Detail Pesanan
                </h4>
                <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <dt className="text-xs text-muted-foreground">Pemesan</dt>
                    <dd className="font-medium">{result.order.customerName}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted-foreground">WhatsApp</dt>
                    <dd className="font-medium">{result.order.customerPhoneMasked}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted-foreground">Layanan</dt>
                    <dd className="font-medium">{result.order.serviceName || result.order.serviceType}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted-foreground">Waktu Pesan</dt>
                    <dd className="font-medium">{formatDateTime(result.order.createdAt)}</dd>
                  </div>
                </dl>
                {result.order.adminNote && (
                  <div className="mt-3 rounded-lg bg-primary/5 border border-primary/15 p-3 text-sm">
                    <div className="text-xs font-semibold text-primary">Catatan Admin</div>
                    <p className="mt-1 text-foreground/80">{result.order.adminNote}</p>
                  </div>
                )}
              </div>

              {result.history.length > 0 && (
                <div>
                  <h4 className="text-sm font-bold mb-3">Riwayat Status</h4>
                  <ul className="space-y-2">
                    {result.history.map((h, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm">
                        <span className="mt-1 inline-flex size-2 rounded-full bg-primary" />
                        <div>
                          <span className="font-medium">{h.label}</span>
                          {h.note && <p className="text-xs text-muted-foreground">{h.note}</p>}
                          <p className="text-[11px] text-muted-foreground">{formatDateTime(h.createdAt)}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <Button asChild variant="outline" className="w-full">
                <a href={waLink(settings.whatsapp, `Halo Openly, saya ingin menanyakan status pesanan saya ${result.order.orderNumber} (antrean #${result.order.queueNumber}).`)} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="size-4" /> Tanya Status via WhatsApp
                </a>
              </Button>
            </div>
          </Card>
        )}

        {!loading && searched && !result && (
          <Card className="mt-6 p-8 text-center border-dashed border-border">
            <p className="text-sm text-muted-foreground">
              Pesanan tidak ditemukan. Periksa kembali token pelacakan Anda.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
