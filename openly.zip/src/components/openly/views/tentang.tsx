"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/openly/reveal";
import { SectionHeading } from "@/components/openly/section-heading";
import { useSiteContent } from "@/hooks/use-site-content";
import { useRouter } from "@/store/router";
import { Sparkles, Target, Compass, Heart } from "lucide-react";

const VALUE_ICONS = [Sparkles, Target, Compass, Heart];

export function TentangView() {
  const navigate = useRouter((s) => s.navigate);
  const { data } = useSiteContent();
  const settings = data?.settings || {};
  const owner = data?.sections?.owner || {};

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Tentang Kami"
          title={`Tentang ${settings.brand_name || "Openly"}`}
          description={`${settings.brand_name || "Openly"} adalah jasa desain grafis dan pembuatan website di bawah naungan ${settings.parent_company || "IR Design Kreasi"}.`}
        />

        {/* Owner card */}
        <Reveal className="mt-10">
          <Card className="overflow-hidden border-border/70 shadow-md">
            <div className="grid lg:grid-cols-[300px_1fr]">
              <div className="relative openly-gradient p-8 flex flex-col items-center justify-center text-center text-white">
                <div className="absolute inset-0 openly-pattern opacity-10" />
                <div className="relative">
                  <div className="mx-auto size-28 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-3xl font-black ring-4 ring-white/30">
                    {(owner.name || "O").split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase()}
                  </div>
                  <h3 className="mt-4 text-xl font-bold">{owner.name || settings.owner_name || "Ihfa Mungkas"}</h3>
                  <p className="text-sm text-white/80">{owner.role || "Founder Openly"}</p>
                </div>
              </div>
              <div className="p-6 sm:p-8">
                <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-primary mb-3">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Sambutan
                </span>
                <p className="text-base leading-relaxed text-foreground/90 italic">“{owner.welcome}”</p>
              </div>
            </div>
          </Card>
        </Reveal>

        {/* Vision & Mission */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <Reveal>
            <Card className="h-full p-6 border-border/70 shadow-sm">
              <div className="inline-flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Target className="size-5" />
              </div>
              <h3 className="mt-4 text-base font-bold">Visi</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{owner.vision}</p>
            </Card>
          </Reveal>
          <Reveal delay={0.08}>
            <Card className="h-full p-6 border-border/70 shadow-sm">
              <div className="inline-flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Compass className="size-5" />
              </div>
              <h3 className="mt-4 text-base font-bold">Misi</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{owner.mission}</p>
            </Card>
          </Reveal>
        </div>

        {/* Values */}
        <Reveal className="mt-8">
          <h3 className="text-center text-lg font-bold">Nilai Kerja Kami</h3>
          <div className="mt-5 grid grid-cols-2 lg:grid-cols-4 gap-3">
            {(owner.values || []).map((v: any, i: number) => {
              const Icon = VALUE_ICONS[i % VALUE_ICONS.length];
              return (
                <Card key={i} className="p-4 text-center border-border/70 shadow-sm">
                  <div className="mx-auto inline-flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <Icon className="size-4" />
                  </div>
                  <h4 className="mt-2 text-sm font-bold">{v.title}</h4>
                  <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{v.desc}</p>
                </Card>
              );
            })}
          </div>
        </Reveal>

        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <Button onClick={() => navigate("kontak")} size="lg">Hubungi Kami</Button>
          <Button onClick={() => navigate("pricelist")} size="lg" variant="outline">Lihat Pricelist</Button>
        </div>
      </div>
    </div>
  );
}
