"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Reveal } from "@/components/openly/reveal";
import { StatusTimeline } from "@/components/openly/status-timeline";
import { PushSubscribe } from "@/components/openly/push-subscribe";
import { useRouter } from "@/store/router";
import { useSiteContent, waLink } from "@/hooks/use-site-content";
import { toast } from "sonner";
import { formatDateTime } from "@/lib/format";
import {
  LogOut,
  UserRound,
  Package,
  Download,
  MessageCircle,
  Building2,
  RefreshCw,
  FileText,
  Hash,
  Loader2,
  Bell,
} from "lucide-react";

interface PortalData {
  user: { id: string; name: string; email: string; phone: string | null; avatar: string | null };
  profile: { company: string | null; agreement: string | null };
  orders: Array<{
    id: string;
    orderNumber: string;
    queueNumber: string;
    serviceType: string;
    serviceName: string | null;
    status: string;
    statusLabel: string;
    statusColor: string;
    statusStep: number;
    adminNote: string | null;
    createdAt: string;
    updatedAt: string;
    files: Array<{ id: string; fileName: string; fileType: string; note: string | null; version: number; createdAt: string }>;
  }>;
}

export function PortalView() {
  const navigate = useRouter((s) => s.navigate);
  const { data } = useSiteContent();
  const settings = data?.settings || {};
  const [portal, setPortal] = useState<PortalData | null>(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    fetch("/api/portal")
      .then((r) => (r.ok ? r.json() : Promise.reject(r)))
      .then((d) => setPortal(d))
      .catch(() => {
        toast.error("Sesi berakhir. Silakan login kembali.");
        navigate("login");
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    let active = true;
    fetch("/api/portal")
      .then((r) => (r.ok ? r.json() : Promise.reject(r)))
      .then((d) => {
        if (active) setPortal(d);
      })
      .catch(() => {
        if (active) {
          toast.error("Sesi berakhir. Silakan login kembali.");
          navigate("login");
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    navigate("beranda");
    setTimeout(() => window.location.reload(), 200);
  };

  const download = (id: string) => {
    window.open(`/api/files/${id}`, "_blank");
  };

  return (
    <div className="py-10 sm:py-14">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <Reveal>
          <Card className="overflow-hidden border-border/70 shadow-md">
            <div className="relative openly-gradient p-6 sm:p-8 text-white">
              <div className="absolute inset-0 openly-pattern opacity-10" />
              <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="size-14 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-xl font-black ring-4 ring-white/30">
                    {(portal?.user.name || "U").split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h1 className="text-xl font-bold">{portal?.user.name || "Pelanggan"}</h1>
                    <p className="text-sm text-white/85">{portal?.user.email}</p>
                    {portal?.profile.company && (
                      <p className="text-xs text-white/70 inline-flex items-center gap-1 mt-0.5">
                        <Building2 className="size-3" /> {portal.profile.company}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="secondary" size="sm" onClick={load} className="bg-white/20 text-white hover:bg-white/30 border border-white/20">
                    <RefreshCw className="size-4" /> Segarkan
                  </Button>
                  <Button variant="secondary" size="sm" onClick={logout} className="bg-white text-primary hover:bg-white/90">
                    <LogOut className="size-4" /> Keluar
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </Reveal>

        {/* Agreement */}
        {portal?.profile.agreement && (
          <Reveal delay={0.05} className="mt-4">
            <Card className="p-5 border-border/70 bg-muted/30">
              <div className="flex items-center gap-2 text-sm font-bold">
                <FileText className="size-4 text-primary" /> Detail Kesepakatan
              </div>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{portal.profile.agreement}</p>
            </Card>
          </Reveal>
        )}

        {/* Push notifications */}
        <Reveal delay={0.08} className="mt-4">
          <Card className="p-5 border-border/70">
            <div className="flex items-center gap-2 text-sm font-bold mb-3">
              <Bell className="size-4 text-primary" /> Notifikasi Push
            </div>
            <PushSubscribe />
            <p className="mt-3 text-xs text-muted-foreground">
              Catatan: notifikasi push browser hanya berfungsi pada perangkat & browser yang mendukung (Chrome, Edge, Firefox terbaru). Pada sebagian perangkat iOS, dukungan push terbatas.
            </p>
          </Card>
        </Reveal>

        {/* Stats */}
        <div className="mt-4 grid grid-cols-3 gap-3">
          {[
            { label: "Total Pesanan", value: portal?.orders.length ?? 0, icon: Package },
            { label: "Sedang Dikerjakan", value: portal?.orders.filter((o) => ["QUEUED", "IN_PROGRESS", "WAITING_APPROVAL", "REVISION"].includes(o.status)).length ?? 0, icon: Loader2 },
            { label: "Selesai", value: portal?.orders.filter((o) => o.status === "COMPLETED").length ?? 0, icon: UserRound },
          ].map((s, i) => (
            <Card key={i} className="p-4 border-border/70 shadow-sm">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <s.icon className="size-3.5 text-primary" /> {s.label}
              </div>
              <div className="mt-1 text-2xl font-extrabold">{loading ? <Skeleton className="h-7 w-8" /> : s.value}</div>
            </Card>
          ))}
        </div>

        {/* Orders */}
        <div className="mt-6">
          <h2 className="text-lg font-bold mb-3">Riwayat Pesanan</h2>
          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-40 w-full rounded-xl" />
              ))}
            </div>
          ) : portal && portal.orders.length > 0 ? (
            <div className="space-y-3">
              {portal.orders.map((o) => (
                <Reveal key={o.id}>
                  <Card className="p-5 border-border/70 shadow-sm">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-primary">{o.orderNumber}</span>
                          <Badge variant="outline" className="gap-1">
                            <Hash className="size-3" />{o.queueNumber}
                          </Badge>
                        </div>
                        <p className="mt-1 text-sm text-muted-foreground">
                          {o.serviceName || o.serviceType} • {formatDateTime(o.createdAt)}
                        </p>
                      </div>
                      <Badge className={`border ${o.statusColor}`}>{o.statusLabel}</Badge>
                    </div>

                    <div className="mt-4">
                      <StatusTimeline current={o.status as any} compact />
                    </div>

                    {o.adminNote && (
                      <div className="mt-3 rounded-lg bg-primary/5 border border-primary/15 p-3 text-sm">
                        <span className="text-xs font-semibold text-primary">Catatan Admin: </span>
                        <span className="text-foreground/80">{o.adminNote}</span>
                      </div>
                    )}

                    {o.files.length > 0 && (
                      <div className="mt-4">
                        <h4 className="text-xs font-bold text-muted-foreground mb-2">File Hasil Pekerjaan</h4>
                        <ul className="space-y-2">
                          {o.files.map((f) => (
                            <li key={f.id} className="flex items-center justify-between gap-3 rounded-lg border border-border/70 bg-muted/30 p-2.5">
                              <div className="flex items-center gap-2 min-w-0">
                                <FileText className="size-4 text-primary shrink-0" />
                                <div className="min-w-0">
                                  <p className="text-sm font-medium truncate">{f.fileName}</p>
                                  {f.note && <p className="text-xs text-muted-foreground truncate">{f.note}</p>}
                                </div>
                              </div>
                              <Button size="sm" variant="outline" onClick={() => download(f.id)}>
                                <Download className="size-3.5" /> Unduh
                              </Button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button asChild variant="outline" size="sm">
                        <a href={waLink(settings.whatsapp, `Halo Openly, saya ingin menanyakan pesanan saya ${o.orderNumber}.`)} target="_blank" rel="noopener noreferrer">
                          <MessageCircle className="size-3.5" /> Tanya WhatsApp
                        </a>
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => navigate("track", { token: "" })}>
                        Lacak
                      </Button>
                    </div>
                  </Card>
                </Reveal>
              ))}
            </div>
          ) : (
            <Card className="p-10 text-center border-dashed border-border">
              <Package className="mx-auto size-10 text-muted-foreground/40" />
              <p className="mt-3 text-sm text-muted-foreground">Belum ada pesanan pada akun Anda.</p>
              <Button className="mt-4" onClick={() => navigate("order", { type: "GRAPHIC" })}>
                Buat Pesanan Baru
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
