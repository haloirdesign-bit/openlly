"use client";

import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Palette, Globe, Tag, Star, Users, Phone, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouter } from "@/store/router";
import { useSiteContent, waLink } from "@/hooks/use-site-content";

export function BerandaView() {
  const navigate = useRouter((s) => s.navigate);
  const { data } = useSiteContent();
  const sections = data?.sections || {};
  const settings = data?.settings || {};
  const hero = sections.hero || {};

  // Quick nav shortcuts (bukan section, cuma tombol navigasi rapih)
  const shortcuts = [
    { label: "Desain Grafis", desc: "Mulai Rp 10.000", view: "jasa-desain" as const, icon: Palette },
    { label: "Website", desc: "Mulai Rp 150.000", view: "jasa-website" as const, icon: Globe },
    { label: "Pricelist", desc: "Lihat semua harga", view: "pricelist" as const, icon: Tag },
    { label: "Review", desc: "Apa kata pelanggan", view: "review" as const, icon: Star },
    { label: "Tentang", desc: "Kenali Openly", view: "tentang" as const, icon: Users },
    { label: "Kontak", desc: "Hubungi kami", view: "kontak" as const, icon: Phone },
  ];

  return (
    <div>
      {/* ===== HERO ONLY (minimal, tidak numpuk) ===== */}
      <section className="relative overflow-hidden openly-pattern-mesh min-h-[calc(100vh-4rem)] flex items-center">
        <div className="absolute inset-0 -z-10">
          <div className="absolute -top-24 -right-24 size-96 rounded-full bg-primary/20 blur-3xl" />
          <div className="absolute top-40 -left-24 size-80 rounded-full bg-sky-300/20 blur-3xl" />
        </div>
        <div className="mx-auto w-full max-w-[1600px] px-4 sm:px-6 lg:px-10 py-12">
          <div className="grid items-center gap-10 lg:grid-cols-[1.2fr_1fr]">
            <div>
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-semibold text-primary"
              >
                <Sparkles className="size-3.5" />
                {settings.parent_company || "IR DESIGN KREASI"}
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.05, ease: [0.22, 1, 0.36, 1] }}
                className="mt-4 text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.05]"
              >
                <span className="openly-text-gradient">{hero.slogan || "Openly — Crafted For Your Growth"}</span>
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
                className="mt-5 max-w-xl text-base sm:text-lg text-muted-foreground leading-relaxed"
              >
                {hero.description}
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
                className="mt-7 flex flex-wrap gap-3"
              >
                <Button size="lg" onClick={() => navigate("order", { type: "GRAPHIC" })}>
                  Pesan Desain <ArrowRight className="size-4" />
                </Button>
                <Button size="lg" variant="outline" onClick={() => navigate("order", { type: "WEBSITE" })}>
                  Pesan Website <ArrowRight className="size-4" />
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="ghost"
                  className="text-primary hover:text-primary hover:bg-primary/10"
                >
                  <a href={waLink(settings.whatsapp, "Halo Openly, saya ingin berkonsultasi.")} target="_blank" rel="noopener noreferrer">
                    Konsultasi Gratis
                  </a>
                </Button>
              </motion.div>
            </div>

            {/* Visual */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="relative mx-auto w-full max-w-sm hidden lg:block"
            >
              <div className="relative aspect-square">
                <div className="absolute inset-0 rounded-[2.5rem] openly-gradient opacity-95" />
                <div className="absolute inset-3 rounded-[2rem] openly-pattern opacity-20" />
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute left-4 top-8 w-40 rounded-2xl bg-background/95 p-4 shadow-xl backdrop-blur"
                >
                  <div className="flex items-center gap-2">
                    <div className="size-9 rounded-lg openly-gradient" />
                    <div>
                      <div className="text-xs font-bold">Desain Logo</div>
                      <div className="text-[10px] text-muted-foreground">Mulai Rp 25.000</div>
                    </div>
                  </div>
                </motion.div>
                <motion.div
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  className="absolute right-4 bottom-10 w-44 rounded-2xl bg-background/95 p-4 shadow-xl backdrop-blur"
                >
                  <div className="text-xs font-semibold text-muted-foreground">Progress</div>
                  <div className="mt-2 h-1.5 w-full rounded-full bg-muted">
                    <div className="h-1.5 w-3/4 rounded-full openly-gradient" />
                  </div>
                  <div className="mt-2 text-xs font-bold">Sedang dikerjakan</div>
                </motion.div>
              </div>
            </motion.div>
          </div>

          {/* Navigasi cepat — tombol rapih, bukan section menumpuk */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-12 sm:mt-16"
          >
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground mb-3">
              Jelajahi Layanan
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
              {shortcuts.map((s, i) => {
                const Icon = s.icon;
                return (
                  <button
                    key={s.view}
                    onClick={() => navigate(s.view)}
                    className="group flex items-center gap-3 rounded-xl border border-border/70 bg-card px-4 py-3 text-left transition-all hover:border-primary/40 hover:shadow-md hover:-translate-y-0.5"
                  >
                    <div className="inline-flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                      <Icon className="size-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-bold truncate">{s.label}</div>
                      <div className="text-[11px] text-muted-foreground truncate">{s.desc}</div>
                    </div>
                    <ChevronRight className="size-4 text-muted-foreground/50 group-hover:text-primary transition-colors shrink-0" />
                  </button>
                );
              })}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
