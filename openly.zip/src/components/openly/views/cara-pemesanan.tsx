"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/openly/reveal";
import { SectionHeading } from "@/components/openly/section-heading";
import { useRouter } from "@/store/router";
import { useSiteContent } from "@/hooks/use-site-content";
import { ClipboardList, FileText, CheckCircle2, Loader2, PackageCheck } from "lucide-react";

const STEPS = [
  { icon: ClipboardList, title: "1. Pilih Layanan", desc: "Tentukan kebutuhan Anda: jasa desain grafis atau pembuatan website. Pilih kategori dan paket yang sesuai." },
  { icon: FileText, title: "2. Isi Formulir Pemesanan", desc: "Lengkapi data pemesan, deskripsi kebutuhan, deadline, dan unggah referensi gambar bila ada." },
  { icon: CheckCircle2, title: "3. Konfirmasi Pesanan", desc: "Setelah dikirim, Anda mendapatkan nomor pesanan dan nomor antrean unik beserta tautan pelacakan." },
  { icon: Loader2, title: "4. Pengerjaan", desc: "Tim Openly memverifikasi pesanan, lalu pengerjaan dilakukan sesuai antrean dengan estimasi waktu jelas." },
  { icon: PackageCheck, title: "5. Hasil & Serah Terima", desc: "Hasil pekerjaan dikirim. Pelanggan kerja sama dapat mengunduh hasil melalui akun masing-masing." },
];

const RULES = [
  "Pesanan akan diproses setelah konfirmasi dan, jika berlaku, pembayaran dilakukan.",
  "Estimasi waktu mulai berlaku setelah pesanan masuk antrean pengerjaan.",
  "Revisi mengikuti ketentuan paket yang dipilih.",
  "Pelanggan umum dapat memesan tanpa membuat akun.",
  "Pelanggan kerja sama mendapatkan akses unduh hasil pekerjaan secara aman.",
  "Komunikasi utama dilakukan melalui WhatsApp untuk respons cepat.",
];

export function CaraPemesananView() {
  const navigate = useRouter((s) => s.navigate);
  const { data } = useSiteContent();
  const flow = data?.sections?.order_flow || {};

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Cara Pemesanan"
          title={flow.title || "Alur Pemesanan Openly"}
          description="Proses pemesanan yang sederhana, transparan, dan mudah diikuti."
        />

        <div className="mt-10 space-y-4">
          {STEPS.map((step, i) => (
            <Reveal key={i} delay={i * 0.06}>
              <Card className="flex flex-col sm:flex-row gap-4 p-5 border-border/70 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 sm:flex-col sm:items-start">
                  <div className="inline-flex size-12 items-center justify-center rounded-xl openly-gradient text-white shadow-md">
                    <step.icon className="size-5" />
                  </div>
                </div>
                <div>
                  <h3 className="text-base font-bold">{step.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
                </div>
              </Card>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10">
          <Card className="p-6 sm:p-8 border-border/70 shadow-sm">
            <h3 className="text-lg font-bold">Ketentuan Umum</h3>
            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {RULES.map((r, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="mt-1 inline-flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
                    <CheckCircle2 className="size-3" />
                  </span>
                  <span className="text-foreground/80">{r}</span>
                </li>
              ))}
            </ul>
          </Card>
        </Reveal>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button onClick={() => navigate("order", { type: "GRAPHIC" })} size="lg">
            Pesan Desain Grafis
          </Button>
          <Button onClick={() => navigate("order", { type: "WEBSITE" })} size="lg" variant="outline">
            Pesan Website
          </Button>
        </div>
      </div>
    </div>
  );
}
