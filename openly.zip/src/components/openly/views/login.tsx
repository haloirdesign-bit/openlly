"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Reveal } from "@/components/openly/reveal";
import { useRouter } from "@/store/router";
import { toast } from "sonner";
import { waLink } from "@/hooks/use-site-content";
import { LogIn, Loader2, ShieldCheck, UserRound, ArrowLeft } from "lucide-react";

export function LoginView() {
  const navigate = useRouter((s) => s.navigate);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Email dan password wajib diisi.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Login gagal.");
        return;
      }
      toast.success("Login berhasil.");
      if (data.user.role === "ADMIN") {
        navigate("admin");
      } else {
        navigate("portal");
      }
      // reload to refresh session-aware components
      setTimeout(() => window.location.reload(), 300);
    } catch {
      toast.error("Terjadi kesalahan jaringan.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-md px-4 sm:px-6 lg:px-8">
        <Reveal>
          <button
            onClick={() => navigate("beranda")}
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-4"
          >
            <ArrowLeft className="size-4" /> Beranda
          </button>
          <Card className="overflow-hidden border-border/70 shadow-md">
            <div className="relative openly-gradient p-6 text-white text-center">
              <div className="absolute inset-0 openly-pattern opacity-10" />
              <div className="relative">
                <div className="mx-auto inline-flex size-12 items-center justify-center rounded-full bg-white/20 backdrop-blur ring-4 ring-white/30">
                  <UserRound className="size-6" />
                </div>
                <h1 className="mt-3 text-xl font-bold">Login</h1>
                <p className="mt-1 text-sm text-white/85">
                  Akun khusus pelanggan kerja sama Openly.
                </p>
              </div>
            </div>

            <form onSubmit={submit} className="p-6 sm:p-8 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="email@anda.com"
                  autoComplete="email"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                />
              </div>
              <Button type="submit" className="w-full" size="lg" disabled={loading}>
                {loading ? <Loader2 className="size-4 animate-spin" /> : <LogIn className="size-4" />}
                Masuk
              </Button>

              <div className="rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground leading-relaxed">
                <ShieldCheck className="size-4 text-primary inline mr-1" />
                Belum punya akun? Akun pelanggan kerja sama hanya dapat dibuat oleh admin.
                Hubungi kami untuk informasi pendaftaran kerja sama.
              </div>

              <Button asChild variant="outline" className="w-full">
                <a href={waLink(undefined, "Halo Openly, saya tertarik menjadi pelanggan kerja sama. Mohon info lebih lanjut.")} target="_blank" rel="noopener noreferrer">
                  Tanya tentang Kerja sama
                </a>
              </Button>
            </form>
          </Card>
        </Reveal>
      </div>
    </div>
  );
}
