"use client";

import { ServiceExplorer } from "@/components/openly/service-explorer";
import { Reveal } from "@/components/openly/reveal";

export function JasaDesainView() {
  return (
    <div>
      <section className="relative overflow-hidden openly-pattern-mesh border-b border-border/60">
        <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10 py-12 sm:py-16">
          <Reveal>
            <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-primary mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Jasa Desain Grafis
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight">
              <span className="openly-text-gradient">Desain Grafis Profesional</span>
            </h1>
            <p className="mt-4 max-w-2xl text-muted-foreground leading-relaxed">
              Identitas visual yang kuat untuk membangun kesan pertama yang berkesan. Mulai dari
              logo, banner, konten media sosial, hingga kebutuhan promosi lainnya.
            </p>
          </Reveal>
        </div>
      </section>
      <ServiceExplorer
        type="GRAPHIC"
        eyebrow="Layanan Desain"
        title="Pilihan Layanan Desain Grafis"
        description="Setiap layanan dirancang dengan estimasi waktu jelas dan ketentuan revisi yang transparan."
      />
    </div>
  );
}
