"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/openly/reveal";
import { SectionHeading } from "@/components/openly/section-heading";
import { TestimonialCarousel } from "@/components/openly/testimonial-carousel";
import { useSiteContent } from "@/hooks/use-site-content";
import { useRouter } from "@/store/router";
import { Star, ExternalLink, Sparkles, MessageCircle } from "lucide-react";

export function ReviewView() {
  const navigate = useRouter((s) => s.navigate);
  const { data } = useSiteContent();
  const settings = data?.settings || {};
  const testimonials: any[] = data?.sections?.testimonials || [];
  const reviewSection = data?.sections?.review_section || {};

  const googleUrl = settings.google_review || reviewSection.googleUrl || "https://g.page/r/CU_Ah0Evi1nwEAI/review";
  const googleRating = reviewSection.googleRating || "4.9";
  const googleCount = reviewSection.googleCount || "50+";

  const socials = [
    { label: "Instagram", url: settings.instagram, emoji: "📸" },
    { label: "TikTok", url: settings.tiktok, emoji: "🎵" },
    { label: "Facebook", url: settings.facebook, emoji: "👍" },
    { label: "Behance", url: settings.behance, emoji: "🎨" },
  ].filter((x) => x.url);

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Review"
          title={reviewSection.title || "Apa Kata Pelanggan"}
          description={reviewSection.desc || "Cerita dan ulasan dari pelanggan yang telah berkembang bersama Openly."}
        />

        {/* Google review highlight card */}
        <Reveal className="mt-10">
          <Card className="overflow-hidden border-border/70 shadow-md">
            <div className="grid lg:grid-cols-[1fr_1.2fr]">
              <div className="relative openly-gradient p-6 sm:p-8 text-white flex flex-col justify-center">
                <div className="absolute inset-0 openly-pattern opacity-10" />
                <div className="relative">
                  <div className="flex items-center gap-2 mb-2">
                    { }
                    <img
                      src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCI+PGNpcmNsZSBjeD0iMjQiIGN5PSIyNCIgcj0iMjQiIGZpbGw9IiNmZmYiIG9wYWNpdHk9IjAuMiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNCAxNGw0IDggNC04eiIvPjwvc3ZnPg=="
                      alt=""
                      className="hidden"
                    />
                    <span className="text-3xl font-black">{googleRating}</span>
                    <div className="flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className="size-4 fill-amber-300 text-amber-300" />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-white/85">
                    Berdasarkan {googleCount} ulasan di Google
                  </p>
                  <Button
                    asChild
                    size="sm"
                    className="mt-5 bg-white text-primary hover:bg-white/90"
                  >
                    <a href={googleUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="size-4" /> Lihat / Beri Ulasan Google
                    </a>
                  </Button>
                </div>
              </div>
              <div className="p-6 sm:p-8 flex flex-col justify-center">
                <h3 className="text-lg font-bold">Pengalaman Pelanggan Openly</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                  Kami senang membantu bisnis tumbuh. Lihat apa kata mereka, dan bagikan
                  pengalaman Anda bersama Openly melalui ulasan Google.
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button asChild variant="outline" size="sm">
                    <a href={googleUrl} target="_blank" rel="noopener noreferrer">
                      <Star className="size-4 text-amber-400" /> Tulis Ulasan
                    </a>
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => navigate("kontak")}>
                    <MessageCircle className="size-4" /> Hubungi Kami
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </Reveal>

        {/* Auto-scroll testimonials row (marquee) */}
        {testimonials.length > 0 && (
          <Reveal className="mt-10">
            <h3 className="text-center text-lg font-bold mb-5">Testimoni Pelanggan</h3>
            <TestimonialCarousel
              items={testimonials.map((t) => ({ name: t.name, role: t.role, text: t.text, rating: t.rating }))}
              variant="row"
              interval={3500}
            />
          </Reveal>
        )}

        {/* Featured testimonial carousel (alternating, auto-scroll) */}
        {testimonials.length > 0 && (
          <Reveal className="mt-10">
            <div className="max-w-2xl mx-auto">
              <TestimonialCarousel
                items={testimonials.map((t) => ({ name: t.name, role: t.role, text: t.text, rating: t.rating }))}
                variant="card"
                interval={4500}
              />
            </div>
          </Reveal>
        )}

        {/* Social media */}
        {socials.length > 0 && (
          <Reveal className="mt-12">
            <Card className="p-6 sm:p-8 border-border/70">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="size-5 text-primary" />
                <h3 className="text-lg font-bold">Ikuti Openly</h3>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {socials.map((s) => (
                  <a
                    key={s.label}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group rounded-xl border border-border/70 p-4 hover:border-primary/40 hover:bg-muted/40 transition-colors text-center"
                  >
                    <div className="text-2xl mb-1">{s.emoji}</div>
                    <div className="text-sm font-bold">{s.label}</div>
                    <div className="mt-1 text-xs text-primary inline-flex items-center gap-1">
                      Kunjungi <ExternalLink className="size-3" />
                    </div>
                  </a>
                ))}
              </div>
            </Card>
          </Reveal>
        )}

        {/* CTA */}
        <Reveal className="mt-10 text-center">
          <p className="text-sm text-muted-foreground mb-4">
            Siap berkembang bersama Openly?
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Button onClick={() => navigate("order", { type: "GRAPHIC" })}>Pesan Desain</Button>
            <Button variant="outline" onClick={() => navigate("order", { type: "WEBSITE" })}>Pesan Website</Button>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
