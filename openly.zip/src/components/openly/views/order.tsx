"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Reveal } from "@/components/openly/reveal";
import { FileUploader } from "@/components/openly/file-uploader";
import { useRouter } from "@/store/router";
import { useServices } from "@/hooks/use-services";
import { toast } from "sonner";
import { formatIDR } from "@/lib/format";
import {
  ArrowLeft,
  ArrowRight,
  Send,
  Loader2,
  CheckCircle2,
  ShieldCheck,
} from "lucide-react";
import type { ServiceType } from "@/lib/types";

export function OrderView() {
  const { view, params, navigate } = useRouter();
  const type = (params.type as ServiceType) || "GRAPHIC";
  const { services, loading } = useServices(type);

  // preselect service/package
  const preselected = params.service
    ? services.find((s) => s.slug === params.service)
    : undefined;
  const preselectedPkg = params.pkg
    ? services.flatMap((s) => s.packages).find((p) => p.id === params.pkg)
    : undefined;

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [serviceId, setServiceId] = useState<string>(preselected?.id || "");
  const [pkgId, setPkgId] = useState<string>(preselectedPkg?.id || "");

  // graphic-specific
  const [ukuran, setUkuran] = useState("");
  const [warna, setWarna] = useState("");
  const [deadline, setDeadline] = useState("");
  const [kebutuhan, setKebutuhan] = useState("");
  const [catatan, setCatatan] = useState("");

  // website-specific
  const [namaBisnis, setNamaBisnis] = useState("");
  const [tujuan, setTujuan] = useState("");
  const [fitur, setFitur] = useState("");
  const [referensi, setReferensi] = useState("");
  const [domain, setDomain] = useState("");

  const [files, setFiles] = useState<File[]>([]);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const selectedService = services.find((s) => s.id === serviceId);
  const selectedPkg = selectedService?.packages.find((p) => p.id === pkgId);

  useEffect(() => {
    if (preselected && !serviceId) setServiceId(preselected.id);
  }, [preselected, serviceId]);
  useEffect(() => {
    if (preselectedPkg && !pkgId) setPkgId(preselectedPkg.id);
  }, [preselectedPkg, pkgId]);

  const validate = (): string | null => {
    if (!name || name.trim().length < 2) return "Nama pemesan wajib diisi.";
    if (!/^[0-9+\-\s]{8,18}$/.test(phone)) return "Nomor WhatsApp tidak valid (8–18 digit).";
    if (!serviceId) return "Pilih jenis layanan terlebih dahulu.";
    if (!kebutuhan || kebutuhan.trim().length < 5) return "Deskripsi kebutuhan wajib diisi.";
    if (type === "WEBSITE" && (!namaBisnis || !tujuan)) return "Nama bisnis dan tujuan website wajib diisi.";
    if (!deadline) return "Deadline wajib diisi.";
    return null;
  };

  const handleOpenConfirm = () => {
    const err = validate();
    if (err) {
      toast.error(err);
      return;
    }
    setConfirmOpen(true);
  };

  const buildDetails = () => {
    if (type === "GRAPHIC") {
      return {
        jenisDesain: selectedService?.name || "",
        paket: selectedPkg?.name || "",
        kebutuhan,
        ukuran,
        warna,
        deadline,
        catatan,
      };
    }
    return {
      jenisWebsite: selectedService?.name || "",
      paket: selectedPkg?.name || "",
      namaBisnis,
      tujuan,
      fitur: fitur ? fitur.split(",").map((s) => s.trim()).filter(Boolean) : [],
      referensi,
      domain,
      deadline,
      catatan,
    };
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.append("customerName", name);
      fd.append("customerPhone", phone);
      fd.append("serviceType", type);
      fd.append("serviceId", serviceId);
      if (pkgId) fd.append("packageId", pkgId);
      fd.append("details", JSON.stringify(buildDetails()));
      files.forEach((f) => fd.append("files", f, f.name));

      const res = await fetch("/api/orders/create", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Gagal membuat pesanan.");
        return;
      }
      setConfirmOpen(false);
      toast.success("Pesanan berhasil dibuat!");
      navigate("confirmation", {
        orderNumber: data.orderNumber,
        queueNumber: data.queueNumber,
        token: data.token,
        type: data.serviceType,
      });
    } catch {
      toast.error("Terjadi kesalahan jaringan. Coba lagi.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="py-10 sm:py-14">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <button
            onClick={() => navigate(type === "GRAPHIC" ? "jasa-desain" : "jasa-website")}
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mb-4"
          >
            <ArrowLeft className="size-4" /> Kembali
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Formulir Pemesanan{" "}
            <span className="openly-text-gradient">
              {type === "GRAPHIC" ? "Jasa Desain Grafis" : "Jasa Pembuatan Website"}
            </span>
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Lengkapi data berikut. Pelanggan umum dapat memesan tanpa membuat akun.
          </p>
        </Reveal>

        <Card className="mt-6 p-6 sm:p-8 border-border/70 shadow-sm">
          {/* Identitas */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="name">Nama Pemesan <span className="text-destructive">*</span></Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nama lengkap" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="phone">Nomor WhatsApp <span className="text-destructive">*</span></Label>
              <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="08xxxxxxxxxx" inputMode="tel" />
            </div>
          </div>

          {/* Layanan & Paket */}
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>{type === "GRAPHIC" ? "Jenis Desain" : "Jenis Website"} <span className="text-destructive">*</span></Label>
              {loading ? (
                <Skeleton className="h-9 w-full" />
              ) : (
                <Select value={serviceId} onValueChange={(v) => { setServiceId(v); setPkgId(""); }}>
                  <SelectTrigger><SelectValue placeholder="Pilih layanan" /></SelectTrigger>
                  <SelectContent>
                    {services.map((s) => (
                      <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>Paket / Layanan {selectedService?.packages.length ? "" : "(opsional)"}</Label>
              <Select value={pkgId} onValueChange={setPkgId} disabled={!selectedService?.packages.length}>
                <SelectTrigger><SelectValue placeholder={selectedService?.packages.length ? "Pilih paket" : "Tidak ada paket"} /></SelectTrigger>
                <SelectContent>
                  {selectedService?.packages.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} — {p.priceLabel || (p.price != null ? formatIDR(p.price) : "Hubungi kami")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Detail per type */}
          <div className="mt-5 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="kebutuhan">
                {type === "GRAPHIC" ? "Deskripsi Kebutuhan Desain" : "Deskripsi Kebutuhan Website"} <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="kebutuhan"
                value={kebutuhan}
                onChange={(e) => setKebutuhan(e.target.value)}
                rows={4}
                placeholder={type === "GRAPHIC" ? "Jelaskan konsep, gaya, dan kebutuhan desain yang Anda inginkan..." : "Jelaskan tujuan dan kebutuhan website Anda..."}
              />
            </div>

            {type === "GRAPHIC" ? (
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="ukuran">Ukuran Desain</Label>
                  <Input id="ukuran" value={ukuran} onChange={(e) => setUkuran(e.target.value)} placeholder="Mis. 1080x1080 px / A3" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="warna">Warna / Referensi Desain</Label>
                  <Input id="warna" value={warna} onChange={(e) => setWarna(e.target.value)} placeholder="Mis. biru & putih / minimalis" />
                </div>
              </div>
            ) : (
              <>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="bisnis">Nama Bisnis <span className="text-destructive">*</span></Label>
                    <Input id="bisnis" value={namaBisnis} onChange={(e) => setNamaBisnis(e.target.value)} placeholder="Nama bisnis/brand" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="tujuan">Tujuan Website <span className="text-destructive">*</span></Label>
                    <Input id="tujuan" value={tujuan} onChange={(e) => setTujuan(e.target.value)} placeholder="Mis. meningkatkan penjualan online" />
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="fitur">Fitur yang Dibutuhkan</Label>
                    <Input id="fitur" value={fitur} onChange={(e) => setFitur(e.target.value)} placeholder="Pisahkan dengan koma: katalog, form, chat" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="referensi">Referensi Website (opsional)</Label>
                    <Input id="referensi" value={referensi} onChange={(e) => setReferensi(e.target.value)} placeholder="URL referensi" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="domain">Domain / Hosting (jika relevan)</Label>
                  <Input id="domain" value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="Mis. punya domain sendiri / butuh domain baru" />
                </div>
              </>
            )}

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="deadline">Deadline yang Diinginkan <span className="text-destructive">*</span></Label>
                <Input id="deadline" type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="catatan">Catatan Tambahan</Label>
              <Textarea id="catatan" value={catatan} onChange={(e) => setCatatan(e.target.value)} rows={2} placeholder="Catatan tambahan untuk tim kami (opsional)" />
            </div>

            <div>
              <FileUploader files={files} onChange={setFiles} />
            </div>
          </div>

          <div className="mt-6 flex flex-col-reverse sm:flex-row gap-3 sm:justify-between sm:items-center">
            <p className="text-xs text-muted-foreground inline-flex items-center gap-1.5">
              <ShieldCheck className="size-3.5 text-primary" /> Data Anda aman & tidak dibagikan ke pihak ketiga.
            </p>
            <Button onClick={handleOpenConfirm} size="lg" disabled={submitting}>
              <Send className="size-4" /> Kirim Pesanan
            </Button>
          </div>
        </Card>
      </div>

      {/* Confirm modal */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="size-5 text-primary" /> Konfirmasi Pesanan
            </DialogTitle>
            <DialogDescription>
              Pastikan data berikut sudah benar sebelum dikirim.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <Row label="Nama" value={name} />
            <Row label="WhatsApp" value={phone} />
            <Row label="Layanan" value={selectedService?.name || "-"} />
            {selectedPkg && <Row label="Paket" value={selectedPkg.name} />}
            <Row label="Deadline" value={deadline || "-"} />
            {files.length > 0 && <Row label="Lampiran" value={`${files.length} file`} />}
          </div>
          <DialogFooter className="flex-col sm:flex-col gap-2">
            <Button onClick={handleSubmit} disabled={submitting} className="w-full">
              {submitting ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              {submitting ? "Mengirim..." : "Ya, Kirim Pesanan"}
            </Button>
            <Button variant="outline" onClick={() => setConfirmOpen(false)} className="w-full" disabled={submitting}>
              Periksa Kembali
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3 border-b border-border/60 pb-1.5">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-right">{value}</span>
    </div>
  );
}
