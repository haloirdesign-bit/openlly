"use client";

import { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { PackageCard } from "@/components/openly/package-card";
import { PackageDetailModal } from "@/components/openly/package-detail-modal";
import { SectionHeading } from "@/components/openly/section-heading";
import { Reveal } from "@/components/openly/reveal";
import { useRouter } from "@/store/router";
import { usePackages } from "@/hooks/use-services";
import type { PackageDTO } from "@/lib/types";

export function PricelistView() {
  const navigate = useRouter((s) => s.navigate);
  const { packages, loading } = usePackages();
  const [activePkg, setActivePkg] = useState<PackageDTO | null>(null);
  const [activeServiceName, setActiveServiceName] = useState("");

  const graphic = packages.filter((p) => p.serviceType === "GRAPHIC");
  const website = packages.filter((p) => p.serviceType === "WEBSITE");

  const orderPkg = (pkg: PackageDTO) => {
    navigate("order", { type: pkg.serviceType, pkg: pkg.id });
  };

  const renderGrid = (list: typeof packages) => {
    if (loading)
      return (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-72 w-full rounded-xl" />
          ))}
        </div>
      );
    if (list.length === 0)
      return (
        <div className="rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          Belum ada paket. Hubungi kami untuk penawaran.
        </div>
      );
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((p) => (
          <PackageCard
            key={p.id}
            pkg={p}
            serviceName={p.serviceName}
            onViewDetail={() => {
              setActivePkg(p);
              setActiveServiceName(p.serviceName);
            }}
            onOrder={() => orderPkg(p)}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10">
        <SectionHeading
          eyebrow="Pricelist"
          title="Daftar Harga Paket"
          description="Harga dan fitur paket layanan Openly. Pilih kategori untuk melihat detail."
        />
        <Reveal className="mt-8">
          <Tabs defaultValue="GRAPHIC" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
              <TabsTrigger value="GRAPHIC">Desain Grafis</TabsTrigger>
              <TabsTrigger value="WEBSITE">Pembuatan Website</TabsTrigger>
            </TabsList>
            <TabsContent value="GRAPHIC" className="mt-8">
              {renderGrid(graphic)}
            </TabsContent>
            <TabsContent value="WEBSITE" className="mt-8">
              {renderGrid(website)}
            </TabsContent>
          </Tabs>
        </Reveal>
      </div>

      <PackageDetailModal
        pkg={activePkg}
        serviceName={activeServiceName}
        open={!!activePkg}
        onOpenChange={(v) => !v && setActivePkg(null)}
        onOrder={() => activePkg && orderPkg(activePkg)}
      />
    </div>
  );
}
