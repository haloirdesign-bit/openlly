"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Reveal } from "@/components/openly/reveal";
import { SectionHeading } from "@/components/openly/section-heading";
import { PackageDetailModal } from "@/components/openly/package-detail-modal";
import { useRouter } from "@/store/router";
import { useServices } from "@/hooks/use-services";
import { NICHES, nicheInfo, type ServiceDTO, type PackageDTO, type ServiceType } from "@/lib/types";
import { Check, ArrowRight, Palette, Globe, Package } from "lucide-react";

export function NicheView() {
  const { params, navigate } = useRouter();
  const nicheId = params.niche || "baby-kids";
  const info = nicheInfo(nicheId);

  // fetch all 3 types for this niche
  const { services: graphic, loading: lg } = useServices("GRAPHIC", nicheId);
  const { services: website, loading: lw } = useServices("WEBSITE", nicheId);
  const { services: bundles, loading: lb } = useServices("BUNDLE", nicheId);

  const [activePkg, setActivePkg] = useState<PackageDTO | null>(null);
  const [activeServiceName, setActiveServiceName] = useState("");

  const order = (svc: ServiceDTO, pkgId?: string) => {
    navigate("order", {
      type: svc.type === "BUNDLE" ? "WEBSITE" : (svc.type as ServiceType),
      service: svc.slug,
      ...(pkgId ? { pkg: pkgId } : {}),
    });
  };

  // if no services for niche yet, show general fallback message
  const hasAny = graphic.length + website.length + bundles.length > 0;

  return (
    <div className="py-12 sm:py-16">
      {/* Hero niche */}
      <section className="relative overflow-hidden openly-pattern-mesh border-b border-border/60">
        <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10 py-10 sm:py-14">
          <Reveal>
            <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-primary mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Layanan Kategori
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight">
              <span className="openly-text-gradient">
                {info?.emoji} {info?.label || "Layanan"}
              </span>
            </h1>
            <p className="mt-3 max-w-2xl text-muted-foreground leading-relaxed">
              {info?.desc || "Pilih layanan desain dan website sesuai kebutuhan bisnis Anda."}
            </p>
          </Reveal>

          {/* Niche pills */}
          <div className="mt-6 flex flex-wrap gap-2">
            {NICHES.map((n) => (
              <button
                key={n.id}
                onClick={() => navigate("niche", { niche: n.id })}
                className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                  n.id === nicheId
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border/70 bg-background text-foreground/70 hover:border-primary/40 hover:text-foreground"
                }`}
              >
                <span>{n.emoji}</span>
                {n.short}
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10 mt-10 space-y-12">
        {/* Design services */}
        <section>
          <Reveal>
            <div className="flex items-center gap-3 mb-2">
              <div className="inline-flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Palette className="size-5" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold">Desain Grafis</h2>
                <p className="text-sm text-muted-foreground">Paket desain untuk {info?.label}</p>
              </div>
            </div>
          </Reveal>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {lg
              ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-64 rounded-xl" />)
              : graphic.map((s, i) => <NicheServiceCard key={s.id} service={s} index={i} onOrder={() => order(s)} onViewPkg={(p) => { setActivePkg(p); setActiveServiceName(s.name); }} />)}
          </div>
        </section>

        {/* Website services */}
        <section>
          <Reveal>
            <div className="flex items-center gap-3 mb-2">
              <div className="inline-flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Globe className="size-5" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold">Website</h2>
                <p className="text-sm text-muted-foreground">Website untuk {info?.label} — sudah termasuk online</p>
              </div>
            </div>
          </Reveal>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {lw
              ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-64 rounded-xl" />)
              : website.map((s, i) => <NicheServiceCard key={s.id} service={s} index={i} onOrder={() => order(s)} onViewPkg={(p) => { setActivePkg(p); setActiveServiceName(s.name); }} />)}
          </div>
        </section>

        {/* Bundle services */}
        {(lb || bundles.length > 0) && (
          <section>
            <Reveal>
              <div className="flex items-center gap-3 mb-2">
                <div className="inline-flex size-10 items-center justify-center rounded-xl openly-gradient text-white">
                  <Package className="size-5" />
                </div>
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold">Paket Lengkap Desain + Website</h2>
                  <p className="text-sm text-muted-foreground">Hemat dibanding pesan terpisah</p>
                </div>
              </div>
            </Reveal>
            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {lb
                ? Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-64 rounded-xl" />)
                : bundles.map((s, i) => <NicheServiceCard key={s.id} service={s} index={i} onOrder={() => order(s)} onViewPkg={(p) => { setActivePkg(p); setActiveServiceName(s.name); }} highlight />)}
            </div>
          </section>
        )}

        {!hasAny && !lg && !lw && !lb && (
          <Card className="p-10 text-center border-dashed">
            <p className="text-sm text-muted-foreground">
              Layanan untuk kategori ini sedang disiapkan. Hubungi kami untuk penawaran.
            </p>
            <Button className="mt-4" onClick={() => navigate("kontak")}>Hubungi Kami</Button>
          </Card>
        )}
      </div>

      <PackageDetailModal
        pkg={activePkg}
        serviceName={activeServiceName}
        open={!!activePkg}
        onOpenChange={(v) => !v && setActivePkg(null)}
        onOrder={() => {
          if (activePkg) {
            const svc = [...graphic, ...website, ...bundles].find((s) => s.packages.some((p) => p.id === activePkg.id));
            if (svc) order(svc, activePkg.id);
          }
        }}
      />
    </div>
  );
}

function NicheServiceCard({
  service,
  index,
  onOrder,
  onViewPkg,
  highlight,
}: {
  service: ServiceDTO;
  index: number;
  onOrder: () => void;
  onViewPkg: (p: PackageDTO) => void;
  highlight?: boolean;
}) {
  const firstPkg = service.packages[0];
  return (
    <Reveal delay={index * 0.05} className="h-full">
      <Card className={`relative h-full overflow-hidden p-6 ${highlight ? "border-primary/40 ring-1 ring-primary/20 shadow-md" : "border-border/70 shadow-sm"} hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex flex-col`}>
        {highlight && (
          <div className="absolute -right-10 -top-10 size-28 rounded-full bg-primary/10 blur-2xl" />
        )}
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-bold">{service.name}</h3>
          {highlight && <Badge className="openly-gradient text-white border-0">Hemat</Badge>}
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 flex-1">{service.description}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {service.priceLabel && (
            <Badge variant="secondary" className="bg-primary/10 text-primary border-0 font-semibold">
              {service.priceLabel}
            </Badge>
          )}
          {service.estDuration && (
            <Badge variant="outline" className="font-normal">{service.estDuration}</Badge>
          )}
        </div>
        {service.options && service.options.length > 0 && (
          <ul className="mt-3 space-y-1">
            {service.options.slice(0, 3).map((o, i) => (
              <li key={i} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Check className="size-3 text-primary" /> {o}
              </li>
            ))}
          </ul>
        )}
        <div className="mt-5 flex gap-2">
          <Button onClick={onOrder} size="sm" className="flex-1">Pesan <ArrowRight className="size-4" /></Button>
          {firstPkg && (
            <Button onClick={() => onViewPkg(firstPkg)} variant="outline" size="sm">Detail</Button>
          )}
        </div>
      </Card>
    </Reveal>
  );
}
