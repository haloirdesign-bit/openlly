"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/openly/reveal";
import { SectionHeading } from "@/components/openly/section-heading";
import { useSiteContent, waLink } from "@/hooks/use-site-content";
import { useRouter } from "@/store/router";
import { MessageCircle, MapPin, Clock, Mail, ArrowRight } from "lucide-react";

export function KontakView() {
  const navigate = useRouter((s) => s.navigate);
  const { data } = useSiteContent();
  const settings = data?.settings || {};
  const contact = data?.sections?.contact || {};

  const socials = [
    { label: "Instagram", url: settings.instagram },
    { label: "TikTok", url: settings.tiktok },
    { label: "Facebook", url: settings.facebook },
    { label: "Behance", url: settings.behance },
  ].filter((x) => x.url);

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Hubungi Kami"
          title={contact.title || "Hubungi Kami"}
          description={contact.desc || "Ada pertanyaan atau siap memesan? Tim Openly siap membantu Anda."}
        />

        <div className="mt-10 grid gap-4 lg:grid-cols-2">
          <Reveal>
            <Card className="h-full p-6 sm:p-8 border-border/70 shadow-sm">
              <h3 className="text-lg font-bold">Informasi Kontak</h3>
              <ul className="mt-4 space-y-4 text-sm">
                <li>
                  <div className="flex items-start gap-3">
                    <div className="inline-flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <MessageCircle className="size-5" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground">WhatsApp</div>
                      <a
                        href={waLink(settings.whatsapp || contact.whatsapp)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium hover:text-primary transition-colors"
                      >
                        {settings.whatsapp_display || "Chat WhatsApp"}
                      </a>
                    </div>
                  </div>
                </li>
                {settings.email_contact && (
                  <li>
                    <div className="flex items-start gap-3">
                      <div className="inline-flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        <Mail className="size-5" />
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-muted-foreground">Email</div>
                        <div className="font-medium">{settings.email_contact}</div>
                      </div>
                    </div>
                  </li>
                )}
                <li>
                  <div className="flex items-start gap-3">
                    <div className="inline-flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <MapPin className="size-5" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground">Alamat</div>
                      <div className="font-medium leading-relaxed">{settings.address || contact.address}</div>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="flex items-start gap-3">
                    <div className="inline-flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <Clock className="size-5" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground">Jam Operasional</div>
                      <div className="font-medium">{contact.hours || "Senin–Sabtu, 08.00–21.00 WIB"}</div>
                    </div>
                  </div>
                </li>
              </ul>

              <div className="mt-6 flex flex-wrap gap-2">
                <Button asChild>
                  <a href={waLink(settings.whatsapp, "Halo Openly, saya ingin bertanya.")} target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="size-4" /> Chat WhatsApp
                  </a>
                </Button>
                <Button variant="outline" onClick={() => navigate("order", { type: "GRAPHIC" })}>
                  Pesan Sekarang <ArrowRight className="size-4" />
                </Button>
              </div>
            </Card>
          </Reveal>

          <Reveal delay={0.08}>
            <Card className="h-full p-6 sm:p-8 border-border/70 shadow-sm">
              <h3 className="text-lg font-bold">Media Sosial</h3>
              {socials.length === 0 ? (
                <p className="mt-4 text-sm text-muted-foreground">
                  Media sosial belum dikonfigurasi. Silakan hubungi kami melalui WhatsApp.
                </p>
              ) : (
                <div className="mt-4 grid grid-cols-2 gap-3">
                  {socials.map((s) => (
                    <a
                      key={s.label}
                      href={s.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-xl border border-border/70 p-4 hover:border-primary/40 hover:bg-muted/40 transition-colors"
                    >
                      <div className="text-sm font-bold">{s.label}</div>
                      <div className="mt-1 text-xs text-primary inline-flex items-center gap-1">
                        Kunjungi <ArrowRight className="size-3" />
                      </div>
                    </a>
                  ))}
                </div>
              )}

              <div className="mt-6 rounded-xl bg-muted/40 p-4">
                <h4 className="text-sm font-bold">Pelanggan Kerja sama</h4>
                <p className="mt-1 text-xs text-muted-foreground">
                  Sudah menjadi pelanggan kerja sama? Masuk ke akun Anda untuk mengelola pesanan.
                </p>
                <Button variant="outline" size="sm" className="mt-3" onClick={() => navigate("login")}>
                  Login Pelanggan
                </Button>
              </div>
            </Card>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
