"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/openly/reveal";
import { useRouter } from "@/store/router";
import { toast } from "sonner";
import { useSiteContent, waLink } from "@/hooks/use-site-content";
import { CheckCircle2, Copy, Hash, FileText, ArrowRight, Search, Home } from "lucide-react";

export function ConfirmationView() {
  const { params, navigate } = useRouter();
  const { data } = useSiteContent();
  const settings = data?.settings || {};
  const [copied, setCopied] = useState(false);

  const orderNumber = params.orderNumber || "";
  const queueNumber = params.queueNumber || "";
  const token = params.token || "";
  const type = params.type || "GRAPHIC";

  useEffect(() => {
    if (!orderNumber) {
      toast.error("Data pesanan tidak ditemukan.");
      navigate("beranda");
    }
  }, [orderNumber, navigate]);

  const trackUrl = typeof window !== "undefined" ? `${window.location.origin}/#/track?token=${token}` : "";

  const copyOrder = () => {
    navigator.clipboard.writeText(orderNumber);
    setCopied(true);
    toast.success("Nomor pesanan disalin.");
    setTimeout(() => setCopied(false), 1800);
  };

  const waMessage = `Halo Openly, saya baru saja memesan ${type === "GRAPHIC" ? "jasa desain grafis" : "jasa pembuatan website"} dengan nomor pesanan ${orderNumber} (antrean #${queueNumber}). Mohon info selanjutnya.`;

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <Card className="overflow-hidden border-border/70 shadow-md text-center">
            <div className="relative openly-gradient p-8 text-white">
              <div className="absolute inset-0 openly-pattern opacity-10" />
              <div className="relative">
                <div className="mx-auto inline-flex size-16 items-center justify-center rounded-full bg-white/20 backdrop-blur ring-4 ring-white/30">
                  <CheckCircle2 className="size-8" />
                </div>
                <h1 className="mt-4 text-2xl font-extrabold">Pesanan Berhasil Dibuat!</h1>
                <p className="mt-2 text-sm text-white/85">
                  Terima kasih. Pesanan Anda telah kami terima dan sedang menunggu konfirmasi.
                </p>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-border/70 bg-muted/30 p-4">
                  <div className="text-xs font-semibold text-muted-foreground">Nomor Pesanan</div>
                  <div className="mt-1 text-lg font-extrabold text-primary break-all">{orderNumber}</div>
                </div>
                <div className="rounded-xl border border-border/70 bg-muted/30 p-4">
                  <div className="text-xs font-semibold text-muted-foreground">Nomor Antrean</div>
                  <div className="mt-1 text-lg font-extrabold flex items-center justify-center gap-1.5">
                    <Hash className="size-4 text-primary" />{queueNumber}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap justify-center gap-2">
                <Button variant="outline" size="sm" onClick={copyOrder}>
                  {copied ? <CheckCircle2 className="size-4" /> : <Copy className="size-4" />}
                  Salin Nomor Pesanan
                </Button>
              </div>

              <div className="rounded-xl border border-dashed border-border bg-muted/20 p-4 text-left">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <FileText className="size-4 text-primary" /> Tautan Pelacakan
                </div>
                <p className="mt-1 text-xs text-muted-foreground break-all">{trackUrl}</p>
                <p className="mt-2 text-xs text-muted-foreground">
                  Simpan tautan ini untuk melacak status pesanan Anda. Tautan bersifat privat.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  onClick={() => navigate("track", { token })}
                >
                  <Search className="size-4" /> Lacak Pesanan
                </Button>
              </div>

              <div className="rounded-xl bg-primary/5 border border-primary/15 p-4 text-left">
                <p className="text-sm text-muted-foreground">
                  Selanjutnya, tim kami akan menghubungi Anda via WhatsApp untuk konfirmasi.
                </p>
                <Button asChild className="mt-3 w-full">
                  <a href={waLink(settings.whatsapp, waMessage)} target="_blank" rel="noopener noreferrer">
                    Konfirmasi via WhatsApp <ArrowRight className="size-4" />
                  </a>
                </Button>
              </div>

              <Button variant="ghost" onClick={() => navigate("beranda")} className="w-full">
                <Home className="size-4" /> Kembali ke Beranda
              </Button>
            </div>
          </Card>
        </Reveal>
      </div>
    </div>
  );
}
