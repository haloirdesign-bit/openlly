"use client";

import { Skeleton } from "@/components/ui/skeleton";
import { ServiceCard } from "@/components/openly/service-card";
import { PackageCard } from "@/components/openly/package-card";
import { PackageDetailModal } from "@/components/openly/package-detail-modal";
import { SectionHeading } from "@/components/openly/section-heading";
import { Reveal } from "@/components/openly/reveal";
import { useRouter } from "@/store/router";
import { useServices } from "@/hooks/use-services";
import { useState } from "react";
import type { PackageDTO } from "@/lib/types";

interface ServiceExplorerProps {
  type: "GRAPHIC" | "WEBSITE";
  eyebrow: string;
  title: string;
  description: string;
  showPackages?: boolean;
}

export function ServiceExplorer({
  type,
  eyebrow,
  title,
  description,
  showPackages = true,
}: ServiceExplorerProps) {
  const navigate = useRouter((s) => s.navigate);
  const { services, loading } = useServices(type);
  const [activePkg, setActivePkg] = useState<PackageDTO | null>(null);
  const [activeServiceName, setActiveServiceName] = useState<string>("");

  const allPackages = services.flatMap((s) =>
    s.packages.map((p) => ({ pkg: p, service: s }))
  );

  const order = (serviceSlug?: string, packageId?: string) => {
    navigate("order", { type, ...(serviceSlug ? { service: serviceSlug } : {}), ...(packageId ? { pkg: packageId } : {}) });
  };

  return (
    <div className="py-12 sm:py-16">
      <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-10">
        <SectionHeading eyebrow={eyebrow} title={title} description={description} />

        {/* Services grid */}
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-64 w-full rounded-xl" />
              ))
            : services.map((s, i) => (
                <ServiceCard key={s.id} service={s} index={i} />
              ))}
        </div>

        {/* Packages */}
        {showPackages && allPackages.length > 0 && (
          <div className="mt-16">
            <Reveal>
              <h3 className="text-center text-xl sm:text-2xl font-bold tracking-tight">
                Pilihan Paket
              </h3>
              <p className="mx-auto mt-2 max-w-xl text-center text-sm text-muted-foreground">
                Pilih paket yang sesuai dengan kebutuhan dan anggaran Anda.
              </p>
            </Reveal>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {loading
                ? Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-72 w-full rounded-xl" />
                  ))
                : allPackages.map(({ pkg, service }) => (
                    <PackageCard
                      key={pkg.id}
                      pkg={pkg}
                      serviceName={service.name}
                      onViewDetail={() => {
                        setActivePkg(pkg);
                        setActiveServiceName(service.name);
                      }}
                      onOrder={() => order(service.slug, pkg.id)}
                    />
                  ))}
            </div>
          </div>
        )}
      </div>

      <PackageDetailModal
        pkg={activePkg}
        serviceName={activeServiceName}
        open={!!activePkg}
        onOpenChange={(v) => !v && setActivePkg(null)}
        onOrder={() => {
          if (activePkg) {
            const svc = services.find((s) => s.packages.some((p) => p.id === activePkg.id));
            order(svc?.slug, activePkg.id);
          }
        }}
      />
    </div>
  );
}
