"use client";

import { useState, useRef, useCallback } from "react";
import { Upload, X, FileIcon, ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatBytes } from "./file-utils";

interface FileUploaderProps {
  files: File[];
  onChange: (files: File[]) => void;
  max?: number;
  accept?: string;
  label?: string;
  hint?: string;
}

export function FileUploader({
  files,
  onChange,
  max = 6,
  accept = "image/*,.pdf,.zip,.ai,.psd",
  label = "Unggah referensi / brief",
  hint = "Maks. 6 file, masing-masing maks 15MB. JPG, PNG, WEBP, PDF, ZIP, AI, PSD.",
}: FileUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFiles = useCallback(
    (list: FileList | null) => {
      if (!list) return;
      setError(null);
      const incoming = Array.from(list);
      const merged = [...files, ...incoming];
      if (merged.length > max) {
        setError(`Maksimal ${max} file.`);
      }
      const trimmed = merged.slice(0, max);
      onChange(trimmed);
    },
    [files, onChange, max]
  );

  const removeAt = (i: number) => {
    const next = files.filter((_, idx) => idx !== i);
    onChange(next);
  };

  return (
    <div className="space-y-3">
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          handleFiles(e.dataTransfer.files);
        }}
        className={cn(
          "flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-8 text-center transition-colors",
          dragOver
            ? "border-primary bg-primary/5"
            : "border-border hover:border-primary/50 hover:bg-muted/40"
        )}
      >
        <div className="inline-flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Upload className="size-5" />
        </div>
        <span className="text-sm font-medium">{label}</span>
        <span className="text-xs text-muted-foreground max-w-xs">{hint}</span>
      </button>
      <input
        ref={inputRef}
        type="file"
        multiple
        accept={accept}
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}

      {files.length > 0 && (
        <ul className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {files.map((f, i) => {
            const isImage = f.type.startsWith("image/");
            const url = isImage ? URL.createObjectURL(f) : null;
            return (
              <li
                key={i}
                className="group relative overflow-hidden rounded-lg border border-border bg-muted/30"
              >
                <div className="aspect-square w-full flex items-center justify-center bg-muted/40">
                  {isImage && url ? (
                     
                    <img src={url} alt={f.name} className="h-full w-full object-cover" />
                  ) : (
                    <FileIcon className="size-8 text-muted-foreground" />
                  )}
                </div>
                <div className="p-2">
                  <p className="truncate text-xs font-medium" title={f.name}>
                    {f.name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{formatBytes(f.size)}</p>
                </div>
                <button
                  type="button"
                  onClick={() => removeAt(i)}
                  className="absolute right-1 top-1 inline-flex size-6 items-center justify-center rounded-full bg-background/90 text-foreground shadow opacity-0 transition-opacity group-hover:opacity-100 hover:bg-destructive hover:text-white"
                  aria-label="Hapus file"
                >
                  <X className="size-3.5" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
