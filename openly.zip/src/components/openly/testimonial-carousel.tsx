"use client";

import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";
import { cn } from "@/lib/utils";
import { useReducedMotion } from "framer-motion";

export interface Testimonial {
  name: string;
  role?: string;
  text: string;
  rating?: number;
}

interface TestimonialCarouselProps {
  items: Testimonial[];
  /** speed in ms per item */
  interval?: number;
  variant?: "row" | "card";
  className?: string;
}

export function TestimonialCarousel({
  items,
  interval = 4000,
  variant = "card",
  className,
}: TestimonialCarouselProps) {
  const reduce = useReducedMotion();
  const [active, setActive] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const paused = useRef(false);

  useEffect(() => {
    if (reduce || items.length <= 1) return;
    timerRef.current = setInterval(() => {
      if (!paused.current) {
        setActive((p) => (p + 1) % items.length);
      }
    }, interval);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [items.length, interval, reduce]);

  if (items.length === 0) return null;

  if (variant === "row") {
    // Marquee-style auto-scroll row (CSS animation)
    return (
      <div
        className={cn("relative overflow-hidden", className)}
        onMouseEnter={() => (paused.current = true)}
        onMouseLeave={() => (paused.current = false)}
      >
        <div
          className="flex gap-4 w-max openly-marquee"
          style={{
            animation: reduce ? "none" : `openly-marquee ${items.length * interval / 1000 * 2}s linear infinite`,
          }}
        >
          {[...items, ...items].map((t, i) => (
            <Card key={i} className="w-72 shrink-0 p-5 border-border/70 shadow-sm">
              <div className="flex gap-1 mb-2">
                {Array.from({ length: t.rating || 5 }).map((_, s) => (
                  <Star key={s} className="size-3.5 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-sm text-foreground/80 line-clamp-3 leading-relaxed">"{t.text}"</p>
              <div className="mt-3 flex items-center gap-2">
                <div className="size-8 rounded-full openly-gradient flex items-center justify-center text-white text-xs font-bold">
                  {t.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="text-xs font-bold">{t.name}</div>
                  {t.role && <div className="text-[10px] text-muted-foreground">{t.role}</div>}
                </div>
              </div>
            </Card>
          ))}
        </div>
        <style jsx>{`
          @keyframes openly-marquee {
            from { transform: translateX(0); }
            to { transform: translateX(-50%); }
          }
        `}</style>
      </div>
    );
  }

  // card variant: single active card with fade
  return (
    <div
      className={cn("relative", className)}
      onMouseEnter={() => (paused.current = true)}
      onMouseLeave={() => (paused.current = false)}
    >
      <div className="relative overflow-hidden">
        {items.map((t, i) => (
          <Card
            key={i}
            className={cn(
              "absolute inset-0 p-6 sm:p-8 border-border/70 shadow-md transition-all duration-700",
              i === active
                ? "opacity-100 translate-y-0 pointer-events-auto"
                : "opacity-0 translate-y-4 pointer-events-none"
            )}
          >
            <Quote className="size-8 text-primary/20 mb-3" />
            <div className="flex gap-1 mb-3">
              {Array.from({ length: t.rating || 5 }).map((_, s) => (
                <Star key={s} className="size-4 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <p className="text-base sm:text-lg leading-relaxed text-foreground/90 italic">"{t.text}"</p>
            <div className="mt-5 flex items-center gap-3">
              <div className="size-11 rounded-full openly-gradient flex items-center justify-center text-white text-sm font-bold ring-2 ring-primary/20">
                {t.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase()}
              </div>
              <div>
                <div className="text-sm font-bold">{t.name}</div>
                {t.role && <div className="text-xs text-muted-foreground">{t.role}</div>}
              </div>
            </div>
          </Card>
        ))}
        {/* spacer to give height */}
        <div className="invisible p-6 sm:p-8">
          <Quote className="size-8 mb-3" />
          <div className="flex gap-1 mb-3">
            {Array.from({ length: 5 }).map((_, s) => <Star key={s} className="size-4" />)}
          </div>
          <p className="text-base sm:text-lg leading-relaxed italic">spacer</p>
          <div className="mt-5 flex items-center gap-3">
            <div className="size-11 rounded-full" />
            <div>
              <div className="text-sm font-bold">spacer</div>
              <div className="text-xs">spacer</div>
            </div>
          </div>
        </div>
      </div>

      {/* dots */}
      {items.length > 1 && (
        <div className="mt-4 flex justify-center gap-1.5">
          {items.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              aria-label={`Testimoni ${i + 1}`}
              className={cn(
                "h-2 rounded-full transition-all",
                i === active ? "w-6 bg-primary" : "w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50"
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
}
