"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Bell, BellRing, BellOff, Info } from "lucide-react";
import { toast } from "sonner";

type PushState = "unsupported" | "disabled-server" | "granted-subscribed" | "granted-not-subscribed" | "denied" | "loading";

function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = typeof window !== "undefined" ? window.atob(base64) : "";
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
}

export function PushSubscribe() {
  const [state, setState] = useState<PushState>("loading");
  const [subEndpoint, setSubEndpoint] = useState<string | null>(null);
  const [vapidKey, setVapidKey] = useState<string>("");

  useEffect(() => {
    let active = true;
    (async () => {
      if (typeof window === "undefined") return;
      if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
        if (active) setState("unsupported");
        return;
      }
      try {
        const res = await fetch("/api/push/vapid-public");
        const d = await res.json();
        if (!active) return;
        setVapidKey(d.publicKey || "");
        if (!d.enabled) {
          setState("disabled-server");
          return;
        }
        const reg = await navigator.serviceWorker.ready;
        const existing = await reg.pushManager.getSubscription();
        if (!active) return;
        if (existing) {
          setSubEndpoint(existing.endpoint);
          setState("granted-subscribed");
        } else {
          if (Notification.permission === "granted") setState("granted-not-subscribed");
          else if (Notification.permission === "denied") setState("denied");
          else setState("granted-not-subscribed");
        }
      } catch {
        if (active) setState("unsupported");
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const subscribe = async () => {
    try {
      const perm = await Notification.requestPermission();
      if (perm !== "granted") {
        setState("denied");
        toast.info("Izin notifikasi ditolak. Anda bisa mengaktifkannya di pengaturan browser.");
        return;
      }
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidKey),
      });
      await fetch("/api/push/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: sub.endpoint, keys: sub.toJSON().keys }),
      });
      setSubEndpoint(sub.endpoint);
      setState("granted-subscribed");
      toast.success("Notifikasi push diaktifkan.");
    } catch (e) {
      toast.error("Gagal mengaktifkan notifikasi push.");
    }
  };

  const unsubscribe = async () => {
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        await fetch("/api/push/unsubscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ endpoint: sub.endpoint }),
        });
        await sub.unsubscribe();
      }
      setSubEndpoint(null);
      setState("granted-not-subscribed");
      toast.info("Notifikasi push dinonaktifkan.");
    } catch {
      toast.error("Gagal menonaktifkan.");
    }
  };

  if (state === "loading")
    return <p className="text-xs text-muted-foreground">Memeriksa dukungan notifikasi…</p>;

  if (state === "unsupported")
    return (
      <div className="flex items-start gap-2 text-xs text-muted-foreground">
        <Info className="size-4 mt-0.5 text-amber-500" />
        <span>Browser ini tidak mendukung notifikasi push. Gunakan Chrome, Edge, atau Firefox versi terbaru.</span>
      </div>
    );

  if (state === "disabled-server")
    return (
      <div className="flex items-start gap-2 text-xs text-muted-foreground">
        <Info className="size-4 mt-0.5 text-amber-500" />
        <span>
          Notifikasi push browser belum dikonfigurasi di server. Anda tetap mendapat notifikasi
          di dalam website (in-app & toast) saat halaman terbuka.
        </span>
      </div>
    );

  if (state === "denied")
    return (
      <div className="flex items-start gap-2 text-xs text-muted-foreground">
        <BellOff className="size-4 mt-0.5 text-destructive" />
        <span>
          Izin notifikasi diblokir di browser. Buka pengaturan situs untuk mengizinkan ulang.
        </span>
      </div>
    );

  if (state === "granted-subscribed")
    return (
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm">
          <BellRing className="size-4 text-primary" />
          <span>Notifikasi push aktif</span>
        </div>
        <Button size="sm" variant="outline" onClick={unsubscribe}>
          Nonaktifkan
        </Button>
      </div>
    );

  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-2 text-sm">
        <Bell className="size-4 text-muted-foreground" />
        <span>Aktifkan notifikasi push</span>
      </div>
      <Button size="sm" onClick={subscribe}>
        <BellRing className="size-4" /> Aktifkan
      </Button>
    </div>
  );
}
