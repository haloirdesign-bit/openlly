"use client";

import { useEffect, useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
  SheetClose,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Collapsible,
  CollapsibleTrigger,
  CollapsibleContent,
} from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";
import {
  Menu as MenuIcon,
  X as XIcon,
  LogIn as LogInIcon,
  ChevronDown as ChevronDownIcon,
  Home,
  Tag,
  Star,
  Users,
  Phone,
  Palette,
  Globe,
} from "lucide-react";
import { useRouter, type RouteView } from "@/store/router";
import { cn } from "@/lib/utils";
import { useSiteContent } from "@/hooks/use-site-content";
import { useSession } from "@/hooks/use-session";
import { NotificationBell } from "@/components/openly/notification-bell";
import { NICHES } from "@/lib/types";

interface NavItem {
  label: string;
  view: RouteView;
  icon: React.ComponentType<{ className?: string }>;
}

// Menu utama — label pendek & rapih
const NAV: NavItem[] = [
  { label: "Beranda", view: "beranda", icon: Home },
  { label: "Pricelist", view: "pricelist", icon: Tag },
  { label: "Review", view: "review", icon: Star },
  { label: "Tentang", view: "tentang", icon: Users },
  { label: "Kontak", view: "kontak", icon: Phone },
];

export function Header() {
  const { view, navigate } = useRouter();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data } = useSiteContent();
  const loginText = data?.settings.nav_login_text || "Login";
  const { user } = useSession();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (item: NavItem) => {
    navigate(item.view, item.params);
    setMobileOpen(false);
  };

  const goNiche = (nicheId: string) => {
    navigate("niche", { niche: nicheId });
    setMobileOpen(false);
  };

  return (
    <header
      className={cn(
        "sticky top-0 z-40 w-full transition-all duration-300",
        scrolled
          ? "border-b border-border/60 bg-background/90 backdrop-blur-md shadow-sm"
          : "bg-transparent"
      )}
    >
      <div className="mx-auto flex h-16 max-w-[1600px] items-center justify-between gap-3 px-4 sm:px-6 lg:px-10">
        <button
          onClick={() => navigate("beranda")}
          className="flex items-center gap-2 transition-opacity hover:opacity-90 shrink-0"
          aria-label="Openly beranda"
        >
          { }
          <img src="/openly-logo.svg" alt="Openly — IR Design Kreasi" className="h-9 w-auto sm:h-10" />
        </button>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-0.5">
          {/* Layanan dropdown — label pendek */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                className={cn(
                  "inline-flex items-center gap-1 rounded-md px-3 py-2 text-[13px] font-medium transition-colors",
                  view === "jasa-desain" || view === "jasa-website" || view === "niche"
                    ? "text-primary"
                    : "text-foreground/70 hover:text-foreground hover:bg-muted/60"
                )}
              >
                Layanan
                <ChevronDownIcon className="size-3.5" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Jasa</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => navigate("jasa-desain")} className="cursor-pointer gap-2.5 py-2">
                <Palette className="size-4 text-primary" />
                <span className="text-sm font-medium">Desain Grafis</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate("jasa-website")} className="cursor-pointer gap-2.5 py-2">
                <Globe className="size-4 text-primary" />
                <span className="text-sm font-medium">Website</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs text-muted-foreground">Kategori Bisnis</DropdownMenuLabel>
              <div className="grid grid-cols-2 gap-0.5 px-1 pb-1">
                {NICHES.map((n) => (
                  <DropdownMenuItem
                    key={n.id}
                    onClick={() => goNiche(n.id)}
                    className="cursor-pointer gap-1.5 py-1.5 px-2 rounded-md text-xs"
                  >
                    <span className="text-sm">{n.emoji}</span>
                    <span className="truncate">{n.short}</span>
                  </DropdownMenuItem>
                ))}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {NAV.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.view}
                onClick={() => go(item)}
                className={cn(
                  "relative rounded-md px-3 py-2 text-[13px] font-medium transition-colors",
                  view === item.view
                    ? "text-primary"
                    : "text-foreground/70 hover:text-foreground hover:bg-muted/60"
                )}
              >
                {item.label}
                {view === item.view && (
                  <span className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full openly-gradient" />
                )}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          {user && <NotificationBell className="hidden lg:inline-flex" />}
          {user ? (
            <Button
              variant="default"
              size="sm"
              className="hidden lg:inline-flex"
              onClick={() => navigate("portal")}
            >
              Akun
            </Button>
          ) : (
            <Button
              variant="default"
              size="sm"
              className="hidden lg:inline-flex"
              onClick={() => navigate("customer-login")}
            >
              <LogInIcon className="size-4" />
              {loginText}
            </Button>
          )}

          {/* Mobile */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="lg:hidden" aria-label="Buka menu">
                <MenuIcon className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[340px] p-0 overflow-y-auto openly-scroll">
              <SheetHeader className="px-5 pt-5 pb-3 border-b">
                <SheetTitle className="flex items-center justify-between">
                  { }
                  <img src="/openly-logo.svg" alt="Openly" className="h-8 w-auto" />
                  <SheetClose asChild>
                    <Button variant="ghost" size="icon" className="size-8">
                      <XIcon className="size-4" />
                    </Button>
                  </SheetClose>
                </SheetTitle>
              </SheetHeader>
              <nav className="flex flex-col gap-0.5 p-3">
                {/* Layanan collapsible (mobile) */}
                <Collapsible>
                  <CollapsibleTrigger
                    className={cn(
                      "flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors",
                      view === "jasa-desain" || view === "jasa-website" || view === "niche"
                        ? "bg-primary/10 text-primary"
                        : "text-foreground/80 hover:bg-muted"
                    )}
                  >
                    <span className="inline-flex items-center gap-2">
                      <Palette className="size-4" /> Layanan
                    </span>
                    <ChevronDownIcon className="size-4" />
                  </CollapsibleTrigger>
                  <CollapsibleContent className="pl-3 pt-1 pb-1">
                    <button
                      onClick={() => navigate("jasa-desain")}
                      className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm text-foreground/75 hover:bg-muted"
                    >
                      <Palette className="size-4 text-primary" /> Desain Grafis
                    </button>
                    <button
                      onClick={() => navigate("jasa-website")}
                      className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm text-foreground/75 hover:bg-muted"
                    >
                      <Globe className="size-4 text-primary" /> Website
                    </button>
                    <div className="px-3 pt-2 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      Kategori Bisnis
                    </div>
                    <div className="grid grid-cols-2 gap-0.5">
                      {NICHES.map((n) => (
                        <button
                          key={n.id}
                          onClick={() => goNiche(n.id)}
                          className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-left text-xs text-foreground/70 hover:bg-muted"
                        >
                          <span>{n.emoji}</span>
                          <span className="truncate">{n.short}</span>
                        </button>
                      ))}
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {NAV.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.view}
                      onClick={() => go(item)}
                      className={cn(
                        "rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors inline-flex items-center gap-2",
                        view === item.view ? "bg-primary/10 text-primary" : "text-foreground/80 hover:bg-muted"
                      )}
                    >
                      <Icon className="size-4" /> {item.label}
                    </button>
                  );
                })}
                <div className="my-2 h-px bg-border" />
                {user ? (
                  <button
                    onClick={() => navigate("portal")}
                    className="rounded-lg px-3 py-2.5 text-left text-sm font-medium text-foreground/80 hover:bg-muted inline-flex items-center gap-2"
                  >
                    <LogInIcon className="size-4 text-primary" /> Akun Saya
                  </button>
                ) : (
                  <button
                    onClick={() => navigate("customer-login")}
                    className="rounded-lg px-3 py-2.5 text-left text-sm font-medium text-foreground/80 hover:bg-muted inline-flex items-center gap-2"
                  >
                    <LogInIcon className="size-4 text-primary" /> {loginText}
                  </button>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
