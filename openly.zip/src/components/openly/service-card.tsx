"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, RotateCcw, ArrowRight, ImageIcon } from "lucide-react";
import type { ServiceDTO } from "@/lib/types";
import { useRouter, type RouteView } from "@/store/router";
import { Reveal } from "./reveal";

interface ServiceCardProps {
  service: ServiceDTO;
  index?: number;
}

export function ServiceCard({ service, index = 0 }: ServiceCardProps) {
  const navigate = useRouter((s) => s.navigate);
  const goToOrder = () =>
    navigate("order", { type: service.type, service: service.slug });
  const goToPricelist = () =>
    navigate("pricelist", { type: service.type });

  return (
    <Reveal delay={index * 0.06} className="h-full">
      <Card className="group relative h-full overflow-hidden p-6 border-border/70 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col">
        <div className="absolute -right-10 -top-10 size-28 rounded-full bg-primary/10 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
        <div className="mb-4 inline-flex size-12 items-center justify-center rounded-xl openly-gradient text-white shadow-md">
          <ImageIcon className="size-6" />
        </div>
        <h3 className="text-lg font-bold tracking-tight">{service.name}</h3>
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-3 flex-1">
          {service.description}
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          {service.priceLabel && (
            <Badge variant="secondary" className="bg-primary/10 text-primary border-0 font-semibold">
              {service.priceLabel}
            </Badge>
          )}
          {service.estDuration && (
            <Badge variant="outline" className="gap-1 font-normal">
              <Clock className="size-3" /> {service.estDuration}
            </Badge>
          )}
          {service.revision && (
            <Badge variant="outline" className="gap-1 font-normal">
              <RotateCcw className="size-3" /> Revisi
            </Badge>
          )}
        </div>

        <div className="mt-5 flex flex-col sm:flex-row gap-2">
          <Button onClick={goToOrder} className="flex-1" size="sm">
            Pesan Sekarang <ArrowRight className="size-4" />
          </Button>
          {service.packages.length > 0 && (
            <Button onClick={goToPricelist} variant="outline" size="sm" className="flex-1">
              Lihat Paket
            </Button>
          )}
        </div>
      </Card>
    </Reveal>
  );
}

export function navLink(view: RouteView, params?: Record<string, string>) {
  return useRouter.getState().navigate(view, params);
}
