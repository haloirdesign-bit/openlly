import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const SESSION_COOKIE = "openly_session";
const SECRET = process.env.OPENLY_JWT_SECRET || "openly-dev-secret-change-me-in-production";

export type SessionRole = "ADMIN" | "CUSTOMER";

export interface SessionPayload {
  sub: string;       // user id
  email: string;
  name: string;
  role: SessionRole;
}

export function hashPassword(pw: string) {
  return bcrypt.hash(pw, 10);
}

export function verifyPassword(pw: string, hash: string) {
  return bcrypt.compare(pw, hash);
}

export function signSession(payload: SessionPayload) {
  return jwt.sign(payload, SECRET, { expiresIn: "30d" });
}

export function verifySession(token: string): SessionPayload | null {
  try {
    return jwt.verify(token, SECRET) as SessionPayload;
  } catch {
    return null;
  }
}

export const SESSION_COOKIE_NAME = SESSION_COOKIE;

export function isAdmin(payload?: SessionPayload | null) {
  return payload?.role === "ADMIN";
}

export function isCustomer(payload?: SessionPayload | null) {
  return payload?.role === "CUSTOMER";
}
