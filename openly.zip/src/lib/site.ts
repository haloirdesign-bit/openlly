export const WHATSAPP_NUMBER = "628216881766"; // 08216881766 -> intl
export const WHATSAPP_DISPLAY = "0821-6881-766";
export const BUSINESS_ADDRESS =
  "Jl. Dusun Legok Noong, RT.001/RW.001, Tj. Siom, Kec. Limau, Kabupaten Tanggamus, Lampung 35682";
export const OWNER_NAME = "Ihfa Mungkas";
export const BRAND_NAME = "Openly";
export const PARENT_COMPANY = "IR DESIGN KREASI";

export function waLink(message?: string) {
  const base = `https://wa.me/${WHATSAPP_NUMBER}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export const DEFAULT_WA_MESSAGES = {
  general: "Halo Openly, saya ingin bertanya seputar layanan desain grafis dan pembuatan website.",
  orderDesign: "Halo Openly, saya tertarik memesan jasa desain grafis. Mohon info lebih lanjut.",
  orderWebsite: "Halo Openly, saya tertarik memesan jasa pembuatan website. Mohon info lebih lanjut.",
  pricelist: "Halo Openly, saya ingin bertanya tentang pricelist layanan.",
};
