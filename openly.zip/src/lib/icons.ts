"use client";

import * as Icons from "lucide-react";
import type { LucideIcon } from "lucide-react";

export function getIcon(name?: string): LucideIcon | null {
  if (!name) return null;
  const lib = Icons as unknown as Record<string, LucideIcon>;
  return lib[name] || null;
}
