export type ServiceType = "GRAPHIC" | "WEBSITE" | "BUNDLE";

export interface NicheInfo {
  id: string;
  label: string;
  short: string;
  desc: string;
  emoji: string;
}

// Niche navigasi (sederhana tapi mewakili)
export const NICHES: NicheInfo[] = [
  { id: "baby-kids", label: "Baby & Kids", short: "Baby & Kids", desc: "Untuk baby spa, kids salon, toko bayi, dan layanan anak.", emoji: "🍼" },
  { id: "mom-care", label: "Mom Care", short: "Mom Care", desc: "Untuk layanan ibu & bayi, prenatal, postpartum, dan perawatan ibu.", emoji: "🤱" },
  { id: "klinik", label: "Klinik", short: "Klinik", desc: "Untuk klinik, praktek dokter, dan layanan kesehatan.", emoji: "🏥" },
  { id: "salon", label: "Salon", short: "Salon", desc: "Untuk salon kecantikan, barbershop, dan layanan estetika.", emoji: "💇" },
  { id: "kuliner", label: "Kuliner", short: "Kuliner", desc: "Untuk restoran, cafe, catering, dan usaha kuliner.", emoji: "🍽️" },
  { id: "toko", label: "Toko", short: "Toko", desc: "Untuk toko, retail, UMKM, dan bisnis produk.", emoji: "🛍️" },
  { id: "custom", label: "Custom", short: "Custom", desc: "Kebutuhan khusus di luar kategori di atas.", emoji: "✨" },
];

export function nicheInfo(id?: string | null): NicheInfo | undefined {
  if (!id) return undefined;
  return NICHES.find((n) => n.id === id);
}

export interface ServiceDTO {
  id: string;
  type: ServiceType;
  niche: string | null;
  name: string;
  slug: string;
  description: string;
  image: string | null;
  priceLabel: string | null;
  priceFrom: number | null;
  estDuration: string | null;
  revision: string | null;
  options: string[] | null;
  sortOrder: number;
  active: boolean;
  packages: PackageDTO[];
}

export interface PackageDTO {
  id: string;
  serviceId: string;
  name: string;
  price: number | null;
  priceLabel: string | null;
  description: string | null;
  features: string[];
  estDuration: string | null;
  revision: string | null;
  popular: boolean;
  active: boolean;
  sortOrder: number;
}

export const ORDER_STATUSES = [
  "RECEIVED",
  "WAITING_CONFIRM",
  "WAITING_PAYMENT",
  "QUEUED",
  "IN_PROGRESS",
  "WAITING_APPROVAL",
  "REVISION",
  "COMPLETED",
  "CANCELLED",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  RECEIVED: "Pesanan diterima",
  WAITING_CONFIRM: "Menunggu konfirmasi",
  WAITING_PAYMENT: "Menunggu pembayaran",
  QUEUED: "Dalam antrean",
  IN_PROGRESS: "Sedang dikerjakan",
  WAITING_APPROVAL: "Menunggu persetujuan pelanggan",
  REVISION: "Revisi",
  COMPLETED: "Selesai",
  CANCELLED: "Dibatalkan",
};

export const ORDER_STATUS_COLOR: Record<OrderStatus, string> = {
  RECEIVED: "bg-sky-100 text-sky-700 border-sky-200",
  WAITING_CONFIRM: "bg-amber-100 text-amber-700 border-amber-200",
  WAITING_PAYMENT: "bg-orange-100 text-orange-700 border-orange-200",
  QUEUED: "bg-violet-100 text-violet-700 border-violet-200",
  IN_PROGRESS: "bg-blue-100 text-blue-700 border-blue-200",
  WAITING_APPROVAL: "bg-cyan-100 text-cyan-700 border-cyan-200",
  REVISION: "bg-rose-100 text-rose-700 border-rose-200",
  COMPLETED: "bg-emerald-100 text-emerald-700 border-emerald-200",
  CANCELLED: "bg-zinc-200 text-zinc-600 border-zinc-300",
};

export const ORDER_STATUS_STEP: Record<OrderStatus, number> = {
  RECEIVED: 0,
  WAITING_CONFIRM: 1,
  WAITING_PAYMENT: 2,
  QUEUED: 3,
  IN_PROGRESS: 4,
  WAITING_APPROVAL: 5,
  REVISION: 5,
  COMPLETED: 6,
  CANCELLED: -1,
};

export interface OrderDetailGraphic {
  jenisDesain: string;
  paket: string;
  kebutuhan: string;
  ukuran: string;
  warna: string;
  deadline: string;
  catatan: string;
}

export interface OrderDetailWebsite {
  jenisWebsite: string;
  paket: string;
  namaBisnis: string;
  tujuan: string;
  fitur: string[];
  referensi: string;
  domain: string;
  deadline: string;
  catatan: string;
}
