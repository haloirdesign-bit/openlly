import { db } from "@/lib/db";
import { randomBytes } from "crypto";

// Generate order number: OPL-YYYYMMDD-XXXX (unique)
export async function generateOrderNumber(): Promise<string> {
  const date = new Date();
  const ymd =
    date.getFullYear().toString() +
    String(date.getMonth() + 1).padStart(2, "0") +
    String(date.getDate()).padStart(2, "0");
  for (let attempt = 0; attempt < 10; attempt++) {
    const rand = Math.floor(1000 + Math.random() * 9000).toString();
    const candidate = `OPL-${ymd}-${rand}`;
    const exists = await db.order.findUnique({ where: { orderNumber: candidate } });
    if (!exists) return candidate;
  }
  // fallback with cuid-ish
  return `OPL-${ymd}-${Date.now().toString().slice(-4)}`;
}

// Generate queue number (3-digit, daily, unique)
export async function generateQueueNumber(): Promise<string> {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date();
  end.setHours(23, 59, 59, 999);
  const todayCount = await db.order.count({
    where: { queueDate: { gte: start, lte: end } },
  });
  // sequential but padded; verify uniqueness
  let n = todayCount + 1;
  for (let attempt = 0; attempt < 20; attempt++) {
    const candidate = String(n).padStart(3, "0");
    const exists = await db.order.findFirst({
      where: { queueNumber: candidate, queueDate: { gte: start, lte: end } },
    });
    if (!exists) return candidate;
    n++;
  }
  return String(Date.now()).slice(-3);
}

export function randomToken(bytes = 24): string {
  return randomBytes(bytes).toString("hex");
}
