import path from "path";
import fs from "fs/promises";

const STORAGE_DIR = path.resolve(process.cwd(), "storage");

export function storageDir(...parts: string[]) {
  return path.join(STORAGE_DIR, ...parts);
}

export async function ensureDir(dir: string) {
  await fs.mkdir(dir, { recursive: true });
}

export async function writeFileBuffer(relPath: string[], buf: Buffer) {
  const full = storageDir(...relPath);
  await ensureDir(path.dirname(full));
  await fs.writeFile(full, buf);
  return path.join(...relPath);
}

export async function readFileSafe(relPath: string): Promise<Buffer | null> {
  try {
    const full = storageDir(relPath);
    return await fs.readFile(full);
  } catch {
    return null;
  }
}

export async function deleteFileSafe(relPath: string) {
  try {
    await fs.unlink(storageDir(relPath));
  } catch {
    /* ignore */
  }
}

export function fileExt(name: string) {
  const m = name.match(/\.([a-zA-Z0-9]+)$/);
  return m ? m[1].toLowerCase() : "";
}

export const ALLOWED_IMAGE = ["jpg", "jpeg", "png", "webp", "gif"];
export const ALLOWED_DOC = ["pdf", "doc", "docx", "zip", "rar", "ai", "psd", "sketch", "fig"];
export const MAX_UPLOAD_MB = 15;

export function validateUpload(name: string, size: number, allowed: string[] = [...ALLOWED_IMAGE, ...ALLOWED_DOC]) {
  if (!name) return "File tidak valid.";
  if (size > MAX_UPLOAD_MB * 1024 * 1024) return `Ukuran file maksimal ${MAX_UPLOAD_MB}MB.`;
  const ext = fileExt(name);
  if (!allowed.includes(ext)) return `Tipe file .${ext} tidak diizinkan.`;
  return null;
}
