import { db } from "@/lib/db";
import { cache } from "react";

// Cache content/settings for the duration of a request (React cache).
export const getContent = cache(async (key: string): Promise<string | null> => {
  const row = await db.contentSection.findUnique({ where: { key } });
  return row?.value ?? null;
});

export async function getContentJSON<T>(key: string, fallback: T): Promise<T> {
  const raw = await getContent(key);
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function setContent(key: string, value: string) {
  await db.contentSection.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  });
}

export const getSetting = cache(async (key: string): Promise<string | null> => {
  const row = await db.siteSetting.findUnique({ where: { key } });
  return row?.value ?? null;
});

export async function getSettingMap(keys: string[]): Promise<Record<string, string>> {
  const rows = await db.siteSetting.findMany({ where: { key: { in: keys } } });
  const out: Record<string, string> = {};
  for (const r of rows) out[r.key] = r.value;
  return out;
}

export async function setSetting(key: string, value: string) {
  await db.siteSetting.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  });
}
