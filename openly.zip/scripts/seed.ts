 
import { db } from "../src/lib/db";
import { hashPassword } from "../src/lib/auth";

async function upsertPackages(serviceId: string, packages: any[]) {
  for (const pk of packages) {
    const existing = await db.servicePackage.findFirst({
      where: { serviceId, name: pk.name },
    });
    if (existing) {
      await db.servicePackage.update({
        where: { id: existing.id },
        data: {
          price: pk.price ?? null,
          priceLabel: pk.priceLabel ?? null,
          description: pk.description ?? null,
          features: JSON.stringify(pk.features),
          estDuration: pk.estDuration ?? null,
          revision: pk.revision ?? null,
          popular: pk.popular ?? false,
          sortOrder: pk.sortOrder ?? 0,
        },
      });
    } else {
      await db.servicePackage.create({
        data: {
          serviceId,
          name: pk.name,
          price: pk.price ?? null,
          priceLabel: pk.priceLabel ?? null,
          description: pk.description ?? null,
          features: JSON.stringify(pk.features),
          estDuration: pk.estDuration ?? null,
          revision: pk.revision ?? null,
          popular: pk.popular ?? false,
          sortOrder: pk.sortOrder ?? 0,
        },
      });
    }
  }
}

async function upsertService(s: any) {
  const { packages, ...data } = s;
  const payload = { ...data, options: data.options ? JSON.stringify(data.options) : null };
  const svc = await db.service.upsert({
    where: { slug: payload.slug },
    update: payload,
    create: payload,
  });
  if (packages) await upsertPackages(svc.id, packages);
  return svc;
}

async function main() {
  console.log("Seeding Openly v2 (niches + new prices + bundles + testimonials)...");

  // ===== Admin user =====
  const adminEmail = process.env.ADMIN_EMAIL || "admin@openly.id";
  const adminPw = process.env.ADMIN_PASSWORD || "admin123";
  const adminHash = await hashPassword(adminPw);
  await db.user.upsert({
    where: { email: adminEmail },
    update: { role: "ADMIN", active: true },
    create: {
      email: adminEmail,
      name: "Admin Openly",
      passwordHash: adminHash,
      role: "ADMIN",
      active: true,
    },
  });
  console.log("Admin:", adminEmail);

  // ===== Site settings (with real social media) =====
  const settings: Record<string, string> = {
    brand_name: "Openly",
    parent_company: "IR DESIGN KREASI",
    owner_name: "Ihfa Mungkas",
    whatsapp: "628216881766",
    whatsapp_display: "0821-6881-766",
    address:
      "Jl. Dusun Legok Noong, RT.001/RW.001, Tj. Siom, Kec. Limau, Kabupaten Tanggamus, Lampung 35682",
    email_contact: "hello@openly.id",
    instagram: "https://www.instagram.com/irdesign_web",
    tiktok: "https://vm.tiktok.com/ZS9UodMCtX5fq-ELISn/",
    facebook: "",
    behance: "",
    google_review: "https://g.page/r/CU_Ah0Evi1nwEAI/review",
    footer_text:
      "Openly — bagian dari IR Design Kreasi. Solusi kreatif untuk pertumbuhan bisnis Anda.",
    nav_login_text: "Login",
    announcement: "",
    hero_slogan: "Openly — Crafted For Your Growth",
    hero_description:
      "Solusi kreatif untuk membantu bisnis berkembang melalui desain grafis profesional dan website berkualitas.",
  };
  for (const [k, v] of Object.entries(settings)) {
    await db.siteSetting.upsert({ where: { key: k }, update: { value: v }, create: { key: k, value: v } });
  }

  // ===== Content sections =====
  const sections: Record<string, any> = {
    hero: {
      slogan: "Openly — Crafted For Your Growth",
      description:
        "Solusi kreatif untuk membantu bisnis berkembang melalui desain grafis profesional dan website berkualitas.",
      ctas: [
        { label: "Pesan Jasa Desain", view: "order", params: { type: "GRAPHIC" } },
        { label: "Pesan Jasa Website", view: "order", params: { type: "WEBSITE" } },
        { label: "Lihat Pricelist", view: "pricelist" },
      ],
      badges: ["Desain Grafis", "Pembuatan Website", "Paket Hemat", "Reservasi Online"],
    },
    advantages: [
      { icon: "Sparkles", title: "Desain Berkarakter", desc: "Setiap karya dibuat dengan karakter kuat dan estetika premium yang merepresentasikan merek Anda." },
      { icon: "Zap", title: "Pengerjaan Cepat", desc: "Estimasi waktu jelas dan alur kerja rapi agar bisnis Anda terus bergerak tanpa hambatan." },
      { icon: "ShieldCheck", title: "Proses Terpercaya", desc: "Sistem antrean transparan, pelacakan pesanan, dan komunikasi yang mudah via WhatsApp." },
      { icon: "Wallet", title: "Harga Bersahabat", desc: "Paket lengkap mulai dari 150rb. Website custom sudah termasuk online, ada paket jangka panjang." },
      { icon: "Rocket", title: "Fokus Pertumbuhan", desc: "Desain dan website dirancang untuk mendukung pertumbuhan bisnis jangka panjang Anda." },
      { icon: "Headset", title: "Dukungan Ramah", desc: "Konsultasi awal sampai hasil akhir, tim Openly siap mendampingi kebutuhan Anda." },
    ],
    services_summary_graphic: {
      title: "Jasa Desain Grafis",
      desc: "Identitas visual yang kuat untuk membangun kesan pertama yang berkesan.",
      points: ["Desain logo", "Banner & spanduk", "Poster & brosur", "Konten media sosial", "Kartu nama"],
      cta: { label: "Lihat Layanan Desain", view: "jasa-desain" },
    },
    services_summary_website: {
      title: "Jasa Pembuatan Website",
      desc: "Website profesional mulai dari 150rb. Paket lengkap, custom, reservasi, hingga jangka panjang.",
      points: ["Website HTML 150rb", "Custom + online 250rb", "Paket lengkap 350rb", "Reservasi online", "Paket jangka panjang"],
      cta: { label: "Lihat Layanan Website", view: "jasa-website" },
    },
    order_flow: {
      title: "Alur Pemesanan",
      steps: [
        { title: "Pilih Layanan", desc: "Tentukan kebutuhan desain atau website yang Anda inginkan." },
        { title: "Isi Formulir", desc: "Lengkapi data pemesanan dan unggah referensi bila ada." },
        { title: "Konfirmasi", desc: "Tim kami memverifikasi pesanan dan memberikan nomor antrean." },
        { title: "Pengerjaan", desc: "Pekerjaan dikerjakan sesuai antrean dengan estimasi waktu jelas." },
        { title: "Hasil & Serah Terima", desc: "Hasil dikirim dan dapat diunduh melalui akun pelanggan kerja sama." },
      ],
    },
    cooperation: {
      title: "Pelanggan Kerja sama",
      desc: "Untuk pelanggan yang bekerja sama secara berkelanjutan, Openly menyediakan akun khusus untuk memantau pesanan, mengunggah brief, dan mengunduh hasil pekerjaan dengan aman.",
      points: [
        "Login aman & terverifikasi admin",
        "Riwayat pesanan & status pekerjaan",
        "Unggah brief dan file pendukung",
        "Unduh hasil pekerjaan dengan aman",
        "Komunikasi cepat via WhatsApp",
      ],
      cta: { label: "Login", view: "login" },
    },
    owner: {
      name: "Ihfa Mungkas",
      role: "Founder Openly",
      welcome:
        "Selamat datang di Openly. Kami percaya setiap bisnis layak tampil berkualitas. Melalui desain grafis dan website yang dirancang dengan hati, kami berkomitmen membantu merek Anda tumbuh, terlihat, dan dipercaya. Terima kasih telah mempercayakan kebutuhan kreatif Anda kepada kami.",
      vision:
        "Menjadi mitra kreatif terpercaya yang membantu bisnis tumbuh melalui karya desain dan website yang berkualitas.",
      mission:
        "Memberikan layanan kreatif yang rapi, profesional, dan berorientasi pada pertumbuhan klien dengan komunikasi yang jelas dan transparan.",
      values: [
        { title: "Kualitas", desc: "Mengutamakan hasil yang rapi dan berkarakter." },
        { title: "Transparansi", desc: "Proses, harga, dan antrean yang jelas." },
        { title: "Tanggap", desc: "Komunikasi ramah dan responsif." },
        { title: "Pertumbuhan", desc: "Fokus pada dampak positif untuk bisnis klien." },
      ],
      avatar: "",
    },
    faq: [
      { q: "Apakah saya perlu membuat akun untuk memesan?", a: "Tidak. Pelanggan umum dapat memesan langsung melalui formulir pemesanan tanpa membuat akun. Akun khusus hanya untuk pelanggan kerja sama." },
      { q: "Berapa lama estimasi pengerjaan?", a: "Estimasi waktu tergantung jenis layanan dan paket yang dipilih. Website HTML bisa 1–3 hari, custom 5–14 hari. Detail estimasi tertera pada setiap layanan dan paket." },
      { q: "Apa beda paket website HTML, custom, lengkap, dan jangka panjang?", a: "HTML 150rb untuk halaman statis sederhana. Custom mulai 250rb sudah termasuk online. Paket lengkap 350rb fitur lebih banyak. Paket jangka panjang 650rb untuk pemeliharaan berkala." },
      { q: "Apakah website custom sudah termasuk online?", a: "Ya, paket website custom mulai 250rb sudah termasuk biaya online (domain & hosting dasar) sesuai ketentuan paket." },
      { q: "Bagaimana cara melacak pesanan saya?", a: "Setelah pemesanan berhasil, Anda akan mendapatkan nomor pesanan dan tautan pelacakan. Gunakan tautan tersebut untuk melihat status dan antrean." },
      { q: "Apakah revisi tersedia?", a: "Ya, ketentuan revisi ditentukan per layanan dan paket. Detail revisi tertera pada setiap paket." },
      { q: "Apakah file hasil pekerjaan aman?", a: "File hasil pekerjaan privat hanya dapat diunduh melalui akun pelanggan kerja sama yang terverifikasi." },
    ],
    contact: {
      title: "Hubungi Kami",
      desc: "Ada pertanyaan atau siap memesan? Tim Openly siap membantu Anda.",
      whatsapp: "628216881766",
      address:
        "Jl. Dusun Legok Noong, RT.001/RW.001, Tj. Siom, Kec. Limau, Kabupaten Tanggamus, Lampung 35682",
      hours: "Senin–Sabtu, 08.00–21.00 WIB",
    },
    testimonials: [
      { name: "Pemilik Baby Spa", role: "Baby & Kids", text: "Logo dan website baby spa kami jadi lebih profesional. Sistem reservasi online membantu sekali.", rating: 5 },
      { name: "Owner Mom Care", role: "Mom Care", text: "Desain konten media sosialnya rapi dan konsisten. Komunikasi tim Openly enak dan cepat.", rating: 5 },
      { name: "Klinik Kesehatan", role: "Klinik", text: "Website reservasi pasien jadi lebih tertata. Antrean jelas, proses pengerjaan transparan.", rating: 5 },
      { name: "Salon Kecantikan", role: "Salon", text: "Paket lengkap desain + website sangat worth it. Hasilnya elegan dan modern.", rating: 5 },
      { name: "Usaha Kuliner", role: "Kuliner", text: "Website katalog menu online naikkan penjualan. Harga bersahabat, hasil memuaskan.", rating: 5 },
      { name: "Toko UMKM", role: "Toko", text: "Mulai dari HTML 150rb sudah dapat website online. Cocok untuk pemula seperti saya.", rating: 5 },
    ],
    review_section: {
      title: "Apa Kata Pelanggan",
      desc: "Cerita dan ulasan dari pelanggan yang telah berkembang bersama Openly.",
      googleRating: "4.9",
      googleCount: "50+",
      googleUrl: "https://g.page/r/CU_Ah0Evi1nwEAI/review",
    },
  };
  for (const [k, v] of Object.entries(sections)) {
    await db.contentSection.upsert({
      where: { key: k },
      update: { value: JSON.stringify(v) },
      create: { key: k, value: JSON.stringify(v) },
    });
  }

  // ============================================================
  // GENERAL GRAPHIC SERVICES (niche = null)
  // ============================================================
  const graphicServices = [
    {
      name: "Desain Logo", slug: "desain-logo", niche: null, type: "GRAPHIC",
      description: "Logo profesional yang merepresentasikan identitas dan karakter merek Anda.",
      priceLabel: "Mulai dari Rp 250.000", priceFrom: 250000,
      estDuration: "2–4 hari kerja", revision: "Maksimal 3 kali revisi", sortOrder: 1,
      packages: [
        { name: "Logo Basic", price: 250000, description: "1 konsep logo sederhana.", features: ["1 konsep desain", "2 file final (PNG & JPG)", "Background transparan", "2x revisi"], estDuration: "2–3 hari kerja", revision: "2x revisi", popular: false, sortOrder: 1 },
        { name: "Logo Standard", price: 450000, description: "Beberapa pilihan konsep.", features: ["3 konsep desain", "File final (AI/PDF, PNG, JPG)", "Varian warna", "3x revisi"], estDuration: "3–5 hari kerja", revision: "3x revisi", popular: true, sortOrder: 2 },
        { name: "Logo Premium", price: 850000, description: "Lengkap dengan brand guideline mini.", features: ["5 konsep desain", "Brand guideline mini", "Semua format file", "Revisi wajar tanpa batas"], estDuration: "5–7 hari kerja", revision: "Revisi wajar tanpa batas", popular: false, sortOrder: 3 },
      ],
    },
    {
      name: "Banner & Spanduk", slug: "banner-spanduk", niche: null, type: "GRAPHIC",
      description: "Desain banner dan spanduk untuk promosi, event, dan kebutuhan cetak.",
      priceLabel: "Mulai dari Rp 150.000", priceFrom: 150000,
      estDuration: "1–3 hari kerja", revision: "Maksimal 2 kali revisi", sortOrder: 2,
      packages: [
        { name: "Banner Single", price: 150000, description: "1 desain banner.", features: ["1 desain", "Ukuran custom", "File siap cetak", "2x revisi"], estDuration: "1–2 hari kerja", revision: "2x revisi", popular: true, sortOrder: 1 },
        { name: "Banner Set", price: 350000, description: "Set banner berbagai ukuran.", features: ["3 desain banner", "Multi ukuran", "File siap cetak", "3x revisi"], estDuration: "2–3 hari kerja", revision: "3x revisi", popular: false, sortOrder: 2 },
      ],
    },
    {
      name: "Konten Media Sosial", slug: "konten-media-sosial", niche: null, type: "GRAPHIC",
      description: "Desain konten Instagram, Facebook, dan media sosial lainnya yang konsisten.",
      priceLabel: "Mulai dari Rp 25.000 / feed", priceFrom: 25000,
      estDuration: "1–2 hari kerja", revision: "Maksimal 2 kali revisi", sortOrder: 3,
      packages: [
        { name: "Feed Single", price: 25000, description: "1 desain feed.", features: ["1 desain feed", "Format IG square", "File PNG/JPG", "1x revisi"], estDuration: "1 hari kerja", revision: "1x revisi", popular: false, sortOrder: 1 },
        { name: "Paket 9 Feed", price: 180000, description: "9 desain feed konsisten.", features: ["9 desain feed", "Tema konsisten", "File PNG/JPG", "2x revisi"], estDuration: "2–3 hari kerja", revision: "2x revisi", popular: true, sortOrder: 2 },
        { name: "Paket Bulanan", price: 650000, description: "Konten bulanan lengkap.", features: ["Desain 12 feed", "Desain 4 story", "Konsep konten", "Konsultasi tema"], estDuration: "Per bulan", revision: "Sesuai kesepakatan", popular: false, sortOrder: 3 },
      ],
    },
    {
      name: "Poster & Brosur", slug: "poster-brosur", niche: null, type: "GRAPHIC",
      description: "Desain poster dan brosur informatif untuk promosi.",
      priceLabel: "Mulai dari Rp 175.000", priceFrom: 175000,
      estDuration: "1–3 hari kerja", revision: "Maksimal 2 kali revisi", sortOrder: 4,
      packages: [
        { name: "Poster Single", price: 175000, description: "1 desain poster.", features: ["1 desain", "Ukuran A3/A4", "File siap cetak", "2x revisi"], estDuration: "1–2 hari kerja", revision: "2x revisi", popular: true, sortOrder: 1 },
        { name: "Brosur 2 Sisi", price: 300000, description: "Brosur dua sisi.", features: ["Desain 2 sisi", "Ukuran A5/A4", "File siap cetak", "3x revisi"], estDuration: "2–3 hari kerja", revision: "3x revisi", popular: false, sortOrder: 2 },
      ],
    },
    {
      name: "Kartu Nama", slug: "kartu-nama", niche: null, type: "GRAPHIC",
      description: "Kartu nama profesional yang meninggalkan kesan pertama yang baik.",
      priceLabel: "Mulai dari Rp 125.000", priceFrom: 125000,
      estDuration: "1–2 hari kerja", revision: "Maksimal 2 kali revisi", sortOrder: 5,
      packages: [
        { name: "Kartu Nama Standar", price: 125000, description: "Desain 2 sisi.", features: ["Desain 2 sisi", "Ukuran standar", "File siap cetak", "2x revisi"], estDuration: "1–2 hari kerja", revision: "2x revisi", popular: true, sortOrder: 1 },
      ],
    },
  ];

  for (const s of graphicServices) {
    await upsertService(s);
  }

  // ============================================================
  // GENERAL WEBSITE SERVICES (niche = null) — HARGA BARU
  // Max 3.5jt, variatif: 150rb HTML, 250rb custom+online, 350rb lengkap, 650rb jangka panjang, reservasi bervariasi
  // ============================================================
  const websiteServices = [
    {
      name: "Website HTML Statis", slug: "website-html", niche: null, type: "WEBSITE",
      description: "Website HTML sederhana, cepat, dan hemat. Cocok untuk landing page tunggal atau profil singkat. Sudah online.",
      priceLabel: "Mulai dari Rp 150.000", priceFrom: 150000,
      estDuration: "1–3 hari kerja", revision: "Maksimal 2 kali revisi",
      options: ["Sudah termasuk online", "1 halaman", "Responsif"], sortOrder: 1,
      packages: [
        { name: "HTML Basic", price: 150000, description: "1 halaman HTML statis, sudah online.", features: ["1 halaman", "Desain responsif", "Sudah termasuk online", "Form kontak", "2x revisi"], estDuration: "1–2 hari kerja", revision: "2x revisi", popular: true, sortOrder: 1 },
        { name: "HTML Plus", price: 200000, description: "1 halaman dengan konten lebih kaya.", features: ["1 halaman", "Desain responsif", "Sudah termasuk online", "Animasi sederhana", "Form kontak", "2x revisi"], estDuration: "2–3 hari kerja", revision: "2x revisi", popular: false, sortOrder: 2 },
      ],
    },
    {
      name: "Website Custom", slug: "website-custom", niche: null, type: "WEBSITE",
      description: "Website custom sesuai kebutuhan bisnis Anda. Mulai dari 250rb, sudah termasuk online.",
      priceLabel: "Mulai dari Rp 250.000", priceFrom: 250000,
      estDuration: "5–14 hari kerja", revision: "Maksimal 4 kali revisi",
      options: ["Sudah termasuk online", "Custom sesuai kebutuhan", "Responsif"], sortOrder: 2,
      packages: [
        { name: "Custom Starter", price: 250000, description: "Website custom dasar, sudah online.", features: ["Hingga 3 halaman", "Desain responsif", "Sudah termasuk online", "Form kontak", "3x revisi"], estDuration: "5–7 hari kerja", revision: "3x revisi", popular: true, sortOrder: 1 },
        { name: "Custom Pro", price: 550000, description: "Website custom dengan fitur lebih.", features: ["Hingga 6 halaman", "Desain responsif", "Sudah termasuk online", "Animasi halus", "Form kontak", "4x revisi"], estDuration: "7–10 hari kerja", revision: "4x revisi", popular: false, sortOrder: 2 },
        { name: "Custom Premium", price: 850000, description: "Website custom lengkap.", features: ["Hingga 10 halaman", "Desain responsif", "Sudah termasuk online", "SEO dasar", "Integrasi WhatsApp", "4x revisi"], estDuration: "10–14 hari kerja", revision: "4x revisi", popular: false, sortOrder: 3 },
      ],
    },
    {
      name: "Paket Lengkap Website", slug: "paket-lengkap-website", niche: null, type: "WEBSITE",
      description: "Paket website lengkap dengan fitur lengkap, harga bersahabat. Cocok untuk bisnis yang ingin tampil profesional.",
      priceLabel: "Mulai dari Rp 350.000", priceFrom: 350000,
      estDuration: "7–14 hari kerja", revision: "Maksimal 4 kali revisi",
      options: ["Sudah termasuk online", "Fitur lengkap", "Responsif"], sortOrder: 3,
      packages: [
        { name: "Lengkap Basic", price: 350000, description: "Website lengkap hemat.", features: ["Hingga 5 halaman", "Desain responsif", "Sudah termasuk online", "Form kontak", "Integrasi WhatsApp", "3x revisi"], estDuration: "7–10 hari kerja", revision: "3x revisi", popular: true, sortOrder: 1 },
        { name: "Lengkap Pro", price: 750000, description: "Website lengkap dengan SEO.", features: ["Hingga 8 halaman", "Desain responsif", "Sudah termasuk online", "SEO dasar", "Blog/berita", "4x revisi"], estDuration: "10–14 hari kerja", revision: "4x revisi", popular: false, sortOrder: 2 },
      ],
    },
    {
      name: "Website Reservasi", slug: "website-reservasi", niche: null, type: "WEBSITE",
      description: "Website dengan sistem reservasi/booking online. Harga bervariasi tergantung fitur dan kompleksitas.",
      priceLabel: "Mulai dari Rp 500.000", priceFrom: 500000,
      estDuration: "7–21 hari kerja", revision: "Maksimal 4 kali revisi",
      options: ["Sistem reservasi online", "Notifikasi WhatsApp", "Responsif"], sortOrder: 4,
      packages: [
        { name: "Reservasi Basic", price: 500000, description: "Sistem reservasi sederhana.", features: ["Form reservasi online", "Notifikasi via WhatsApp", "Desain responsif", "Sudah termasuk online", "3x revisi"], estDuration: "7–10 hari kerja", revision: "3x revisi", popular: true, sortOrder: 1 },
        { name: "Reservasi Pro", price: 750000, description: "Reservasi dengan kalender.", features: ["Sistem reservasi + kalender", "Notifikasi WhatsApp", "Manajemen slot", "Desain responsif", "Sudah termasuk online", "4x revisi"], estDuration: "10–14 hari kerja", revision: "4x revisi", popular: false, sortOrder: 2 },
        { name: "Reservasi Premium", price: 850000, description: "Reservasi lengkap dengan dashboard.", features: ["Sistem reservasi penuh", "Dashboard admin", "Kalender & slot", "Notifikasi otomatis", "Laporan reservasi", "4x revisi"], estDuration: "14–21 hari kerja", revision: "4x revisi", popular: false, sortOrder: 3 },
      ],
    },
    {
      name: "Paket Jangka Panjang", slug: "paket-jangka-panjang", niche: null, type: "WEBSITE",
      description: "Website dengan pemeliharaan berkala. Paket lengkap untuk jangka panjang, hemat dan terus terawat.",
      priceLabel: "Mulai dari Rp 650.000", priceFrom: 650000,
      estDuration: "7–14 hari + pemeliharaan", revision: "Sesuai kesepakatan",
      options: ["Pemeliharaan berkala", "Update konten", "Prioritas support"], sortOrder: 5,
      packages: [
        { name: "Jangka Panjang 3 Bulan", price: 650000, description: "Website + pemeliharaan 3 bulan.", features: ["Website hingga 5 halaman", "Sudah termasuk online", "Pemeliharaan 3 bulan", "Update konten ringan", "Prioritas WhatsApp"], estDuration: "7–10 hari + 3 bln", revision: "Sesuai kesepakatan", popular: true, sortOrder: 1 },
        { name: "Jangka Panjang 6 Bulan", price: 1200000, description: "Website + pemeliharaan 6 bulan.", features: ["Website hingga 8 halaman", "Sudah termasuk online", "Pemeliharaan 6 bulan", "Update konten berkala", "Prioritas WhatsApp"], estDuration: "10–14 hari + 6 bln", revision: "Sesuai kesepakatan", popular: false, sortOrder: 2 },
        { name: "Jangka Panjang 12 Bulan", price: 2000000, description: "Website + pemeliharaan 1 tahun.", features: ["Website hingga 12 halaman", "Sudah termasuk online", "Pemeliharaan 12 bulan", "Update konten berkala", "Support prioritas"], estDuration: "14 hari + 12 bln", revision: "Sesuai kesepakatan", popular: false, sortOrder: 3 },
      ],
    },
    {
      name: "Website Bisnis Premium", slug: "website-bisnis-premium", niche: null, type: "WEBSITE",
      description: "Website bisnis premium dengan fitur lengkap dan kustomisasi penuh. Untuk bisnis yang ingin tampil unggul.",
      priceLabel: "Mulai dari Rp 1.500.000", priceFrom: 1500000,
      estDuration: "14–30 hari kerja", revision: "Maksimal 5 kali revisi",
      options: ["Custom penuh", "Fitur lengkap", "Responsif"], sortOrder: 6,
      packages: [
        { name: "Bisnis Pro", price: 1500000, description: "Website bisnis fitur lengkap.", features: ["Hingga 12 halaman", "Desain custom", "Sudah termasuk online", "SEO lengkap", "Integrasi WhatsApp", "5x revisi"], estDuration: "14–21 hari kerja", revision: "5x revisi", popular: true, sortOrder: 1 },
        { name: "Bisnis Ultimate", price: 2500000, description: "Website bisnis premium.", features: ["Hingga 20 halaman", "Desain custom premium", "Sudah termasuk online", "SEO lengkap", "CMS sederhana", "Animasi premium", "5x revisi"], estDuration: "21–30 hari kerja", revision: "5x revisi", popular: false, sortOrder: 2 },
        { name: "Bisnis Max", price: 3500000, description: "Website bisnis terlengkap.", features: ["Halaman tak terbatas", "Desain custom premium", "Sudah termasuk online", "SEO lengkap", "CMS lengkap", "Integrasi sistem", "Support prioritas", "5x revisi"], estDuration: "30+ hari kerja", revision: "5x revisi", popular: false, sortOrder: 3 },
      ],
    },
  ];

  for (const s of websiteServices) {
    await upsertService(s);
  }

  // ============================================================
  // NICHE-SPECIFIC SERVICES
  // For each niche: 1 design + 1 website + 1 bundle, with varied prices
  // ============================================================
  const niches = [
    { id: "baby-kids", label: "Baby & Kids" },
    { id: "mom-care", label: "Mom Care" },
    { id: "klinik", label: "Klinik" },
    { id: "salon", label: "Salon" },
    { id: "kuliner", label: "Kuliner" },
    { id: "toko", label: "Toko" },
    { id: "custom", label: "Custom" },
  ];

  // price variations per niche (slightly different to reflect "harga beda")
  const nichePriceMap: Record<string, { design: number; webHtml: number; webCustom: number; webLengkap: number; webReservasi: number; bundle: number }> = {
    "baby-kids": { design: 275000, webHtml: 150000, webCustom: 250000, webLengkap: 350000, webReservasi: 550000, bundle: 550000 },
    "mom-care": { design: 250000, webHtml: 150000, webCustom: 250000, webLengkap: 350000, webReservasi: 500000, bundle: 500000 },
    "klinik": { design: 300000, webHtml: 200000, webCustom: 350000, webLengkap: 450000, webReservasi: 750000, bundle: 750000 },
    "salon": { design: 275000, webHtml: 150000, webCustom: 300000, webLengkap: 400000, webReservasi: 600000, bundle: 600000 },
    "kuliner": { design: 200000, webHtml: 150000, webCustom: 250000, webLengkap: 350000, webReservasi: 500000, bundle: 500000 },
    "toko": { design: 225000, webHtml: 150000, webCustom: 275000, webLengkap: 375000, webReservasi: 550000, bundle: 550000 },
    "custom": { design: 250000, webHtml: 150000, webCustom: 250000, webLengkap: 350000, webReservasi: 500000, bundle: 600000 },
  };

  let nicheSort = 1;
  for (const n of niches) {
    const prices = nichePriceMap[n.id];

    // Design service for niche
    await upsertService({
      name: `Desain ${n.label}`, slug: `desain-${n.id}`, niche: n.id, type: "GRAPHIC",
      description: `Paket desain grafis khusus bisnis ${n.label}. Logo, konten media sosial, dan kebutuhan promosi yang sesuai dengan karakter bisnis Anda.`,
      priceLabel: `Mulai dari Rp ${prices.design.toLocaleString("id-ID")}`, priceFrom: prices.design,
      estDuration: "2–5 hari kerja", revision: "Maksimal 3 kali revisi", sortOrder: nicheSort,
      packages: [
        { name: `Desain ${n.label} Basic`, price: prices.design, description: `Paket desain dasar untuk ${n.label}.`, features: ["Logo sederhana", "3 desain feed", "File siap pakai", "2x revisi"], estDuration: "2–3 hari kerja", revision: "2x revisi", popular: true, sortOrder: 1 },
        { name: `Desain ${n.label} Pro`, price: Math.round(prices.design * 1.6), description: `Paket desain lengkap untuk ${n.label}.`, features: ["Logo + varian", "9 desain feed", "Banner promosi", "3x revisi"], estDuration: "3–5 hari kerja", revision: "3x revisi", popular: false, sortOrder: 2 },
      ],
    });

    // Website service for niche
    await upsertService({
      name: `Website ${n.label}`, slug: `website-${n.id}`, niche: n.id, type: "WEBSITE",
      description: `Website khusus bisnis ${n.label}. Pilihan paket dari HTML hemat, custom, lengkap, hingga reservasi online.`,
      priceLabel: `Mulai dari Rp ${prices.webHtml.toLocaleString("id-ID")}`, priceFrom: prices.webHtml,
      estDuration: "1–21 hari kerja", revision: "Maksimal 4 kali revisi",
      options: ["Sudah termasuk online", "Responsif", "Sesuai niche"], sortOrder: nicheSort,
      packages: [
        { name: `${n.label} HTML`, price: prices.webHtml, description: `Website HTML hemat untuk ${n.label}.`, features: ["1 halaman", "Sudah termasuk online", "Desain responsif", "Form kontak", "2x revisi"], estDuration: "1–3 hari kerja", revision: "2x revisi", popular: false, sortOrder: 1 },
        { name: `${n.label} Custom`, price: prices.webCustom, description: `Website custom untuk ${n.label}.`, features: ["Hingga 5 halaman", "Sudah termasuk online", "Desain responsif", "Form kontak", "3x revisi"], estDuration: "5–10 hari kerja", revision: "3x revisi", popular: true, sortOrder: 2 },
        { name: `${n.label} Lengkap`, price: prices.webLengkap, description: `Paket lengkap untuk ${n.label}.`, features: ["Hingga 8 halaman", "Sudah termasuk online", "SEO dasar", "Integrasi WhatsApp", "4x revisi"], estDuration: "7–14 hari kerja", revision: "4x revisi", popular: false, sortOrder: 3 },
        { name: `${n.label} Reservasi`, price: prices.webReservasi, description: `Website reservasi online untuk ${n.label}.`, features: ["Sistem reservasi", "Notifikasi WhatsApp", "Sudah termasuk online", "Kalender slot", "4x revisi"], estDuration: "10–21 hari kerja", revision: "4x revisi", popular: false, sortOrder: 4 },
      ],
    });

    // Bundle service (design + website) for niche
    await upsertService({
      name: `Paket Lengkap Desain + Website ${n.label}`, slug: `bundle-${n.id}`, niche: n.id, type: "BUNDLE",
      description: `Paket hemat: desain grafis + website sekaligus untuk bisnis ${n.label}. Lebih murah daripada pesan terpisah.`,
      priceLabel: `Mulai dari Rp ${prices.bundle.toLocaleString("id-ID")}`, priceFrom: prices.bundle,
      estDuration: "7–21 hari kerja", revision: "Maksimal 5 kali revisi",
      options: ["Desain + Website", "Hemat dibanding pesan terpisah", "Sudah termasuk online"], sortOrder: nicheSort,
      packages: [
        { name: `Bundle ${n.label} Basic`, price: prices.bundle, description: `Desain + website hemat untuk ${n.label}.`, features: ["Logo sederhana", "6 desain feed", "Website HTML 1 halaman", "Sudah termasuk online", "3x revisi"], estDuration: "7–10 hari kerja", revision: "3x revisi", popular: true, sortOrder: 1 },
        { name: `Bundle ${n.label} Pro`, price: Math.round(prices.bundle * 1.5), description: `Desain + website lengkap untuk ${n.label}.`, features: ["Logo + varian", "9 desain feed", "Website custom hingga 5 halaman", "Sudah termasuk online", "4x revisi"], estDuration: "10–14 hari kerja", revision: "4x revisi", popular: false, sortOrder: 2 },
        { name: `Bundle ${n.label} Lengkap`, price: Math.round(prices.bundle * 2), description: `Desain + website reservasi untuk ${n.label}.`, features: ["Logo lengkap", "12 desain feed", "Website reservasi online", "Sudah termasuk online", "5x revisi"], estDuration: "14–21 hari kerja", revision: "5x revisi", popular: false, sortOrder: 3 },
      ],
    });

    nicheSort++;
  }

  console.log("Seed v2 complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
