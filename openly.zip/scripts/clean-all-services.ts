 
import { db } from "../src/lib/db";

// Pricelist dari poster (4 kategori, 31 item, harga satuan persis)
const POSTER_PRICELIST = [
  // KATEGORI 1: DESIGN SOSIAL MEDIA
  { name: "Desain Feed Instagram", slug: "feed-instagram", price: 15000 },
  { name: "Desain Story Instagram", slug: "story-instagram", price: 20000 },
  { name: "Desain Carousel", slug: "carousel", price: 15000 },
  { name: "Desain Konten Promosi", slug: "konten-promosi", price: 20000 },
  { name: "Desain Highlight Instagram", slug: "highlight-instagram", price: 15000 },
  { name: "Desain Template Sosial Media", slug: "template-sosmed", price: 50000 },
  // KATEGORI 2: DESIGN PROMOSI
  { name: "Poster Promosi", slug: "poster-promosi", price: 15000 },
  { name: "Flyer", slug: "flyer", price: 15000 },
  { name: "Brosur", slug: "brosur", price: 20000 },
  { name: "Banner", slug: "banner", price: 25000 },
  { name: "Spanduk", slug: "spanduk", price: 20000 },
  { name: "Pamflet", slug: "pamflet", price: 25000 },
  { name: "Voucher / Kupon", slug: "voucher-kupon", price: 25000 },
  { name: "Katalog Produk", slug: "katalog-produk", price: 40000 },
  // KATEGORI 3: DESIGN BRANDING
  { name: "Logo Simple", slug: "logo-simple", price: 25000 },
  { name: "Logo Premium", slug: "logo-premium", price: 200000 },
  { name: "Logo + Filosofi", slug: "logo-filosofi", price: 1250000 },
  { name: "Kartu Nama", slug: "kartu-nama", price: 30000 },
  { name: "Kop Surat", slug: "kop-surat", price: 30000 },
  { name: "ID Card", slug: "id-card", price: 30000 },
  { name: "Stempel", slug: "stempel", price: 25000 },
  { name: "Brand Identity", slug: "brand-identity", price: 1350000 },
  // KATEGORI 4: DESIGN UMKM & BISNIS
  { name: "Menu / Pricelist", slug: "menu-pricelist", price: 15000 },
  { name: "Daftar Harga", slug: "daftar-harga", price: 10000 },
  { name: "Kartu Nama Usaha", slug: "kartu-nama-usaha", price: 25000 },
  { name: "Packaging / Label Produk", slug: "packaging-label", price: 45000 },
  { name: "Stiker Produk", slug: "stiker-produk", price: 15000 },
  { name: "Desain Kemasan", slug: "desain-kemasan", price: 75000 },
  { name: "Sertifikat", slug: "sertifikat", price: 25000 },
  { name: "Undangan", slug: "undangan", price: 25000 },
  { name: "Undangan Digital", slug: "undangan-digital", price: 75000 },
];

const CATEGORIES = [
  {
    id: "sosial-media",
    name: "Design Sosial Media",
    desc: "Desain untuk kebutuhan konten media sosial — feed, story, carousel, highlight, template.",
    slugs: ["feed-instagram", "story-instagram", "carousel", "konten-promosi", "highlight-instagram", "template-sosmed"],
  },
  {
    id: "promosi",
    name: "Design Promosi",
    desc: "Desain untuk kebutuhan promosi — poster, flyer, brosur, banner, spanduk, pamflet, voucher, katalog.",
    slugs: ["poster-promosi", "flyer", "brosur", "banner", "spanduk", "pamflet", "voucher-kupon", "katalog-produk"],
  },
  {
    id: "branding",
    name: "Design Branding",
    desc: "Desain identitas merek — logo, kartu nama, kop surat, ID card, stempel, brand identity.",
    slugs: ["logo-simple", "logo-premium", "logo-filosofi", "kartu-nama", "kop-surat", "id-card", "stempel", "brand-identity"],
  },
  {
    id: "umkm-bisnis",
    name: "Design UMKM & Bisnis",
    desc: "Desain untuk kebutuhan operasional bisnis — menu, daftar harga, kartu nama usaha, packaging, stiker, kemasan, sertifikat, undangan.",
    slugs: ["menu-pricelist", "daftar-harga", "kartu-nama-usaha", "packaging-label", "stiker-produk", "desain-kemasan", "sertifikat", "undangan", "undangan-digital"],
  },
];

// 6 website services umum (tetap dipertahankan, harga sudah benar)
const WEBSITE_SERVICES = [
  { name: "Website HTML Statis", slug: "website-html", priceFrom: 150000, priceLabel: "Mulai dari Rp 150.000" },
  { name: "Website Custom", slug: "website-custom", priceFrom: 250000, priceLabel: "Mulai dari Rp 250.000" },
  { name: "Paket Lengkap Website", slug: "paket-lengkap-website", priceFrom: 350000, priceLabel: "Mulai dari Rp 350.000" },
  { name: "Website Reservasi", slug: "website-reservasi", priceFrom: 500000, priceLabel: "Mulai dari Rp 500.000" },
  { name: "Paket Jangka Panjang", slug: "paket-jangka-panjang", priceFrom: 650000, priceLabel: "Mulai dari Rp 650.000" },
  { name: "Website Bisnis Premium", slug: "website-bisnis-premium", priceFrom: 1500000, priceLabel: "Mulai dari Rp 1.500.000" },
];

async function main() {
  console.log("=== CLEAN ALL: hapus SEMUA services & packages lama ===");

  // 1. Hapus SEMUA services (cascade packages)
  await db.servicePackage.deleteMany({});
  await db.service.deleteMany({});
  console.log("✓ Semua services & packages dihapus");

  // 2. Buat ulang 4 kategori GRAPHIC dari poster
  let catSort = 1;
  for (const cat of CATEGORIES) {
    const items = POSTER_PRICELIST.filter((p) => cat.slugs.includes(p.slug));
    const minPrice = Math.min(...items.map((i) => i.price));
    const svc = await db.service.create({
      data: {
        type: "GRAPHIC",
        niche: null,
        name: cat.name,
        slug: `kategori-${cat.id}`,
        description: cat.desc,
        priceLabel: `Mulai dari Rp ${minPrice.toLocaleString("id-ID")}`,
        priceFrom: minPrice,
        estDuration: "1–3 hari kerja",
        revision: "2x revisi",
        sortOrder: catSort,
        active: true,
      },
    });
    let pkgSort = 1;
    for (const item of items) {
      await db.servicePackage.create({
        data: {
          serviceId: svc.id,
          name: item.name,
          price: item.price,
          priceLabel: null,
          description: `${item.name} — harga satuan sesuai pricelist.`,
          features: JSON.stringify(["Desain profesional", "File siap pakai (PNG/JPG)", "2x revisi"]),
          estDuration: "1–3 hari kerja",
          revision: "2x revisi",
          popular: pkgSort === 1,
          active: true,
          sortOrder: pkgSort,
        },
      });
      pkgSort++;
    }
    console.log(`✓ ${cat.name}: ${items.length} item, mulai Rp ${minPrice.toLocaleString("id-ID")}`);
    catSort++;
  }

  // 3. Buat ulang 6 website services umum (tanpa niche, tanpa bundle)
  let wsSort = 1;
  for (const ws of WEBSITE_SERVICES) {
    await db.service.create({
      data: {
        type: "WEBSITE",
        niche: null,
        name: ws.name,
        slug: ws.slug,
        description: `${ws.name} — ${ws.priceLabel}. Sudah termasuk online.`,
        priceLabel: ws.priceLabel,
        priceFrom: ws.priceFrom,
        estDuration: "1–21 hari kerja",
        revision: "Maksimal 4 kali revisi",
        options: JSON.stringify(["Sudah termasuk online", "Responsif"]),
        sortOrder: wsSort,
        active: true,
      },
    });
    console.log(`✓ ${ws.name}: ${ws.priceLabel}`);
    wsSort++;
  }

  // 4. Tidak ada BUNDLE dan tidak ada niche services — semua bersih

  // 5. Update content section
  const summary = {
    title: "Jasa Desain Grafis",
    desc: "Pricelist lengkap mulai dari Rp 10.000. 4 kategori: Sosial Media, Promosi, Branding, UMKM & Bisnis.",
    points: ["Sosial Media", "Promosi", "Branding", "UMKM & Bisnis"],
    cta: { label: "Lihat Pricelist Desain", view: "pricelist" },
  };
  await db.contentSection.upsert({
    where: { key: "services_summary_graphic" },
    update: { value: JSON.stringify(summary) },
    create: { key: "services_summary_graphic", value: JSON.stringify(summary) },
  });

  console.log("\n=== SELESAI ===");
  const g = await db.service.count({ where: { type: "GRAPHIC" } });
  const w = await db.service.count({ where: { type: "WEBSITE" } });
  const b = await db.service.count({ where: { type: "BUNDLE" } });
  const pkgs = await db.servicePackage.count();
  console.log(`GRAPHIC: ${g} kategori | WEBSITE: ${w} layanan | BUNDLE: ${b} (harus 0) | Total packages: ${pkgs}`);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
