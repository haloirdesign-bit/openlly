// Openly service worker — push notifications & basic caching
// Only sends push when VAPID keys are configured server-side and user granted permission.

self.addEventListener("push", (event) => {
  let data = { title: "Openly", body: "Anda memiliki pembaruan pesanan." };
  try {
    if (event.data) data = event.data.json();
  } catch (e) {
    if (event.data) data.body = event.data.text();
  }
  const options = {
    body: data.body,
    icon: "/openly-mark.svg",
    badge: "/openly-mark.svg",
    data: data.url ? { url: data.url } : {},
    vibrate: [80, 40, 80],
  };
  event.waitUntil(self.registration.showNotification(data.title || "Openly", options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })
  );
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") self.skipWaiting();
});
