# Task A13 — admin-ui-updater (full-stack-developer)

## Task
Update existing admin pages in the Openly project to support the new `niche` field, `BUNDLE` service type, and `testimonials` content section.

## Scope (files touched — admin only)
1. `src/components/admin/pages/services.tsx` — add niche field + BUNDLE support
2. `src/components/admin/pages/content.tsx` — add testimonials + review_section editors
3. `src/components/admin/admin-view.tsx` — add services-bundle menu item + route

No public views, header, footer, or APIs were modified.

## What changed

### `services.tsx`
- Added import `NICHES, nicheInfo` from `@/lib/types`.
- Added `niche: string` to `ServiceFormState` + `EMPTY_FORM` (default `""` = Umum).
- Added helpers `typeLabel(type)` / `typeLabelShort(type)` (GRAPHIC / WEBSITE / BUNDLE labels).
- `openEdit`: prefill `niche: s.niche || ""`.
- `submit` POST/PATCH body includes `niche: form.niche.trim() || null`.
- Added Niche `<Select>` in the service form dialog (after Opsi for WEBSITE, before Urutan/Aktif). Options: `"Umum (tanpa niche)"` (value `""`) + NICHES mapped `${emoji} ${short}`.
- In `ServiceRow`: render niche as a Badge via `nicheInfo(service.niche)` — colored (`border-primary/30 bg-primary/5 text-primary`) when set, muted "Umum" otherwise. Title shows niche desc.
- Header/empty-state copy now uses `typeLabel`/`typeLabelShort` so BUNDLE shows "Paket Bundle".

### `content.tsx`
- Imported shadcn `Select` + `Star`, `MessageSquareQuote` icons.
- Added `testimonials` + `review_section` to `SECTION_LABELS` and `ORDER` (placed after `owner`, before `faq`, before `contact`).
- Editor switch routes to new editors.
- New `TestimonialsEditor` (array of `{ name, role, text, rating }`): card list with header (Testimoni #N + Hapus), Name/Role grid, Testimoni Textarea, Rating Select (5..1, default 5), "Tambah Testimoni" button.
- New `ReviewSectionEditor` (object `{ title, desc, googleRating, googleCount, googleUrl }`): Judul Input, Deskripsi Textarea, Rating Google (number step 0.1 max 5), Jumlah Ulasan (number), URL Ulasan Google Input.
- Both write through `onChange` so parent `SectionEditor.saveSection(key, value)` PATCHes `/api/admin/content` with `{ key, value }` and toasts.

### `admin-view.tsx`
- Added `"services-bundle"` to `AdminPageId` union (between `services-website` and `packages`).
- Added nav item `{ id: "services-bundle", label: "Paket Bundle", icon: Package }` (Package icon already imported).
- Added `"services-bundle": "Paket Bundle"` to `PAGE_TITLES`.
- Added `case "services-bundle": return <ServicesPage type="BUNDLE" />;` to `renderPage` switch.

## Verification
- `bun run lint` → exit 0, no new errors.
- Dev server log clean; `/api/content` and `/api/services?type=BUNDLE` both 200.

## API contracts confirmed (pre-existing)
- `/api/admin/services` GET returns `niche` per service.
- `/api/admin/services` POST/PATCH accept `niche` in body; empty string → null.
- `/api/admin/content` PATCH `{ key, value }` → saves JSON to `ContentSection`.

## Notes for downstream agents
- `ServiceType = "GRAPHIC" | "WEBSITE" | "BUNDLE"` already in `src/lib/types.ts`.
- `NICHES` array (7 niches: baby-kids, mom-care, klinik, salon, kuliner, toko, custom) in `src/lib/types.ts`.
- `nicheInfo(id?)` helper resolves niche id → `{ id, label, short, desc, emoji }`.
- BUNDLE services appear in the new "Paket Bundle" sidebar entry. Existing PackagesPage (`/api/admin/packages`) will list packages attached to BUNDLE services too (no change needed there).
